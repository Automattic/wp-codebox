<?php
/** Native runtime composition and the option-only compatibility wrapper. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../class-wp-markdown-canonical-option-path.php';
require_once __DIR__ . '/class-wp-markdown-native-query-contracts.php';
require_once __DIR__ . '/class-wp-markdown-native-scalar-evaluator.php';
require_once __DIR__ . '/class-wp-markdown-native-sql-session.php';
require_once __DIR__ . '/class-wp-markdown-native-query-schema.php';
require_once __DIR__ . '/class-wp-markdown-native-schema-catalog.php';
require_once __DIR__ . '/class-wp-markdown-native-sql-tokenizer.php';
require_once __DIR__ . '/class-wp-markdown-native-query-ast.php';
require_once __DIR__ . '/class-wp-markdown-native-query-parser.php';
require_once __DIR__ . '/../class-wp-markdown-storage.php';
require_once __DIR__ . '/class-wp-markdown-native-table-providers.php';
require_once __DIR__ . '/class-wp-markdown-native-option-mutations.php';
require_once __DIR__ . '/class-wp-markdown-native-table-index.php';
require_once __DIR__ . '/class-wp-markdown-native-table-mutations.php';
require_once __DIR__ . '/class-wp-markdown-native-post-mutations.php';
require_once __DIR__ . '/class-wp-markdown-native-schema-introspection.php';
require_once __DIR__ . '/class-wp-markdown-native-schema-mutations.php';
require_once __DIR__ . '/../class-wp-markdown-sql-classifier.php';
require_once __DIR__ . '/../class-wp-markdown-table-durability-policy.php';
require_once __DIR__ . '/class-wp-markdown-native-transactions.php';
require_once __DIR__ . '/class-wp-markdown-native-temporary-tables.php';
require_once __DIR__ . '/class-wp-markdown-native-advisory-locks.php';
require_once __DIR__ . '/class-wp-markdown-native-query-executor.php';

final class WP_Markdown_Native_Runtime_Factory {

	public static function options_schema(): WP_Markdown_Native_Table_Schema {
		return WP_Markdown_Native_Schema_Catalog::table_schema(
			'options',
			'integer',
			array(
				'columns' => array(
					'option_name' => array(
						'normalizer'      => array( self::class, 'normalize_ascii_ci' ),
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_ascii_strings( $values ),
					),
					// WordPress options use a nonbinary text column. Limit native CAS
					// matching to the ASCII portion of that collation rather than guess
					// at an unsupported Unicode collation.
					'option_value' => array( 'normalizer' => array( self::class, 'normalize_ascii_ci_padded' ) ),
					'autoload' => array(
						'lookup_operators' => array( 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => ! array_diff( $values, array( 'yes', 'on', 'auto-on', 'auto' ) ),
					),
				),
			)
		);
	}

	public static function users_schema( bool $multisite = false ): WP_Markdown_Native_Table_Schema {
		$ascii_lookup = static fn( array $values ): bool => self::all_ascii_strings( $values );
		$unsigned_lookup = static fn( array $values ): bool => self::all_normalized_unsigned( $values );
		return WP_Markdown_Native_Schema_Catalog::table_schema(
			'users',
			'string',
			array(
				'columns' => array(
					'ID' => array( 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $unsigned_lookup ),
					'user_login' => array( 'normalizer' => array( self::class, 'normalize_ascii_ci' ), 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $ascii_lookup ),
					'user_nicename' => array( 'normalizer' => array( self::class, 'normalize_ascii_ci' ), 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $ascii_lookup ),
					'user_email' => array( 'normalizer' => array( self::class, 'normalize_ascii_ci' ), 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $ascii_lookup ),
				),
				'order_columns' => array( 'user_login' ),
			),
			$multisite
		);
	}

	public static function usermeta_schema(): WP_Markdown_Native_Table_Schema {
		return WP_Markdown_Native_Schema_Catalog::table_schema(
			'usermeta',
			'string',
			array(
				'columns' => array(
					'user_id' => array(
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_normalized_unsigned( $values ),
					),
					// WordPress locates an existing meta row by key before it
					// writes, so a missing meta_key lookup silently duplicates
					// the row instead of updating it. Keys are case-insensitive
					// ASCII in practice, and a non-ASCII key fails closed rather
					// than matching under an assumed collation.
					'meta_key' => array(
						'normalizer'       => array( self::class, 'normalize_ascii_ci' ),
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_ascii_strings( $values ),
					),
				),
			)
		);
	}

	public static function posts_schema(): WP_Markdown_Native_Table_Schema {
		return WP_Markdown_Native_Schema_Catalog::table_schema(
			'posts',
			'integer',
			array(
				'columns' => array(
					'ID' => array( 'lookup_operators' => array( '=', 'IN' ) ),
					'post_author' => array( 'lookup_operators' => array( '=', 'IN' ) ),
					'post_parent' => array( 'lookup_operators' => array( '=', 'IN' ) ),
					'post_type' => array( 'lookup_operators' => array( '=', 'IN' ) ),
					// Duplicate-event discovery uses a title equality candidate set.
					// MySQL's nonbinary VARCHAR comparisons ignore trailing spaces.
					// Keep its file-backed scan bounded to ASCII comparisons instead
					// of assuming MySQL's full Unicode collation.
					'post_title' => array(
						'normalizer'       => array( self::class, 'normalize_ascii_ci_padded' ),
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_ascii_strings( $values ),
					),
					// WordPress resolves a permalink by slug, so post_name is the
					// lookup every front-end request depends on. Slugs are
					// sanitized to ASCII, and a non-ASCII slug fails closed
					// rather than resolving under an assumed collation.
					'post_name' => array(
						'normalizer'       => array( self::class, 'normalize_ascii_ci' ),
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_ascii_strings( $values ),
					),
				),
				'order_columns' => array( 'post_date', 'post_date_gmt', 'post_modified', 'post_modified_gmt', 'menu_order', 'post_title' ),
			)
		);
	}

	public static function comments_schema(): WP_Markdown_Native_Table_Schema {
		$unsigned_lookup = static fn( array $values ): bool => self::all_normalized_unsigned( $values );
		return WP_Markdown_Native_Schema_Catalog::table_schema(
			'comments',
			'string',
			array(
				'columns' => array(
					'comment_ID' => array( 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $unsigned_lookup ),
					'comment_post_ID' => array( 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $unsigned_lookup ),
					'comment_author_email' => array(
						'normalizer'       => array( self::class, 'normalize_ascii_ci' ),
						'lookup_operators' => array( '=', 'IN' ),
						'lookup_validator' => static fn( array $values ): bool => self::all_ascii_strings( $values ),
					),
					'comment_approved' => array( 'lookup_operators' => array( '=', 'IN' ) ),
					'comment_parent' => array( 'lookup_operators' => array( '=', 'IN' ), 'lookup_validator' => $unsigned_lookup ),
				),
				'order_columns' => array( 'comment_date_gmt' ),
			)
		);
	}

	public static function registry(
		string $state_root,
		string $prefix = 'wp_',
		?string $base_prefix = null,
		bool $multisite = false,
		?string $content_root = null,
		?string $global_state_root = null,
		?string $global_content_root = null
	): WP_Markdown_Native_Table_Registry {
		$base_prefix = $base_prefix ?? $prefix;
		$content_root = $content_root ?? $state_root;
		$global_state_root = $global_state_root ?? $state_root;
		$global_content_root = $global_content_root ?? $content_root;
		$registry = new WP_Markdown_Native_Table_Registry();
		// Untouched storage holds no site, so it reports no tables and leaves
		// WordPress free to install one here.
		if ( self::holds_canonical_site( $state_root, $content_root ) ) {
			foreach ( array_keys( WP_Markdown_Native_Schema_Catalog::definitions( $multisite ) ) as $suffix ) {
				self::register_core_table( $registry, $state_root, $content_root, $prefix, $base_prefix, $multisite, (string) $suffix, $global_state_root, $global_content_root );
			}
		} elseif ( $multisite && self::holds_canonical_site( $global_state_root, $global_content_root ) ) {
			// A new site's local root is empty while wp_initialize_site() still
			// needs established network tables such as sitemeta.
			foreach ( array( 'blogs', 'blogmeta', 'registration_log', 'site', 'sitemeta', 'signups' ) as $suffix ) {
				self::register_core_table( $registry, $state_root, $content_root, $prefix, $base_prefix, true, $suffix, $global_state_root, $global_content_root );
			}
		}
		self::register_persisted_plugin_tables( $registry, $state_root, $prefix, $multisite );
		return $registry;
	}

	/**
	 * Register one generated core table against canonical storage.
	 *
	 * Creating a core table has to reach the provider that reads its canonical
	 * form, so posts stay Markdown and options stay their own store, rather
	 * than the generic snapshot a plugin table would earn.
	 */
	public static function register_core_table(
		WP_Markdown_Native_Table_Registry $registry,
		string $state_root,
		string $content_root,
		string $prefix,
		string $base_prefix,
		bool $multisite,
		string $suffix,
		?string $global_state_root = null,
		?string $global_content_root = null
	): bool {
		$definitions = WP_Markdown_Native_Schema_Catalog::definitions( $multisite );
		if ( ! isset( $definitions[ $suffix ] ) ) {
			return false;
		}
		$network = array( 'blogs', 'blogmeta', 'registration_log', 'site', 'sitemeta', 'signups' );
		$table_prefix = $multisite && in_array( $suffix, $network, true ) ? $base_prefix : $prefix;
		if ( in_array( $suffix, array( 'users', 'usermeta' ), true ) ) {
			$table_prefix = $base_prefix;
		}
		$provider_state_root = $table_prefix === $base_prefix ? ( $global_state_root ?? $state_root ) : $state_root;
		$provider_content_root = $table_prefix === $base_prefix ? ( $global_content_root ?? $content_root ) : $content_root;
		if ( null !== $registry->definition( $table_prefix . $suffix ) ) {
			return false;
		}
		if ( 'options' === $suffix ) {
			$options = self::options_schema();
			$registry->register( $prefix . 'options', $options, new WP_Markdown_Native_Option_Provider( $provider_state_root, $options ) );
			return true;
		}
		if ( 'posts' === $suffix ) {
			$posts = self::posts_schema();
			$network_root = $multisite && $prefix === $base_prefix;
			$registry->register( $prefix . 'posts', $posts, new WP_Markdown_Native_Post_Provider( $provider_content_root, $posts, self::shared_storage( $provider_content_root, $network_root ), $provider_state_root, $network_root ) );
			return true;
		}
		$bespoke = array(
			'users' => static fn(): WP_Markdown_Native_Table_Schema => self::users_schema( $multisite ),
			'usermeta' => static fn(): WP_Markdown_Native_Table_Schema => self::usermeta_schema(),
			'comments' => static fn(): WP_Markdown_Native_Table_Schema => self::comments_schema(),
		);
		if ( isset( $bespoke[ $suffix ] ) ) {
			self::register_json_snapshot( $registry, $provider_state_root, $table_prefix . $suffix, ( $bespoke[ $suffix ] )(), $suffix . '.json' );
			return true;
		}
		$schema = self::generated_core_schema( $suffix, $definitions[ $suffix ] );
		if ( null === $schema ) {
			return false;
		}
		self::register_json_snapshot( $registry, $provider_state_root, $table_prefix . $suffix, $schema, $suffix . '.json' );
		return true;
	}

	public static function runtime(
		string $state_root,
		string $prefix = 'wp_',
		?string $base_prefix = null,
		bool $multisite = false,
		?string $content_root = null,
		?string $global_state_root = null,
		?string $global_content_root = null,
		?WP_Markdown_Native_Advisory_Locks $advisory_locks = null,
		?string $transaction_state_root = null,
		?WP_Markdown_Native_SQL_Session $session = null
	): WP_Markdown_Native_Query_Runtime {
		$session ??= new WP_Markdown_Native_SQL_Session();
		$state_root = self::materialize_state_root( $state_root );
		if ( null !== $content_root ) {
			$content_root = self::materialize_state_root( $content_root );
		}
		if ( null !== $global_state_root ) {
			$global_state_root = self::materialize_state_root( $global_state_root );
		}
		if ( null !== $global_content_root ) {
			$global_content_root = self::materialize_state_root( $global_content_root );
		}
		$transactions = self::shared_transactions(
			$transaction_state_root ?? $state_root,
			array_filter( array( $state_root, $content_root, $global_state_root, $global_content_root ) )
		);
		$registry = self::registry( $state_root, $prefix, $base_prefix, $multisite, $content_root, $global_state_root, $global_content_root );
		$temporary_tables = new WP_Markdown_Native_Temporary_Tables();
		$parser = new WP_Markdown_Native_Table_Insert_Parser();
		$resolved_base = $base_prefix ?? $prefix;
		$resolved_content = $content_root ?? $state_root;
		$resolved_global_state = $global_state_root ?? $state_root;
		$resolved_global_content = $global_content_root ?? $resolved_content;
		$core_registrar = static fn( string $suffix ): bool => self::register_core_table(
			$registry,
			$state_root,
			$resolved_content,
			$prefix,
			$resolved_base,
			$multisite,
			$suffix,
			$resolved_global_state,
			$resolved_global_content
		);
		return new WP_Markdown_Native_Query_Runtime(
			$registry,
			new WP_Markdown_Native_Query_Parser(),
			new WP_Markdown_Native_Option_Mutation_Runtime( $state_root, new WP_Markdown_Native_Option_Mutation_Parser(), $transactions ),
			new WP_Markdown_Native_Schema_Mutation_Runtime( $state_root, $registry, $transactions, $core_registrar, $temporary_tables ),
			new WP_Markdown_Native_Table_Mutation_Runtime( $state_root, $registry, $parser, $transactions, $temporary_tables, $session ),
			$transactions,
			new WP_Markdown_Native_Post_Mutation_Runtime(
				$registry,
				$parser,
				self::shared_storage( $content_root ?? $state_root, $multisite && $prefix === $resolved_base ),
				$transactions,
			),
			advisory_locks: $advisory_locks ?? new WP_Markdown_Native_Advisory_Locks( $state_root ),
			session: $session
		);
	}

	/** Materialize a declared native state root before its journal can use it. */
	private static function materialize_state_root( string $state_root ): string {
		if ( '' === $state_root || is_link( $state_root ) || ( file_exists( $state_root ) && ! is_dir( $state_root ) ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		if ( ! is_dir( $state_root ) && ! @mkdir( $state_root, 0755, true ) && ! is_dir( $state_root ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		$root = realpath( $state_root );
		if ( false === $root || ! is_dir( $root ) || is_link( $state_root ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		return rtrim( $root, DIRECTORY_SEPARATOR );
	}

	/** @var array<string,WP_Markdown_Native_Transaction_Journal> */
	private static array $transactions = array();

	/**
	 * One state root has one transaction owner per process.
	 *
	 * The first construction is a cold-root boundary and may recover an orphaned
	 * journal. Prefix changes reuse that owner, so they cannot recover or replace
	 * a live transaction.
	 */
	/** @param list<string> $admitted_roots */
	private static function shared_transactions( string $state_root, array $admitted_roots ): WP_Markdown_Native_Transaction_Journal {
		if ( ! isset( self::$transactions[ $state_root ] ) ) {
			$transactions = new WP_Markdown_Native_Transaction_Journal( $state_root, $admitted_roots );
			$transactions->recover();
			self::$transactions[ $state_root ] = $transactions;
		} else {
			// Later prefix and multisite runtimes may add factory-configured roots.
			self::$transactions[ $state_root ]->admit_roots( $admitted_roots );
		}
		return self::$transactions[ $state_root ];
	}

	/** Route a multisite request to its base or site-local canonical roots. */
	public static function multisite_runtime(
		string $state_root,
		string $base_prefix = 'wp_',
		?string $content_root = null
	): WP_Markdown_Query_Runtime {
		return new WP_Markdown_Native_Multisite_Query_Runtime( $state_root, $base_prefix, $content_root ?? $state_root );
	}

	/** Route a single site's changing wpdb prefix to its one canonical root. */
	public static function prefix_runtime(
		string $state_root,
		?string $content_root = null
	): WP_Markdown_Query_Runtime {
		return new WP_Markdown_Native_Prefix_Query_Runtime( $state_root, $content_root ?? $state_root );
	}

	/** Select the multisite dispatcher only once WordPress has published its topology. */
	public static function wordpress_runtime(
		string $state_root,
		string $base_prefix = 'wp_',
		?string $content_root = null
	): WP_Markdown_Query_Runtime {
		return new WP_Markdown_Native_WordPress_Query_Runtime( $state_root, $base_prefix, $content_root ?? $state_root );
	}

	/**
	 * Report whether canonical storage holds a site yet.
	 *
	 * Core tables are generated from WordPress rather than persisted, so they
	 * would otherwise be described even in an empty directory, and WordPress
	 * reads a described core table as proof a site is already installed.
	 *
	 * The options store is the signal because no WordPress site can exist
	 * without one, and installation writes it. A plugin table alone leaves
	 * canonical storage without a site in it.
	 */
	private static function holds_canonical_site( string $state_root, string $content_root ): bool {
		foreach ( array_unique( array( $state_root, $content_root ) ) as $root ) {
			$path = rtrim( $root, '/\\' ) . DIRECTORY_SEPARATOR . '_options';
			if ( is_dir( $path ) && ! is_link( $path ) ) {
				return true;
			}
		}
		return false;
	}

	/** @var array<string,WP_Markdown_Storage> */
	private static array $storages = array();

	/**
	 * One storage instance per canonical content root.
	 *
	 * Reading posts and writing them have to agree about the corpus, because
	 * a read that remembers what it parsed must be told when a write changes
	 * a file underneath it.
	 */
	private static function shared_storage( string $content_root, bool $network_root = false ): WP_Markdown_Storage {
		$key = ( $network_root ? 'network:' : 'site:' ) . rtrim( $content_root, '/\\' );
		if ( ! isset( self::$storages[ $key ] ) ) {
			// The network root owns sites/{blog_id}; it is not a post-type tree.
			$storage = new WP_Markdown_Storage( $content_root, $network_root ? array( 'sites' ) : array() );
			// A post with a parent belongs inside its parent's directory, and
			// the writer walks the ancestor chain to find that directory. Without
			// a resolver it cannot read an ancestor, so it writes the child flat
			// at the post-type root while the row still records the parent. The
			// path then disagrees with the hierarchy the row declares.
			$storage->set_post_resolver( static fn( int $post_id ): ?object => $storage->read_post( $post_id ) );
			self::$storages[ $key ] = $storage;
		}
		return self::$storages[ $key ];
	}

	public static function register_json_snapshot(
		WP_Markdown_Native_Table_Registry $registry,
		string $state_root,
		string $table,
		WP_Markdown_Native_Table_Schema $schema,
		string $filename
	): void {
		$registry->register(
			$table,
			$schema,
			new WP_Markdown_Native_JSON_Snapshot_Provider( $state_root, $schema, $filename )
		);
	}

	private static function register_persisted_plugin_tables(
		WP_Markdown_Native_Table_Registry $registry,
		string $state_root,
		string $prefix,
		bool $multisite
	): void {
		$directory = rtrim( $state_root, '/\\' ) . '/_schema';
		$root = realpath( $directory );
		if ( is_link( $directory ) || false === $root || ! is_dir( $root ) ) {
			return;
		}
		$core_tables = WP_Markdown_Native_Schema_Catalog::definitions( $multisite );
		foreach ( glob( $root . '/*.sql' ) ?: array() as $path ) {
			$table = basename( $path, '.sql' );
			if ( 1 !== preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/D', $table ) || isset( $core_tables[ $table ] ) || ! WP_Markdown_Table_Durability_Policy::persists( $prefix . $table, $prefix ) ) {
				continue;
			}
			$ddl = self::read_persisted_file( $root, $path );
			if ( null === $ddl ) {
				continue;
			}
			try {
				$definitions = WP_Markdown_Native_Schema_Catalog::compile( $ddl, array( $prefix ) );
				if ( array( $table ) !== array_keys( $definitions ) ) {
					continue;
				}
				$registry->register_definition( $prefix . $table, $definitions[ $table ] );
				$schema = WP_Markdown_Native_Schema_Catalog::indexed_snapshot_schema( $definitions[ $table ] );
				if ( null !== $schema ) {
					$partition_marker = rtrim( $state_root, '/\\' ) . '/_tables/' . $table . '/.mdi-partition.json';
					if ( file_exists( $partition_marker ) || is_link( $partition_marker ) ) {
						$marker = self::read_persisted_partition_marker( $state_root, $table );
						$identity = is_array( $marker ) ? (string) ( $marker['identity_column'] ?? '' ) : '';
						if ( array( $identity ) !== $schema->identity_columns() ) {
							continue;
						}
						$registry->register(
							$prefix . $table,
							$schema,
							new WP_Markdown_Native_JSON_Partition_Provider( $state_root, $schema, $table, $identity )
						);
					} else {
						self::register_json_snapshot( $registry, $state_root, $prefix . $table, $schema, $table . '.json' );
					}
				}
			} catch ( Throwable ) {
				continue;
			}
		}
	}

	/** @return array<string,mixed>|null */
	private static function read_persisted_partition_marker( string $state_root, string $table ): ?array {
		$state = realpath( $state_root );
		$tables_path = rtrim( $state_root, '/\\' ) . '/_tables';
		$tables = realpath( $tables_path );
		$table_path = false === $tables ? '' : $tables . '/' . $table;
		$directory = '' === $table_path ? false : realpath( $table_path );
		if ( false === $state
			|| false === $tables
			|| false === $directory
			|| is_link( $tables_path )
			|| is_link( $table_path )
			|| dirname( $tables ) !== $state
			|| dirname( $directory ) !== $tables
		) {
			return null;
		}
		$path = $directory . '/.mdi-partition.json';
		$contents = self::read_persisted_file( $directory, $path );
		if ( null === $contents ) {
			return null;
		}
		try {
			$marker = json_decode( $contents, true, 512, JSON_THROW_ON_ERROR );
		} catch ( JsonException ) {
			return null;
		}
		return is_array( $marker )
			&& 1 === ( $marker['version'] ?? null )
			&& $table === ( $marker['table'] ?? null )
			&& is_string( $marker['identity_column'] ?? null )
			&& 1 === preg_match( '/^generation-[a-f0-9]{24}$/D', (string) ( $marker['generation'] ?? '' ) )
			? $marker
			: null;
	}

	/** @param array{columns:array<string,array<string,mixed>>,indexes:array<int,array<string,mixed>>} $definition */
	private static function generated_core_schema( string $table, array $definition ): ?WP_Markdown_Native_Table_Schema {
		$column_overlays = array();
		foreach ( $definition['indexes'] as $index ) {
			$column = $index['columns'][0]['name'] ?? '';
			$type = $definition['columns'][ $column ]['type'] ?? '';
			if ( in_array( $type, array( 'char', 'varchar' ), true ) ) {
				$ascii = static fn( array $values ): bool => self::all_ascii_strings( $values );
				$column_overlays[ $column ] = array(
					'normalizer'       => array( self::class, 'normalize_ascii_ci' ),
					'lookup_operators' => array( '=', 'IN' ),
					'lookup_validator' => $ascii,
					'filter_operators' => array( '=', 'IN', 'NOT IN', 'LIKE', 'NOT LIKE', 'REGEXP' ),
					'filter_validator' => $ascii,
				);
			}
		}
		$order_columns = 'terms' === $table ? array( 'name' ) : array();
		return WP_Markdown_Native_Schema_Catalog::indexed_snapshot_schema( $definition, $column_overlays, $order_columns );
	}

	private static function read_persisted_file( string $root, string $path ): ?string {
		$real = realpath( $path );
		if ( is_link( $path ) || false === $real || ! is_file( $real ) || dirname( $real ) !== $root ) {
			return null;
		}
		$handle = @fopen( $real, 'rb' );
		if ( false === $handle ) {
			return null;
		}
		try {
			$opened = fstat( $handle );
			$current = @lstat( $real );
			if ( false === $opened
				|| false === $current
				|| $opened['dev'] !== $current['dev']
				|| $opened['ino'] !== $current['ino']
				|| 1 !== ( $opened['nlink'] ?? 1 )
				|| is_link( $real )
			) {
				return null;
			}
			$ddl = stream_get_contents( $handle );
			return is_string( $ddl ) && '' !== trim( $ddl ) ? $ddl : null;
		} finally {
			fclose( $handle );
		}
	}

	public static function normalize_unsigned( mixed $value ): ?string {
		if ( is_int( $value ) && $value >= 0 ) {
			return (string) $value;
		}
		if ( ! is_string( $value ) || 1 !== preg_match( '/^[0-9]+$/D', $value ) ) {
			return null;
		}
		$value = ltrim( $value, '0' );
		return '' === $value ? '0' : $value;
	}

	public static function normalize_signed( mixed $value ): ?string {
		if ( is_int( $value ) ) {
			return (string) $value;
		}
		if ( ! is_string( $value ) || 1 !== preg_match( '/^-?[0-9]+$/D', $value ) ) {
			return null;
		}
		$negative = str_starts_with( $value, '-' );
		$value    = ltrim( $negative ? substr( $value, 1 ) : $value, '0' );
		$value    = '' === $value ? '0' : $value;
		return $negative && '0' !== $value ? '-' . $value : $value;
	}

	public static function normalize_ascii_ci( mixed $value ): ?string {
		if ( ! is_string( $value ) || 1 === preg_match( '/[^\x00-\x7F]/', $value ) ) {
			return null;
		}
		return strtolower( $value );
	}

	public static function normalize_ascii_ci_padded( mixed $value ): ?string {
		$value = self::normalize_ascii_ci( $value );
		return null === $value ? null : rtrim( $value, ' ' );
	}

	private static function all_normalized_unsigned( array $values ): bool {
		foreach ( $values as $value ) {
			if ( null === self::normalize_unsigned( $value ) ) {
				return false;
			}
		}
		return true;
	}

	private static function all_ascii_strings( array $values ): bool {
		foreach ( $values as $value ) {
			if ( null === self::normalize_ascii_ci( $value ) ) {
				return false;
			}
		}
		return true;
	}
}

final class WP_Markdown_Native_Option_Query_Runtime implements WP_Markdown_Query_Runtime, WP_Markdown_Native_Transactional_Table_Support {

	private WP_Markdown_Native_Query_Runtime $runtime;

	public function __construct(
		string $state_root,
		private string $table_prefix = 'wp_'
	) {
		$this->runtime = WP_Markdown_Native_Runtime_Factory::runtime( $state_root, $table_prefix );
	}

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		if ( $this->table_prefix !== $request->table_prefix() ) {
			return WP_Markdown_Query_Result::failure(
				array(
					'code'    => 'markdown_db_native_unsupported_query',
					'reason'  => 'unsupported_table_prefix',
					'message' => 'The native option runtime is bound to a different canonical state root.',
				)
			);
		}
		return $this->runtime->execute( $request );
	}

	public function supports_transactional_tables( array $tables ): bool {
		return $this->runtime->supports_transactional_tables( $tables );
	}
}

/** Lazily construct a single-root runtime for the prefix selected by wpdb. */
final class WP_Markdown_Native_Prefix_Query_Runtime implements WP_Markdown_Query_Runtime, WP_Markdown_Native_Transactional_Table_Support {

	/** @var array<string,WP_Markdown_Native_Query_Runtime> */
	private array $runtimes = array();
	private WP_Markdown_Native_Advisory_Locks $advisory_locks;

	public function __construct(
		private string $state_root,
		private string $content_root,
		private WP_Markdown_Native_SQL_Session $session = new WP_Markdown_Native_SQL_Session()
	) {
		$this->advisory_locks = new WP_Markdown_Native_Advisory_Locks( $state_root );
	}

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		$prefix = $request->table_prefix();
		if ( ! isset( $this->runtimes[ $prefix ] ) ) {
			$this->runtimes[ $prefix ] = WP_Markdown_Native_Runtime_Factory::runtime(
				$this->state_root,
				$prefix,
				$prefix,
				false,
				$this->content_root,
				advisory_locks: $this->advisory_locks,
				session: $this->session
			);
		}
		return $this->runtimes[ $prefix ]->execute( $request );
	}

	public function supports_transactional_tables( array $tables ): bool {
		$prefix = isset( $GLOBALS['wpdb']->prefix ) && is_string( $GLOBALS['wpdb']->prefix ) ? $GLOBALS['wpdb']->prefix : 'wp_';
		if ( ! isset( $this->runtimes[ $prefix ] ) ) {
			$this->runtimes[ $prefix ] = WP_Markdown_Native_Runtime_Factory::runtime(
				$this->state_root,
				$prefix,
				$prefix,
				false,
				$this->content_root,
				advisory_locks: $this->advisory_locks,
				session: $this->session
			);
		}
		return $this->runtimes[ $prefix ]->supports_transactional_tables( $tables );
	}

	public function close(): void {
		$this->advisory_locks->close();
		$this->session->reset();
	}
}

/** Defer WordPress topology detection because db.php precedes multisite bootstrap. */
final class WP_Markdown_Native_WordPress_Query_Runtime implements WP_Markdown_Query_Runtime, WP_Markdown_Native_Transactional_Table_Support {

	private WP_Markdown_Native_Prefix_Query_Runtime $prefix_runtime;
	/** @var array<string,WP_Markdown_Native_Multisite_Query_Runtime> */
	private array $multisite_runtimes = array();
	private WP_Markdown_Native_SQL_Session $session;

	public function __construct( string $state_root, private string $base_prefix, string $content_root ) {
		$this->session = new WP_Markdown_Native_SQL_Session();
		$this->prefix_runtime = new WP_Markdown_Native_Prefix_Query_Runtime( $state_root, $content_root, $this->session );
		$this->state_root = $state_root;
		$this->content_root = $content_root;
	}

	private string $state_root;
	private string $content_root;

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		$multisite = ( defined( 'WP_INSTALLING_NETWORK' ) && WP_INSTALLING_NETWORK ) || ( defined( 'MULTISITE' ) && MULTISITE ) || ( function_exists( 'is_multisite' ) && is_multisite() );
		if ( ! $multisite ) {
			return $this->prefix_runtime->execute( $request );
		}
		$base_prefix = isset( $GLOBALS['wpdb']->base_prefix ) && is_string( $GLOBALS['wpdb']->base_prefix )
			? $GLOBALS['wpdb']->base_prefix
			: $this->base_prefix;
		if ( ! isset( $this->multisite_runtimes[ $base_prefix ] ) ) {
			$this->multisite_runtimes[ $base_prefix ] = new WP_Markdown_Native_Multisite_Query_Runtime( $this->state_root, $base_prefix, $this->content_root, $this->session );
		}
		return $this->multisite_runtimes[ $base_prefix ]->execute( $request );
	}

	public function close(): void {
		$this->prefix_runtime->close();
		foreach ( $this->multisite_runtimes as $runtime ) {
			$runtime->close();
		}
	}

	public function supports_transactional_tables( array $tables ): bool {
		$multisite = ( defined( 'WP_INSTALLING_NETWORK' ) && WP_INSTALLING_NETWORK ) || ( defined( 'MULTISITE' ) && MULTISITE ) || ( function_exists( 'is_multisite' ) && is_multisite() );
		if ( ! $multisite ) {
			return $this->prefix_runtime->supports_transactional_tables( $tables );
		}
		$base_prefix = isset( $GLOBALS['wpdb']->base_prefix ) && is_string( $GLOBALS['wpdb']->base_prefix ) ? $GLOBALS['wpdb']->base_prefix : $this->base_prefix;
		if ( ! isset( $this->multisite_runtimes[ $base_prefix ] ) ) {
			$this->multisite_runtimes[ $base_prefix ] = new WP_Markdown_Native_Multisite_Query_Runtime( $this->state_root, $base_prefix, $this->content_root, $this->session );
		}
		return $this->multisite_runtimes[ $base_prefix ]->supports_transactional_tables( $tables );
	}
}

/** Lazily compose a native runtime for each WordPress multisite table scope. */
final class WP_Markdown_Native_Multisite_Query_Runtime implements WP_Markdown_Query_Runtime, WP_Markdown_Native_Transactional_Table_Support {

	/** @var array<string,WP_Markdown_Native_Query_Runtime> */
	private array $runtimes = array();
	private string $state_root;
	private string $content_root;
	private WP_Markdown_Native_Advisory_Locks $advisory_locks;

	public function __construct(
		string $state_root,
		private string $base_prefix,
		string $content_root,
		private WP_Markdown_Native_SQL_Session $session = new WP_Markdown_Native_SQL_Session()
	) {
		if ( 1 !== preg_match( '/^[A-Za-z0-9_]+$/D', $base_prefix ) ) {
			throw new InvalidArgumentException( 'The base table prefix contains unsupported characters.' );
		}
		$this->state_root = rtrim( $state_root, '/\\' );
		$this->content_root = rtrim( $content_root, '/\\' );
		$this->advisory_locks = new WP_Markdown_Native_Advisory_Locks( $this->state_root );
	}

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		$prefix = $request->table_prefix();
		if ( ! $this->is_scope_prefix( $prefix ) ) {
			return WP_Markdown_Query_Result::failure(
				array(
					'code'    => 'markdown_db_native_unsupported_query',
					'reason'  => 'unsupported_table_prefix',
					'message' => 'The native runtime requires the network or a numeric site table prefix.',
				)
			);
		}
		if ( ! isset( $this->runtimes[ $prefix ] ) ) {
			$roots = $this->roots( $prefix );
			if ( null === $roots ) {
				return WP_Markdown_Query_Result::failure(
					array(
						'code' => 'markdown_db_native_unsafe_path',
						'reason' => 'invalid_site_root',
						'message' => 'The native runtime could not initialize the selected site root.',
					)
				);
			}
			try {
				$this->runtimes[ $prefix ] = WP_Markdown_Native_Runtime_Factory::runtime(
					$roots['state'],
					$prefix,
					$this->base_prefix,
					true,
					$roots['content'],
					$this->state_root,
					$this->content_root,
					$this->advisory_locks,
					$this->state_root,
					$this->session
				);
			} catch ( Throwable ) {
				return WP_Markdown_Query_Result::failure(
					array(
						'code' => 'markdown_db_native_unsafe_path',
						'reason' => 'invalid_site_root',
						'message' => 'The native runtime could not initialize the selected site root.',
					)
				);
			}
		}
		return $this->runtimes[ $prefix ]->execute( $request );
	}

	public function supports_transactional_tables( array $tables ): bool {
		$prefix = isset( $GLOBALS['wpdb']->prefix ) && is_string( $GLOBALS['wpdb']->prefix ) ? $GLOBALS['wpdb']->prefix : $this->base_prefix;
		if ( ! $this->is_scope_prefix( $prefix ) ) {
			return false;
		}
		if ( ! isset( $this->runtimes[ $prefix ] ) ) {
			$roots = $this->roots( $prefix );
			if ( null === $roots ) {
				return false;
			}
			try {
				$this->runtimes[ $prefix ] = WP_Markdown_Native_Runtime_Factory::runtime(
					$roots['state'], $prefix, $this->base_prefix, true, $roots['content'], $this->state_root, $this->content_root, $this->advisory_locks, $this->state_root, $this->session
				);
			} catch ( Throwable ) {
				return false;
			}
		}
		return $this->runtimes[ $prefix ]->supports_transactional_tables( $tables );
	}

	public function close(): void {
		$this->advisory_locks->close();
		$this->session->reset();
	}

	private function is_scope_prefix( string $prefix ): bool {
		if ( $this->base_prefix === $prefix || ! str_starts_with( $prefix, $this->base_prefix ) ) {
			return $this->base_prefix === $prefix;
		}
		$suffix = substr( $prefix, strlen( $this->base_prefix ) );
		return 1 === preg_match( '/^[0-9]+_$/D', $suffix ) && (int) substr( $suffix, 0, -1 ) >= 2;
	}

	/** @return array{state:string,content:string}|null */
	private function roots( string $prefix ): ?array {
		if ( $this->base_prefix === $prefix ) {
			return array( 'state' => $this->state_root, 'content' => $this->content_root );
		}
		preg_match( '/([0-9]+)_$/D', $prefix, $matches );
		$blog_id = (int) ( $matches[1] ?? 0 );
		if ( $blog_id < 2 ) {
			return null;
		}
		$state = $this->state_root . '/sites/' . $blog_id;
		$content = $this->content_root . '/sites/' . $blog_id;
		foreach ( array_unique( array( $state, $content ) ) as $root ) {
			if ( ! is_dir( $root ) && ! @mkdir( $root, 0755, true ) ) {
				return null;
			}
			if ( is_link( $root ) ) {
				return null;
			}
		}
		return array( 'state' => $state, 'content' => $content );
	}
}
