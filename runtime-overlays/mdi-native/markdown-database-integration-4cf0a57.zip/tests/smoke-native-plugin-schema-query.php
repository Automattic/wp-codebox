<?php
/** Native execution over automatically discovered plugin schemas and snapshots. */

declare( strict_types=1 );

define( 'ABSPATH', __DIR__ . '/' );
define( 'DB_NAME', 'wordpress' );

function apply_filters( string $tag, mixed $value, mixed ...$args ): mixed {
	if ( 'markdown_db_table_durability_policy' === $tag && 'ephemeral_native' === ( $args[0] ?? null ) ) {
		return array( 'durability' => 'ephemeral' );
	}
	return $value;
}

require_once __DIR__ . '/../inc/native/class-wp-markdown-native-query-runtime.php';

function mdi_plugin_schema_remove_tree( string $root ): void {
	if ( ! is_dir( $root ) ) {
		return;
	}
	$entries = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $entries as $entry ) {
		$entry->isDir() && ! $entry->isLink() ? rmdir( $entry->getPathname() ) : unlink( $entry->getPathname() );
	}
	rmdir( $root );
}

$root = sys_get_temp_dir() . '/mdi-native-plugin-schema-' . bin2hex( random_bytes( 6 ) );
$outside = $root . '-outside.sql';
$outside_marker = $root . '-outside-marker.json';
mkdir( $root . '/_schema', 0755, true );
mkdir( $root . '/_tables', 0755, true );

$schema = "CREATE TABLE `wp_plugin_jobs` (\n"
	. " `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n"
	. " `owner_id` bigint(20) unsigned NOT NULL DEFAULT '0',\n"
	. " `status` varchar(32) NOT NULL DEFAULT '',\n"
	. " `task_url` text DEFAULT NULL,\n"
	. " `owner_run_ref` varchar(191) DEFAULT NULL,\n"
	. " `payload` longtext DEFAULT NULL,\n"
	. " PRIMARY KEY (`id`),\n"
	. " KEY `owner_id` (`owner_id`)\n"
	. ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;';
file_put_contents( $root . '/_schema/plugin_jobs.sql', $schema );
file_put_contents(
	$root . '/_tables/plugin_jobs.json',
	json_encode(
		array(
			array( 'id' => 10, 'owner_id' => '8', 'status' => 'running', 'task_url' => 'https://example.test/issues/10', 'owner_run_ref' => 'BENCH-RUN-42', 'payload' => null ),
			array( 'id' => '2', 'owner_id' => 7, 'status' => 'queued', 'task_url' => 'https://example.test/issues/42', 'owner_run_ref' => 'bench-run-2', 'payload' => 'work' ),
			array( 'id' => 1, 'owner_id' => '7', 'status' => 'done', 'task_url' => null, 'owner_run_ref' => null, 'payload' => '' ),
		),
		JSON_THROW_ON_ERROR
	)
);

file_put_contents( $root . '/_schema/no_identity.sql', 'CREATE TABLE wp_no_identity (value bigint(20) unsigned NOT NULL);' );
file_put_contents( $root . '/_tables/no_identity.json', '[{"value":1}]' );
file_put_contents( $root . '/_schema/composite.sql', 'CREATE TABLE wp_composite (left_id bigint(20) unsigned NOT NULL, right_id bigint(20) unsigned NOT NULL, PRIMARY KEY (left_id,right_id));' );
file_put_contents( $root . '/_tables/composite.json', '[{"left_id":3,"right_id":"9"},{"left_id":"3","right_id":7}]' );
file_put_contents( $root . '/_schema/unsupported.sql', 'CREATE TABLE wp_unsupported (id bigint(20) unsigned NOT NULL, region geometry NOT NULL, PRIMARY KEY (id));' );
file_put_contents( $root . '/_schema/mismatch.sql', 'CREATE TABLE wp_different_name (id bigint(20) unsigned NOT NULL, PRIMARY KEY (id));' );
file_put_contents( $root . '/_schema/malformed.sql', 'not ddl' );
file_put_contents( $root . '/_schema/inline_items.sql', "CREATE TABLE wp_inline_items (\n id INTEGER PRIMARY KEY,\n value TEXT NOT NULL\n);" );
file_put_contents( $root . '/_tables/inline_items.json', '[{"id":4,"value":"portable"}]' );
file_put_contents( $root . '/_schema/ephemeral_native.sql', 'CREATE TABLE wp_ephemeral_native (id INTEGER PRIMARY KEY);' );
file_put_contents( $root . '/_tables/ephemeral_native.json', '[{"id":1}]' );
file_put_contents( $root . '/_schema/partitioned.sql', 'CREATE TABLE wp_partitioned (id bigint(20) unsigned NOT NULL, owner_id bigint(20) unsigned NOT NULL, status varchar(32) NOT NULL, PRIMARY KEY (id), KEY owner_id (owner_id));' );
$partition_generation = 'generation-1234567890abcdef12345678';
mkdir( $root . '/_tables/partitioned/' . $partition_generation, 0755, true );
file_put_contents( $root . '/_tables/partitioned/.mdi-partition.json', '{"version":1,"table":"partitioned","identity_column":"id","generation":"' . $partition_generation . '"}' );
foreach ( array( 1 => array( 'id' => 1, 'owner_id' => 7, 'status' => 'ready' ), 2 => array( 'id' => 2, 'owner_id' => 8, 'status' => 'waiting' ) ) as $identity => $row ) {
	file_put_contents(
		$root . '/_tables/partitioned/' . $partition_generation . '/' . hash( 'sha256', (string) $identity ) . '.json',
		json_encode( array( '_mdi_partition' => array( 'version' => 1, 'identity_column' => 'id', 'identity' => (string) $identity ), 'row' => $row ), JSON_THROW_ON_ERROR )
	);
}
file_put_contents( $root . '/_schema/partition_mismatch.sql', 'CREATE TABLE wp_partition_mismatch (id bigint(20) unsigned NOT NULL, owner_id bigint(20) unsigned NOT NULL, PRIMARY KEY (id));' );
mkdir( $root . '/_tables/partition_mismatch', 0755 );
file_put_contents( $root . '/_tables/partition_mismatch/.mdi-partition.json', '{"version":1,"table":"partition_mismatch","identity_column":"owner_id","generation":"generation-1234567890abcdef12345678"}' );
file_put_contents( $root . '/_schema/partition_invalid.sql', 'CREATE TABLE wp_partition_invalid (id bigint(20) unsigned NOT NULL, PRIMARY KEY (id));' );
mkdir( $root . '/_tables/partition_invalid', 0755 );
file_put_contents( $root . '/_tables/partition_invalid/.mdi-partition.json', '{"version":1,"table":"partition_invalid","identity_column":"id","generation":"invalid"}' );
file_put_contents( $root . '/_schema/partition_linked.sql', 'CREATE TABLE wp_partition_linked (id bigint(20) unsigned NOT NULL, PRIMARY KEY (id));' );
mkdir( $root . '/_tables/partition_linked', 0755 );
file_put_contents( $outside_marker, '{"version":1,"table":"partition_linked","identity_column":"id","generation":"generation-1234567890abcdef12345678"}' );
$linked_marker = function_exists( 'symlink' ) && @symlink( $outside_marker, $root . '/_tables/partition_linked/.mdi-partition.json' );
file_put_contents( $outside, $schema );
$linked = function_exists( 'symlink' ) && @symlink( $outside, $root . '/_schema/linked.sql' );

$runtime = WP_Markdown_Native_Runtime_Factory::runtime( $root );
$exact = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT status, id FROM wp_plugin_jobs WHERE id = 2 LIMIT 1' ) );
$secondary = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id, status FROM wp_plugin_jobs WHERE owner_id IN (7) ORDER BY id ASC LIMIT 2' ) );
$unfiltered = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_plugin_jobs LIMIT 2' ) );
$string_filter = $runtime->execute( new WP_Markdown_Query_Request( "SELECT id FROM wp_plugin_jobs WHERE status = 'QUEUED'" ) );
$lower_cross_filter = $runtime->execute( new WP_Markdown_Query_Request( "SELECT id FROM wp_plugin_jobs WHERE task_url = 'https://example.test/issues/42' OR LOWER(owner_run_ref) = LOWER('bench-run-42') ORDER BY id ASC" ) );
$string_order = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_plugin_jobs ORDER BY status ASC' ) );
$no_identity = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT value FROM wp_no_identity' ) );
$composite = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT right_id FROM wp_composite WHERE left_id = 3' ) );
$unsupported = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_unsupported' ) );
$mismatch = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_mismatch' ) );
$inline = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT value FROM wp_inline_items WHERE id = 4' ) );
$ephemeral_native = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_ephemeral_native WHERE id = 1' ) );
$partitioned = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT status, id FROM wp_partitioned WHERE id = 1 AND owner_id IN (7) ORDER BY id ASC LIMIT 1' ) );
$partition_count = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT COUNT(*) FROM wp_partitioned WHERE id IN (2, 1)' ) );
$partition_scan = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_partitioned' ) );
$partition_mismatch = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_partition_mismatch WHERE owner_id = 7' ) );
$partition_invalid = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_partition_invalid WHERE id = 1' ) );
$partition_linked = $linked_marker ? $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_partition_linked WHERE id = 1' ) ) : null;
$linked_result = $linked ? $runtime->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_linked' ) ) : null;
$show_table = $runtime->execute( new WP_Markdown_Query_Request( "SHOW TABLES LIKE 'wp_plugin_jobs'" ) );
$show_table_wildcard = $runtime->execute( new WP_Markdown_Query_Request( "SHOW TABLES LIKE 'wp_plugin_%'" ) );
$show_table_escaped = $runtime->execute( new WP_Markdown_Query_Request( "SHOW TABLES LIKE 'wp\\_plugin\\_jobs'" ) );
$show_missing_table = $runtime->execute( new WP_Markdown_Query_Request( "SHOW TABLES LIKE 'wp_missing'" ) );
$describe = $runtime->execute( new WP_Markdown_Query_Request( 'DESCRIBE `wp_plugin_jobs`;' ) );
$show_column = $runtime->execute( new WP_Markdown_Query_Request( "SHOW COLUMNS FROM wp_plugin_jobs LIKE 'status'" ) );
$show_full_columns = $runtime->execute( new WP_Markdown_Query_Request( 'SHOW FULL COLUMNS FROM wp_plugin_jobs' ) );
$show_full_missing = $runtime->execute( new WP_Markdown_Query_Request( 'SHOW FULL COLUMNS FROM wp_missing' ) );
$show_indexes = $runtime->execute( new WP_Markdown_Query_Request( 'SHOW INDEX FROM `wp_plugin_jobs`' ) );
$information_columns = $runtime->execute( new WP_Markdown_Query_Request( "SELECT TABLE_NAME, COLUMN_NAME, ORDINAL_POSITION, CHARACTER_MAXIMUM_LENGTH, COLUMN_DEFAULT, IS_NULLABLE, DATA_TYPE, COLUMN_TYPE, COLUMN_KEY, EXTRA FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'wordpress' AND TABLE_NAME IN ('wp_plugin_jobs', 'wp_inline_items') AND COLUMN_NAME IN ('id', 'owner_id', 'status', 'value')" ) );
$absent_information_schema = $runtime->execute( new WP_Markdown_Query_Request( "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'absent_schema' AND TABLE_NAME = 'wp_plugin_jobs'" ) );
$contradictory_information_tables = $runtime->execute( new WP_Markdown_Query_Request( "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wp_plugin_jobs' AND TABLE_NAME = 'wp_inline_items'" ) );
$contradictory_information_columns = $runtime->execute( new WP_Markdown_Query_Request( "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wp_plugin_jobs' AND COLUMN_NAME = 'id' AND COLUMN_NAME = 'status'" ) );
$information_engine = $runtime->execute( new WP_Markdown_Query_Request( "SELECT ENGINE AS Engine FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wp_plugin_jobs'" ) );
$unbounded_information = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()' ) );
$text_information = $runtime->execute( new WP_Markdown_Query_Request( "SELECT COLUMN_NAME, CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wp_plugin_jobs' AND COLUMN_NAME IN ('task_url', 'payload')" ) );
$overwide_information = $runtime->execute( new WP_Markdown_Query_Request( "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (" . implode( ',', array_fill( 0, 101, "'wp_plugin_jobs'" ) ) . ')' ) );
$limited_residual = $runtime->execute( new WP_Markdown_Query_Request( "SELECT id FROM wp_plugin_jobs WHERE status = 'queued' LIMIT 1" ) );
file_put_contents(
	$root . '/_tables/plugin_jobs.json',
	json_encode(
		array(
			array( 'id' => 2, 'owner_id' => 7, 'status' => 'first', 'task_url' => null, 'owner_run_ref' => null, 'payload' => null ),
			array( 'id' => '2', 'owner_id' => '7', 'status' => 'duplicate', 'task_url' => null, 'owner_run_ref' => null, 'payload' => null ),
		),
		JSON_THROW_ON_ERROR
	)
);
$duplicate_identity = WP_Markdown_Native_Runtime_Factory::runtime( $root )->execute( new WP_Markdown_Query_Request( 'SELECT id FROM wp_plugin_jobs' ) );

$checks = array(
	'persisted plugin DDL and snapshots register without table-specific code' => 1 === $exact->return_value()
		&& 'queued' === ( $exact->wpdb_state()['last_result'][0]->status ?? null )
		&& '2' === ( $exact->wpdb_state()['last_result'][0]->id ?? null ),
	'generic table introspection exposes registered tables with MySQL LIKE semantics' => 1 === $show_table->return_value()
		&& 'wp_plugin_jobs' === ( $show_table->wpdb_state()['last_result'][0]->Tables_in_wordpress ?? null )
		&& 1 === $show_table_wildcard->return_value()
		&& 1 === $show_table_escaped->return_value()
		&& 0 === $show_missing_table->return_value(),
	'generic column introspection derives MySQL-visible schema rows from persisted DDL' => array( 'id', 'owner_id', 'status', 'task_url', 'owner_run_ref', 'payload' ) === array_map(
		static fn( object $row ): string => $row->Field,
		$describe->wpdb_state()['last_result']
	)
		&& 'bigint(20) unsigned' === ( $describe->wpdb_state()['last_result'][0]->Type ?? null )
		&& 'PRI' === ( $describe->wpdb_state()['last_result'][0]->Key ?? null )
		&& 'auto_increment' === ( $describe->wpdb_state()['last_result'][0]->Extra ?? null )
		&& 'status' === ( $show_column->wpdb_state()['last_result'][0]->Field ?? null ),
	'full column introspection exposes the charset metadata WordPress reads for registered schemas' => 'utf8mb4_general_ci' === ( $show_full_columns->wpdb_state()['last_result'][2]->Collation ?? null )
		&& null === ( $show_full_columns->wpdb_state()['last_result'][0]->Collation ?? null )
		&& 'select,insert,update,references' === ( $show_full_columns->wpdb_state()['last_result'][2]->Privileges ?? null )
		&& array( 'Field', 'Type', 'Collation', 'Null', 'Key', 'Default', 'Extra', 'Privileges', 'Comment' ) === array_map( static fn( object $column ): string => $column->name, $show_full_columns->wpdb_state()['col_info'] ),
	'full column introspection keeps missing physical tables as errors' => false === $show_full_missing->return_value()
		&& 'unsupported_table' === ( $show_full_missing->diagnostic()['reason'] ?? null ),
	'generic index introspection preserves names, order, uniqueness, and prefix lengths' => array( 'PRIMARY', 'owner_id' ) === array_map(
		static fn( object $row ): string => $row->Key_name,
		$show_indexes->wpdb_state()['last_result']
	)
		&& array( '0', '1' ) === array_map( static fn( object $row ): string => $row->Non_unique, $show_indexes->wpdb_state()['last_result'] ),
	'bounded information_schema reads derive column metadata from registered DDL' => array( 'wp_plugin_jobs', 'wp_plugin_jobs', 'wp_plugin_jobs', 'wp_inline_items', 'wp_inline_items' ) === array_map( static fn( object $row ): string => $row->TABLE_NAME, $information_columns->wpdb_state()['last_result'] )
		&& array( 'id', 'owner_id', 'status', 'id', 'value' ) === array_map( static fn( object $row ): string => $row->COLUMN_NAME, $information_columns->wpdb_state()['last_result'] )
		&& 'PRI' === ( $information_columns->wpdb_state()['last_result'][0]->COLUMN_KEY ?? null )
		&& '32' === ( $information_columns->wpdb_state()['last_result'][2]->CHARACTER_MAXIMUM_LENGTH ?? null )
		&& null === ( $information_columns->wpdb_state()['last_result'][0]->CHARACTER_MAXIMUM_LENGTH ?? null )
		&& array( 253, 253, 8, 8, 253, 253, 251, 253, 253, 253 ) === array_map( static fn( object $column ): int => $column->type, $information_columns->wpdb_state()['col_info'] ),
	'information_schema predicates preserve schema equality and AND intersections' => 0 === $absent_information_schema->return_value()
		&& 0 === $contradictory_information_tables->return_value()
		&& 0 === $contradictory_information_columns->return_value(),
	'information_schema does not manufacture a transactional storage engine' => false === $information_engine->return_value()
		&& 'unsupported_column' === ( $information_engine->diagnostic()['reason'] ?? null ),
	'information_schema catalog scans remain fail-closed without a bounded table name' => false === $unbounded_information->return_value()
		&& 'unsupported_lookup' === ( $unbounded_information->diagnostic()['reason'] ?? null ),
	'information_schema reports TEXT character maxima and bounds list cardinality' => array( 'task_url' => '65535', 'payload' => '4294967295' ) === array_reduce( $text_information->wpdb_state()['last_result'], static function ( array $values, object $row ): array { $values[ $row->COLUMN_NAME ] = $row->CHARACTER_MAXIMUM_LENGTH; return $values; }, array() )
		&& false === $overwide_information->return_value()
		&& 'resource_limit' === ( $overwide_information->diagnostic()['reason'] ?? null ),
	'a materialized snapshot scans a bounded unindexed text equality' => 1 === $limited_residual->return_value()
		&& '2' === (string) ( $limited_residual->wpdb_state()['last_result'][0]->id ?? '' ),
	'primary and secondary numeric indexes derive bounded lookup capabilities' => array( '1', '2' ) === array_map(
		static fn( object $row ): string => $row->id,
		$secondary->wpdb_state()['last_result']
	),
	'mixed SQLite integers and MySQL numeric strings share deterministic natural order' => array( '1', '2' ) === array_map(
		static fn( object $row ): string => $row->id,
		$unfiltered->wpdb_state()['last_result']
	),
	'generated plugin metadata preserves projection order and MySQL field types' => array( 253, 8 ) === array_map(
		static fn( object $column ): int => $column->type,
		$exact->wpdb_state()['col_info']
	),
	'ASCII text equality scans a materialized snapshot with its declared collation' => 0 === $string_filter->return_value()
		&& array() === $string_filter->wpdb_state()['last_result'],
	'unknown string collation ordering fails closed' => false === $string_order->return_value()
		&& 'unsupported_order' === ( $string_order->diagnostic()['reason'] ?? null ),
	'ASCII text equality composes with explicit LOWER equality across columns' => array( '2', '10' ) === array_map(
		static fn( object $row ): string => $row->id,
		$lower_cross_filter->wpdb_state()['last_result']
	),
	'schemas without a numeric primary identity remain unsupported' => false === $no_identity->return_value(),
	'composite numeric plugin identities execute without table-specific code' => array( '7', '9' ) === array_map(
		static fn( object $row ): string => $row->right_id,
		$composite->wpdb_state()['last_result']
	),
	'unsupported DDL, mismatched names, and malformed neighbors do not weaken valid tables' => false === $unsupported->return_value()
		&& false === $mismatch->return_value()
		&& 1 === $exact->return_value(),
	'SQLite inline integer primary keys normalize into the generic execution contract' => 'portable' === ( $inline->wpdb_state()['last_result'][0]->value ?? null ),
	'ephemeral plugin schemas and snapshots do not register in the native runtime' => false === $ephemeral_native->return_value()
		&& 'unsupported_table' === ( $ephemeral_native->diagnostic()['reason'] ?? null ),
	'partitioned plugin tables compose lookup, residual filter, ordering, and limit execution' => 1 === $partitioned->return_value()
		&& 'ready' === ( $partitioned->wpdb_state()['last_result'][0]->status ?? null )
		&& '1' === ( $partitioned->wpdb_state()['last_result'][0]->id ?? null ),
	'partitioned plugin tables compose exact count execution' => '2' === ( $partition_count->wpdb_state()['last_result'][0]->{'COUNT(*)'} ?? null ),
	'partitioned plugin tables scan active canonical generations and reject incompatible identity markers' => array( '1', '2' ) === array_map(
		static fn( object $row ): string => $row->id,
		$partition_scan->wpdb_state()['last_result']
	)
		&& false === $partition_mismatch->return_value()
		&& 'unsupported_table' === ( $partition_mismatch->diagnostic()['reason'] ?? null ),
	'invalid and linked partition markers fail closed during composition' => false === $partition_invalid->return_value()
		&& 'unsupported_table' === ( $partition_invalid->diagnostic()['reason'] ?? null )
		&& ( ! $linked_marker || ( false === $partition_linked->return_value()
			&& 'unsupported_table' === ( $partition_linked->diagnostic()['reason'] ?? null ) ) ),
	'cross-backend numeric representations cannot duplicate one natural identity' => false === $duplicate_identity->return_value()
		&& 'duplicate_natural_identity' === ( $duplicate_identity->diagnostic()['reason'] ?? null ),
	'linked persisted schemas fail closed' => ! $linked || ( false === $linked_result->return_value()
		&& 'unsupported_table' === ( $linked_result->diagnostic()['reason'] ?? null ) ),
);

$failed = false;
foreach ( $checks as $label => $passed ) {
	fwrite( $passed ? STDOUT : STDERR, ( $passed ? 'PASS' : 'FAIL' ) . ": {$label}\n" );
	$failed = $failed || ! $passed;
}

mdi_plugin_schema_remove_tree( $root );
@unlink( $outside );
@unlink( $outside_marker );
exit( $failed ? 1 : 0 );
