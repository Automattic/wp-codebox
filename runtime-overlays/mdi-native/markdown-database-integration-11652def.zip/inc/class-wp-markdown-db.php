<?php
/**
 * Markdown Database — wpdb override.
 *
 * Extends WP_SQLite_DB to:
 * - Use persistent on-disk SQLite as the index/query engine
 * - Load all data from markdown/JSON files on cold boot
 * - Serve the last complete index on warm boot
 * - Persist all writes back to markdown/JSON files
 *
 * Boot modes:
 *   Cold boot: SQLite file doesn't exist → full load from disk
 *   Warm boot: SQLite file exists → bounded read-only attach
 *
 * @package Markdown_Database_Integration
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-backend-capabilities.php';
require_once __DIR__ . '/class-wp-markdown-query-observer-boundary.php';
require_once __DIR__ . '/class-wp-markdown-primary-index-health.php';

class WP_Markdown_DB extends WP_SQLite_DB {

	/**
	 * The boot loader (null until boot completes).
	 *
	 * @var WP_Markdown_Loader|null
	 */
	private $loader = null;

	/** @var WP_Markdown_Backend_Capabilities */
	private $backend_capabilities;

	/**
	 * Deferred primary loader action, if the table prefix is not ready yet.
	 *
	 * @var string|null 'load_all' or 'sync_incremental'.
	 */
	private $deferred_primary_loader_action = null;
	private string $primary_runtime_identity = '';
	private ?WP_Markdown_Write_Engine $write_engine = null;
	private ?WP_Markdown_Primary_Index_Evidence $primary_index_evidence = null;

	private mixed $native_shadow_verifier = null;

	public function set_native_shadow_verifier( mixed $verifier ): void {
		if ( ! is_object( $verifier ) || ! method_exists( $verifier, 'observe' ) ) {
			throw new InvalidArgumentException( 'The native shadow verifier must observe authoritative queries.' );
		}
		$this->native_shadow_verifier = $verifier;
	}

	public function query( $query ) {
		$queries_before = (int) $this->num_queries;
		$result = parent::query( $query );
		if ( (int) $this->num_queries > $queries_before ) {
			$effective_query = is_string( $this->last_query ) && '' !== $this->last_query
				? $this->last_query
				: (string) $query;
			WP_Markdown_Query_Observer_Boundary::observe( $this->native_shadow_verifier, $effective_query, $result, $this );
		}
		return $result;
	}

	/**
	 * Connects to the database.
	 *
	 * In 'primary' mode: uses a persistent on-disk SQLite file as the index.
	 * On cold boot (no file), does a full load from markdown/JSON files.
	 * On warm boot (file exists), attaches the last complete index without
	 * entering reconciliation. An explicit maintenance owner synchronizes it.
	 *
	 * In 'mirror' mode: uses the standard on-disk SQLite file and mirrors
	 * writes to markdown files.
	 *
	 * @param bool $allow_bail Not used.
	 * @return void
	 */
	public function db_connect( $allow_bail = true ) {
		if ( $this->dbh ) {
			return;
		}
		$this->init_charset();

		$pdo = null;
		if ( isset( $GLOBALS['@pdo'] ) ) {
			$pdo = $GLOBALS['@pdo'];
		}

		if ( null === $this->dbname || '' === $this->dbname ) {
			$this->bail(
				'The database name was not set.',
				'db_connect_fail'
			);
			return false;
		}

		$mode = defined( 'MARKDOWN_DB_MODE' ) ? MARKDOWN_DB_MODE : 'mirror';
		if ( ! function_exists( 'markdown_db_default_content_dir' ) ) {
			require_once __DIR__ . '/markdown-db-paths.php';
		}

		// Determine the SQLite path.
		if ( 'primary' === $mode ) {
			// Persistent on-disk SQLite — the index file.
			// Stored alongside the content directory for co-location.
			$content_dir_for_path = defined( 'MARKDOWN_DB_CONTENT_DIR' )
				? MARKDOWN_DB_CONTENT_DIR
				: markdown_db_default_content_dir();
			$state_dir_for_path = defined( 'MARKDOWN_DB_STATE_DIR' )
				? MARKDOWN_DB_STATE_DIR
				: $content_dir_for_path;
			$db_path = defined( 'MARKDOWN_DB_INDEX_PATH' )
				? MARKDOWN_DB_INDEX_PATH
				: ( function_exists( 'markdown_database_integration_primary_index_path' )
					? markdown_database_integration_primary_index_path( $content_dir_for_path, $state_dir_for_path )
					: ( rtrim( $state_dir_for_path, '/\\' ) !== rtrim( $content_dir_for_path, '/\\' )
						? rtrim( $state_dir_for_path, '/\\' ) . '/markdown-index.sqlite'
						: dirname( rtrim( $content_dir_for_path, '/\\' ) ) . '/markdown-index.sqlite' ) );
			$db_path = $this->resolve_primary_database_path( $db_path );
			$this->ensure_directory_exists( dirname( $db_path ) );
			// Don't reuse any existing PDO — we need our own connection.
			$pdo = null;
		} else {
			// Phase 1 / mirror: use on-disk SQLite file.
			$db_path = FQDB;
			$this->ensure_database_directory_exists();
		}

		// Create the markdown storage engine.
		$content_dir = defined( 'MARKDOWN_DB_CONTENT_DIR' )
			? MARKDOWN_DB_CONTENT_DIR
			: markdown_db_default_content_dir();
		$state_dir = defined( 'MARKDOWN_DB_STATE_DIR' )
			? MARKDOWN_DB_STATE_DIR
			: $content_dir;

		// Excluded post types — everything else is stored as markdown.
		$excluded_types_raw = defined( 'MARKDOWN_DB_EXCLUDED_TYPES' )
			? MARKDOWN_DB_EXCLUDED_TYPES
			: '';

		$excluded_types = array_filter( array_map( 'trim', explode( ',', $excluded_types_raw ) ) );

		$storage = new WP_Markdown_Storage( $content_dir, $excluded_types );
		if ( method_exists( $storage, 'set_content_layout_profile' ) ) {
			$storage->set_content_layout_profile( defined( 'MARKDOWN_DB_CONTENT_LAYOUT_PROFILE' ) ? MARKDOWN_DB_CONTENT_LAYOUT_PROFILE : '' );
		}

		// Primary mode: atomic index build to prevent concurrent boot races.
		// See GitHub issue #50.
		//
		// The index file (.sqlite) is the signal for warm vs cold boot.
		// Cold boot builds into a temp file, then renames atomically.
		// Other workers either see the complete file (warm boot) or no
		// file (wait for build to finish, then warm boot).
		if ( 'primary' === $mode ) {
			$this->boot_primary( $db_path, $content_dir, $state_dir, $storage );
		} else {
			try {
				$this->boot_connection( $db_path, $pdo, $mode, false, $content_dir, $state_dir, $storage );
			} catch ( \Throwable $e ) {
				$this->last_error = $e->getMessage();
				error_log( 'Markdown DB connect error: ' . $e->getMessage() . "\n" . $e->getTraceAsString() );
			}
		}

		if ( $this->last_error ) {
			if ( 'primary' === $mode ) {
				$this->bail( $this->last_error, 'db_connect_fail' );
			}
			return false;
		}

		$this->ready = true;
		// The legacy adapter materializes query results before wpdb can inspect them.
		if ( ! defined( 'MARKDOWN_DB_SQLITE_LEGACY_RESULT_API' ) || ! MARKDOWN_DB_SQLITE_LEGACY_RESULT_API ) {
			$this->set_sql_mode();
		}
	}

	/**
	 * Boot the database connection, write engine, resolvers, and loader.
	 *
	 * Extracted from db_connect() so it can be retried on corruption.
	 * See GitHub issue #46.
	 *
	 * @param string              $db_path       Path to the SQLite file.
	 * @param \PDO|null           $pdo           Existing PDO connection (null for fresh).
	 * @param string              $mode          Operating mode ('primary' or 'mirror').
	 * @param bool                $is_warm_boot  Whether the SQLite file already exists.
	 * @param string              $content_dir   Path to the markdown content directory.
	 * @param string              $state_dir     Path to the runtime state directory.
	 * @param WP_Markdown_Storage $storage       The markdown storage engine.
	 */
	private function boot_connection(
		string $db_path,
		?\PDO $pdo,
		string $mode,
		bool $is_warm_boot,
		string $content_dir,
		string $state_dir,
		WP_Markdown_Storage $storage
	): void {
		$this->primary_runtime_identity = $db_path;
		$this->backend_capabilities = WP_Markdown_Backend_Resolver::resolve();
		if ( class_exists( 'WP_Markdown_SQLite_Runtime_Adapter' ) ) {
			$this->dbh = WP_Markdown_SQLite_Runtime_Adapter::create_runtime( $db_path, $pdo, $this->dbname, $storage, $this->backend_capabilities, 'primary' === $mode && $is_warm_boot );
		} else {
			// Isolated bootstrap consumers may inject the historical driver facade.
			$connection = new WP_SQLite_Connection( array( 'pdo' => $pdo, 'path' => $db_path, 'journal_mode' => defined( 'SQLITE_JOURNAL_MODE' ) ? SQLITE_JOURNAL_MODE : null ) );
			$this->dbh = new WP_Markdown_Driver( $connection, $this->dbname, $storage );
		}
		$GLOBALS['@pdo'] = $this->dbh->get_connection()->get_pdo();

		// Resolve the table prefix.
		//
		// IMPORTANT: in some boot paths (wp-phpunit / homeboy bench
		// dispatcher / any caller where wp-config.php sets $table_prefix
		// as a local variable instead of a global), $table_prefix is
		// NULL at this moment. The fallback to 'wp_' would then bake the
		// wrong prefix into every table name the loader creates,
		// breaking every WordPress query that uses the canonical prefix
		// (e.g. wptests_*). See GitHub issue #77.
		//
		// Instead of capturing the prefix as a value at construct time,
		// we use a closure that resolves the current prefix at call
		// time. By the time anything actually USES the prefix (a
		// resolver query, a write_engine call, the loader's table
		// creation), $table_prefix is set globally even in the
		// pathological boot paths.
		$prefix_resolver = static function (): string {
			global $table_prefix, $wpdb;
			if ( isset( $table_prefix ) && '' !== $table_prefix ) {
				return $table_prefix;
			}
			if ( isset( $wpdb ) && '' !== $wpdb->prefix ) {
				return $wpdb->prefix;
			}
			return 'wp_';
		};

		// Set up the write engine. Pass the resolver so the engine
		// re-reads the prefix on every method call instead of baking
		// the boot-time value (which may be NULL in test boots).
		$adapter_runtime = method_exists( $this->dbh, 'operations' );
		$operations = $adapter_runtime ? $this->dbh->operations( $prefix_resolver ) : $this->dbh;
		$reconciliation = function_exists( 'wp_markdown_durable_reconciliation_coordinator' ) ? wp_markdown_durable_reconciliation_coordinator( array( $content_dir, $state_dir ) ) : null;
		$write_engine = new WP_Markdown_Write_Engine(
			$content_dir,
			$storage,
			$operations,
			$prefix_resolver,
			$state_dir,
			$reconciliation
		);
		$this->write_engine = $write_engine;
		$this->dbh->set_write_engine( $write_engine, 'primary' !== $mode || ! $is_warm_boot );

		// Set up the post resolver so the storage engine can build
		// hierarchical directory paths. See GitHub issue #14.
		$driver_ref = $this->dbh;
		$storage->set_post_resolver( function ( int $post_id ) use ( $driver_ref, $prefix_resolver ) {
			$table = $prefix_resolver() . 'posts';
			try {
				$result = $driver_ref->query(
					"SELECT post_name, post_parent, post_type FROM `{$table}` WHERE ID = {$post_id}"
				);
				$rows = is_array( $result ) ? $result : $result->fetchAll( \PDO::FETCH_OBJ );
				if ( ! empty( $rows ) ) {
					return $rows[0];
				}
			} catch ( \Throwable $e ) {
				// Silently fail — the write engine will use a flat path.
			}
			return null;
		} );

		// Meta resolver — fetches all post meta for a given post ID.
		// Used by build_frontmatter() to embed meta in .md files. See issue #6.
		if ( $adapter_runtime ) {
			$storage->set_meta_resolver( static fn( int $post_id ): array => $operations->post_meta( $post_id ) );
		} else {
			$storage->set_meta_resolver( static function ( int $post_id ) use ( $driver_ref, $prefix_resolver ): array {
				try {
					$result = $driver_ref->query( 'SELECT meta_key, meta_value FROM `' . $prefix_resolver() . 'postmeta` WHERE post_id = ' . $post_id );
					return is_array( $result ) ? $result : $result->fetchAll( \PDO::FETCH_OBJ );
				} catch ( \Throwable $e ) { return array(); }
			} );
		}

		// Terms resolver — fetches all terms for a given post ID.
		// Used by build_frontmatter() to embed terms in .md files. See issue #6.
		if ( $adapter_runtime ) {
			$storage->set_terms_resolver( static fn( int $post_id ): array => $operations->post_terms( $post_id ) );
		} else {
			$storage->set_terms_resolver( static function ( int $post_id ) use ( $driver_ref, $prefix_resolver ): array {
				try {
					$prefix = $prefix_resolver();
					$result = $driver_ref->query( "SELECT tt.taxonomy, t.slug FROM `{$prefix}term_relationships` tr JOIN `{$prefix}term_taxonomy` tt ON tr.term_taxonomy_id = tt.term_taxonomy_id JOIN `{$prefix}terms` t ON tt.term_id = t.term_id WHERE tr.object_id = {$post_id}" );
					return is_array( $result ) ? $result : $result->fetchAll( \PDO::FETCH_OBJ );
				} catch ( \Throwable $e ) { return array(); }
			} );
		}

		// Index writer — upserts `_markdown_file_index` when storage renames
		// a file as a side effect of another write. Without this hook,
		// resolve_parent_dir's promotion of a leaf file to `index.md`
		// leaves the index row pointing at a path that no longer exists,
		// and warm boot churns the promoted post through a full delete
		// and reinsert on every sync. See GitHub issue #68.
		$storage->set_index_writer( $adapter_runtime
			? static fn( int $post_id, string $relative_path, int $mtime, int $size ) => $operations->upsert_file_index( $post_id, $relative_path, $mtime, $size )
			: static fn( int $post_id, string $relative_path, int $mtime, int $size ) => $driver_ref->update_file_index( $post_id, $relative_path, $mtime, $size ) );

		// In primary mode, load or sync data.
		//
		if ( 'primary' === $mode ) {
			$this->loader = new WP_Markdown_Loader(
				$content_dir,
				$operations,
				$storage,
				$prefix_resolver,
				$state_dir,
				$reconciliation
			);

			$loader_action = $is_warm_boot ? 'sync_incremental' : 'load_all';
			if ( $this->has_resolved_table_prefix() ) {
				$this->run_primary_loader_action( $loader_action );
			} else {
				$this->deferred_primary_loader_action = $loader_action;
			}
		}

		if ( 'primary' === $mode && $is_warm_boot && method_exists( $this->dbh, 'finish_warm_bootstrap' ) ) {
			$this->dbh->finish_warm_bootstrap();
		}
	}

	/**
	 * Sets the table prefix and runs any deferred primary-mode loader work.
	 *
	 * In wp-phpunit-style boots, the drop-in connects before $table_prefix is
	 * global. WordPress calls set_prefix() shortly after require_wp_db(); that is
	 * the earliest safe point to create/sync prefixed tables.
	 *
	 * @param string $prefix          Table prefix.
	 * @param bool   $set_table_names Whether to update table name properties.
	 * @return string|WP_Error Old prefix or WP_Error, matching wpdb::set_prefix().
	 */
	public function set_prefix( $prefix, $set_table_names = true ) {
		$result = parent::set_prefix( $prefix, $set_table_names );
		$this->run_deferred_primary_loader();
		return $result;
	}

	/**
	 * Whether WordPress has finalized a usable table prefix.
	 *
	 * @return bool True when a real prefix is available.
	 */
	private function has_resolved_table_prefix(): bool {
		global $table_prefix;

		if ( isset( $table_prefix ) && '' !== $table_prefix ) {
			return true;
		}

		return isset( $this->prefix ) && '' !== $this->prefix;
	}

	/**
	 * Run deferred primary-mode loader work once the prefix is ready.
	 */
	private function run_deferred_primary_loader(): void {
		if ( null === $this->deferred_primary_loader_action || ! $this->has_resolved_table_prefix() ) {
			return;
		}

		$action = $this->deferred_primary_loader_action;
		$this->deferred_primary_loader_action = null;
		$this->run_primary_loader_action( $action );
	}

	/**
	 * Run the requested primary loader action.
	 *
	 * @param string $action 'load_all' or 'sync_incremental'.
	 */
	private function run_primary_loader_action( string $action ): void {
		if ( null === $this->loader ) {
			return;
		}

		if ( 'sync_incremental' === $action ) {
			$this->loader->retain_previous_index( 'deferred_synchronization' );
			return;
		}

		$this->backend_capabilities->require( 'disposable_index_operation' );
		$this->backend_capabilities->require( 'cold_reconstruction' );
		$this->loader->load_all();
	}

	/** Synchronize a warm primary index from an explicit maintenance boundary. */
	public function synchronize_primary_index(): bool {
		if ( null === $this->loader || 'primary' !== ( defined( 'MARKDOWN_DB_MODE' ) ? MARKDOWN_DB_MODE : 'mirror' ) ) {
			return false;
		}

		$this->backend_capabilities->require( 'disposable_index_operation' );
		$recover_pending = function (): void {
			if ( null !== $this->write_engine && method_exists( $this->write_engine, 'recover_pending' ) ) {
				$this->write_engine->recover_pending();
			}
		};
		return $this->loader->sync_incremental_if_available( (string) $this->dbname . "\0" . $this->primary_runtime_identity, $recover_pending );
	}

	/**
	 * Boot in primary mode with isolated cold boot.
	 *
	 * Each worker builds its index independently — no shared writes.
	 *
	 * Warm boot: index file exists → connect without inline reconciliation.
	 * Cold boot: index file doesn't exist → build into a private temp
	 *   file (unique per worker), then rename atomically into place.
	 *   If rename fails (another worker beat us), discard our temp file
	 *   and warm-boot from theirs.
	 *
	 * This avoids all cross-worker coordination. Concurrent cold boots
	 * each build independently, the first rename wins, losers discard
	 * their work. No locking, no sentinels, no shared SQLite writes.
	 *
	 * See GitHub issue #50.
	 *
	 * @param string              $db_path     Path to the final SQLite index file.
	 * @param string              $content_dir Path to the markdown content directory.
	 * @param string              $state_dir   Path to the runtime state directory.
	 * @param WP_Markdown_Storage $storage     The markdown storage engine.
	 */
	private function boot_primary(
		string $db_path,
		string $content_dir,
		string $state_dir,
		WP_Markdown_Storage $storage
	): void {
		$deadline_ms = defined( 'MARKDOWN_DB_PRIMARY_BOOTSTRAP_DEADLINE_MS' )
			? max( 1, (int) MARKDOWN_DB_PRIMARY_BOOTSTRAP_DEADLINE_MS )
			: 500;
		$started = hrtime( true );
		$attempted_existing = false;
		$last_evidence = null;
		$recovery_evidence = null;

		// Warm boot only attaches an already-published generation. It never scans
		// canonical files, recovers pending work, deletes an index, or rebuilds.
		foreach ( array( $db_path => false, $db_path . '.previous' => true ) as $candidate => $previous ) {
			$probe = WP_Markdown_Primary_Index_Evidence::probe( $candidate, $deadline_ms );
			if ( 'missing' === $probe->status() ) {
				continue;
			}
			$attempted_existing = true;
			$last_evidence = $probe;
			if ( ! $probe->is_ready() ) {
				if ( ! $previous ) {
					$recovery_evidence = $probe;
				}
				continue;
			}
			try {
				$this->boot_connection( $candidate, null, 'primary', true, $content_dir, $state_dir, $storage );
				$elapsed_ms = (int) ceil( ( hrtime( true ) - $started ) / 1000000 );
				if ( $elapsed_ms > $deadline_ms ) {
					throw new RuntimeException( 'Primary index attachment exceeded its bootstrap deadline.' );
				}
				$this->publish_primary_index_evidence( WP_Markdown_Primary_Index_Evidence::attached( $probe, $previous, $recovery_evidence ) );
				return;
			} catch ( \Throwable $e ) {
				$last_evidence = WP_Markdown_Primary_Index_Evidence::failed( $probe, $e );
				if ( ! $previous ) {
					$recovery_evidence = $last_evidence;
				}
				$this->dbh        = null;
				$this->last_error = '';
				$this->loader     = null;
				$this->write_engine = null;
			}
		}

		if ( $attempted_existing ) {
			$this->publish_primary_index_evidence( $last_evidence );
			$this->last_error = $last_evidence->operator_message();
			return;
		}

		// --- Cold boot: build into a private temp file ---
		//
		// Each worker gets its own temp file (unique suffix). Multiple
		// workers may build simultaneously — that's fine, they don't
		// share a file. The first to finish renames into place.
		$tmp_path = $db_path . '.tmp.' . getmypid() . '.' . substr( md5( uniqid( '', true ) ), 0, 8 );

		try {
			$this->boot_connection( $tmp_path, null, 'primary', false, $content_dir, $state_dir, $storage );

			// Checkpoint WAL so the temp file is self-contained.
			if ( method_exists( $this->dbh, 'checkpoint' ) ) {
				$this->dbh->checkpoint();
			} else {
				$this->dbh->get_connection()->get_pdo()->exec( 'PRAGMA wal_checkpoint(TRUNCATE)' );
			}

			// Check: did another worker finish first?
			if ( file_exists( $db_path ) ) {
				// Someone beat us. Discard our temp file, use theirs.
				$this->dbh        = null;
				$this->last_error = '';
				$this->loader     = null;
				try {
					$this->boot_connection( $db_path, null, 'primary', true, $content_dir, $state_dir, $storage );
					$this->cleanup_index_files( $tmp_path );
					$this->publish_primary_index_evidence( WP_Markdown_Primary_Index_Evidence::attached( WP_Markdown_Primary_Index_Evidence::probe( $db_path, $deadline_ms ) ) );
					return;
				} catch ( \Throwable $e ) {
					// Their file is bad too? Keep it until our complete candidate can
					// replace it atomically; never create an empty authority window.
					error_log( 'Markdown DB: Rival index unreadable (' . $e->getMessage() . '). Using ours.' );
					$this->dbh        = null;
					$this->last_error = '';
					$this->loader     = null;
					$this->write_engine = null;
					// Re-build connection to our temp file for the rename below.
					$this->boot_connection( $tmp_path, null, 'primary', true, $content_dir, $state_dir, $storage );
				}
			}

			// Atomic swap: rename our temp file into place.
			// The open PDO connection follows the inode, not the path,
			// so it keeps working after rename. No reconnect needed.
			$renamed = @rename( $tmp_path, $db_path );

			// Also move any leftover WAL/journal files.
			if ( file_exists( $tmp_path . '-wal' ) ) {
				@rename( $tmp_path . '-wal', $db_path . '-wal' );
			}
			if ( file_exists( $tmp_path . '-shm' ) ) {
				@rename( $tmp_path . '-shm', $db_path . '-shm' );
			}

			if ( ! $renamed ) {
				// Rename failed — another worker likely beat us.
				// Discard our connection and use the winner's index.
				$this->dbh        = null;
				$this->last_error = '';
				$this->loader     = null;
				$this->cleanup_index_files( $tmp_path );

				$this->boot_connection( $db_path, null, 'primary', true, $content_dir, $state_dir, $storage );
			}
			$this->publish_primary_index_evidence( WP_Markdown_Primary_Index_Evidence::cold_complete( $db_path, $deadline_ms ) );
			// If rename succeeded, we keep our existing connection — it's
			// already fully loaded from the cold boot above.

		} catch ( \Throwable $e ) {
			// Build failed — clean up.
			$this->cleanup_index_files( $tmp_path );
			$this->dbh    = null;
			$this->loader = null;
			$this->write_engine = null;
			if ( $e instanceof WP_Markdown_Loader_Exception ) {
				$GLOBALS['markdown_db_primary_bootstrap_diagnostic'] = $e->diagnostic();
				$this->last_error = $e->operator_message();
			} else {
				$this->last_error = $e->getMessage();
			}
			error_log( 'Markdown DB: Cold boot failed: ' . $this->last_error . "\n" . $e->getTraceAsString() );
		}
	}

	private function publish_primary_index_evidence( WP_Markdown_Primary_Index_Evidence $evidence ): void {
		$this->primary_index_evidence = $evidence;
		$GLOBALS['markdown_db_primary_index_evidence'] = $evidence->diagnostic();
	}

	/**
	 * Resolve the writable SQLite index path for primary mode.
	 *
	 * Markdown files are the durable database in primary mode; the SQLite index is
	 * runtime query state. When the markdown store is mounted read-only, such as a
	 * WordPress Playground plugin mount, keep the index in PHP's temp directory.
	 *
	 * @param string $db_path Preferred SQLite index path.
	 * @return string Writable SQLite index path.
	 */
	private function resolve_primary_database_path( string $db_path ): string {
		$dir = dirname( $db_path );
		if ( ! $this->is_playground_runtime() && is_dir( $dir ) && is_writable( $dir ) ) {
			return $db_path;
		}

		$temp_dir = rtrim( sys_get_temp_dir(), '/\\' );
		$hash     = substr( md5( $db_path ), 0, 12 );

		return $temp_dir . '/markdown-index-' . $hash . '.sqlite';
	}

	/**
	 * Whether this request is running inside WordPress Playground.
	 *
	 * Playground mounts plugin directories through a VFS layer where PHP file
	 * writes may appear available, but SQLite write transactions can fail as
	 * read-only. Keep runtime indexes in PHP temp there.
	 *
	 * @return bool True when running in WordPress Playground.
	 */
	private function is_playground_runtime(): bool {
		return defined( 'MARKDOWN_DB_PLAYGROUND_RUNTIME' ) && MARKDOWN_DB_PLAYGROUND_RUNTIME;
	}

	/**
	 * Delete a SQLite file and its associated journal/WAL files.
	 *
	 * @param string $path Path to the SQLite file.
	 */
	private function cleanup_index_files( string $path ): void {
		@unlink( $path );
		@unlink( $path . '-wal' );
		@unlink( $path . '-shm' );
		@unlink( $path . '-journal' );
	}

	/**
	 * Get the boot loader (for debugging/timing).
	 *
	 * @return WP_Markdown_Loader|null
	 */
	public function get_loader(): ?WP_Markdown_Loader {
		return $this->loader;
	}

	/** @return array<string,mixed>|null */
	public function get_primary_index_evidence(): ?array {
		return null === $this->primary_index_evidence ? null : $this->primary_index_evidence->diagnostic();
	}

	/** @return array{created:string[],changed:string[],deleted:string[]} Canonical paths flushed at an explicit long-lived request boundary. */
	public function flush_canonical_writes(): array {
		if ( method_exists( $this->dbh, 'flush_canonical_writes' ) ) {
			return $this->dbh->flush_canonical_writes();
		}
		return array( 'created' => array(), 'changed' => array(), 'deleted' => array() );
	}

	/**
	 * Ensure a directory exists.
	 *
	 * @param string $dir Directory path.
	 */
	private function ensure_directory_exists( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			$umask = umask( 0 );
			@mkdir( $dir, 0755, true );
			umask( $umask );
		}
	}

	/**
	 * Ensure the SQLite database directory exists with protections.
	 */
	private function ensure_database_directory_exists(): void {
		$dir = dirname( FQDB );
		$this->ensure_directory_exists( $dir );

		// .htaccess protection.
		$htaccess = $dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, 'DENY FROM ALL', LOCK_EX );
		}

		// index.php protection.
		$index = $dir . '/index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, '<?php // Silence is gold. ?>', LOCK_EX );
		}
	}
}
