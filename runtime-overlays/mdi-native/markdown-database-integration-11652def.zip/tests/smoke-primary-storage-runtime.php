<?php
/**
 * Smoke coverage for the constrained primary runtime.
 *
 * Usage: php tests/smoke-primary-storage-runtime.php
 */

declare( strict_types=1 );

define( 'ABSPATH', __DIR__ . '/' );
require_once dirname( __DIR__ ) . '/vendor/autoload.php';

class WP_SQLite_Connection {
	public function __construct( private PDO $pdo ) {}
	public function get_pdo(): PDO { return $this->pdo; }
}

class WP_MySQL_On_SQLite {
	/** @var string[] */
	public array $queries = array();
	public bool $fail_status_queries = false;
	private WP_SQLite_Connection $connection;
	private bool $in_transaction = false;
	public function __construct( string $dsn, ?string $username = null, ?string $password = null, array $options = array() ) {
		unset( $dsn, $username, $password );
		$this->connection = new WP_SQLite_Connection( $options['pdo'] );
	}
	public function get_connection(): WP_SQLite_Connection { return $this->connection; }
	public function get_insert_id(): int { return (int) $this->connection->get_pdo()->lastInsertId(); }
	public function beginTransaction(): bool { $this->connection->get_pdo()->beginTransaction(); $this->in_transaction = true; return true; }
	public function commit(): bool { $this->connection->get_pdo()->commit(); $this->in_transaction = false; return true; }
	public function rollBack(): bool { $this->connection->get_pdo()->rollBack(); $this->in_transaction = false; return true; }
	public function inTransaction(): bool { return $this->in_transaction; }
	public function query( string $sql, $fetch_mode = PDO::FETCH_OBJ, ...$args ) {
		unset( $args );
		$this->queries[] = $sql;
		if ( $this->fail_status_queries && str_contains( $sql, 'SELECT post_status FROM' ) ) {
			throw new RuntimeException( 'Simulated status lookup failure.' );
		}
		$wrap = ! $this->in_transaction && 1 === preg_match( '/^\s*(?:INSERT|UPDATE|DELETE|REPLACE|CREATE|ALTER|DROP)\b/i', $sql );
		if ( $wrap ) { $this->connection->get_pdo()->beginTransaction(); }
		try {
			$result = $this->connection->get_pdo()->query( $sql );
			if ( $wrap ) { $this->connection->get_pdo()->commit(); }
			return $result;
		} catch ( Throwable $error ) {
			if ( $wrap && $this->connection->get_pdo()->inTransaction() ) { $this->connection->get_pdo()->rollBack(); }
			throw $error;
		}
	}
}

function apply_filters( string $hook, mixed $value, mixed ...$args ): mixed { unset( $hook, $args ); return $value; }
function do_action( string $hook, mixed ...$args ): void { $GLOBALS['mdi_runtime_actions'][ $hook ][] = $args; }

class MDI_Runtime_WPDB {
	public string $prefix = 'wp_';
	public function set_prefix( string $prefix ): string { $this->prefix = $prefix; return $prefix; }
}
$GLOBALS['wpdb'] = new MDI_Runtime_WPDB();
function wp_get_db_schema(): string {
	$prefix = $GLOBALS['wpdb']->prefix;
	return implode( ';', array(
		"CREATE TABLE {$prefix}posts (ID INTEGER PRIMARY KEY, post_author INTEGER, post_date TEXT, post_date_gmt TEXT, post_content TEXT, post_title TEXT, post_excerpt TEXT, post_status TEXT, comment_status TEXT, ping_status TEXT, post_password TEXT, post_name TEXT, to_ping TEXT, pinged TEXT, post_modified TEXT, post_modified_gmt TEXT, post_content_filtered TEXT, post_parent INTEGER, guid TEXT, menu_order INTEGER, post_type TEXT, post_mime_type TEXT, comment_count INTEGER)",
		"CREATE TABLE {$prefix}options (option_id INTEGER PRIMARY KEY, option_name TEXT UNIQUE, option_value TEXT, autoload TEXT)",
		"CREATE TABLE {$prefix}users (ID INTEGER PRIMARY KEY, user_login TEXT, user_pass TEXT)",
		"CREATE TABLE {$prefix}usermeta (umeta_id INTEGER PRIMARY KEY, user_id INTEGER, meta_key TEXT, meta_value TEXT)",
		"CREATE TABLE {$prefix}postmeta (meta_id INTEGER PRIMARY KEY, post_id INTEGER, meta_key TEXT, meta_value TEXT)",
		"CREATE TABLE {$prefix}terms (term_id INTEGER PRIMARY KEY, slug TEXT)",
		"CREATE TABLE {$prefix}term_taxonomy (term_taxonomy_id INTEGER PRIMARY KEY, term_id INTEGER, taxonomy TEXT)",
		"CREATE TABLE {$prefix}term_relationships (object_id INTEGER, term_taxonomy_id INTEGER, term_order INTEGER DEFAULT 0)",
		"CREATE TABLE {$prefix}termmeta (meta_id INTEGER PRIMARY KEY, term_id INTEGER, meta_key TEXT, meta_value TEXT)",
		"CREATE TABLE {$prefix}comments (comment_ID INTEGER PRIMARY KEY)",
		"CREATE TABLE {$prefix}commentmeta (meta_id INTEGER PRIMARY KEY, comment_id INTEGER, meta_key TEXT, meta_value TEXT)",
		"CREATE TABLE {$prefix}links (link_id INTEGER PRIMARY KEY)"
	) ) . ';';
}

require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-frontmatter-profiles.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-backend-capabilities.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-storage.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-search.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-write-engine.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-driver.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-loader.php';
require_once dirname( __DIR__ ) . '/inc/class-wp-markdown-primary-storage-runtime.php';

$failed = 0;
function mdi_runtime_assert( bool $condition, string $label ): void {
	global $failed;
	echo ( $condition ? 'PASS' : 'FAIL' ) . ': ' . $label . PHP_EOL;
	if ( ! $condition ) { $failed++; }
}
function mdi_runtime_rm( string $path ): void {
	if ( ! is_dir( $path ) ) { return; }
	foreach ( scandir( $path ) ?: array() as $entry ) {
		if ( '.' !== $entry && '..' !== $entry ) {
			$child = $path . '/' . $entry;
			is_dir( $child ) ? mdi_runtime_rm( $child ) : unlink( $child );
		}
	}
	rmdir( $path );
}

$root = sys_get_temp_dir() . '/mdi-primary-runtime-' . getmypid() . '-' . bin2hex( random_bytes( 4 ) );
mkdir( $root, 0755, true );
$cache = $root . '/index.sqlite';
$pdo = new PDO( 'sqlite:' . $cache );
$pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$pdo->exec( 'CREATE TABLE wp_posts (ID INTEGER PRIMARY KEY, post_author INTEGER, post_date TEXT, post_date_gmt TEXT, post_content TEXT, post_title TEXT, post_excerpt TEXT, post_status TEXT, comment_status TEXT, ping_status TEXT, post_password TEXT, post_name TEXT, to_ping TEXT, pinged TEXT, post_modified TEXT, post_modified_gmt TEXT, post_content_filtered TEXT, post_parent INTEGER, guid TEXT, menu_order INTEGER, post_type TEXT, post_mime_type TEXT, comment_count INTEGER)' );
$pdo->exec( 'CREATE TABLE wp_options (option_id INTEGER PRIMARY KEY, option_name TEXT UNIQUE, option_value TEXT, autoload TEXT)' );
$pdo->exec( 'CREATE TABLE wp_users (ID INTEGER PRIMARY KEY, user_login TEXT, user_pass TEXT)' );
$pdo->exec( 'CREATE TABLE wp_postmeta (post_id INTEGER, meta_key TEXT, meta_value TEXT)' );
$pdo->exec( 'CREATE TABLE wp_terms (term_id INTEGER, slug TEXT)' );
$pdo->exec( 'CREATE TABLE wp_term_taxonomy (term_taxonomy_id INTEGER, term_id INTEGER, taxonomy TEXT)' );
$pdo->exec( 'CREATE TABLE wp_term_relationships (object_id INTEGER, term_taxonomy_id INTEGER, term_order INTEGER DEFAULT 0)' );
$pdo->exec( "INSERT INTO wp_posts (ID, post_date, post_date_gmt, post_modified, post_modified_gmt, post_title, post_status, comment_status, ping_status, post_name, post_type) VALUES (12, '2026-07-18 00:00:00', '2026-07-18 00:00:00', '2026-07-18 00:00:00', '2026-07-18 00:00:00', 'Cold post', 'publish', 'open', 'open', 'cold-post', 'post')" );
$pdo->exec( "INSERT INTO wp_options VALUES (7, 'siteurl', 'https://old.test', 'yes')" );
$pdo->exec( "INSERT INTO wp_options VALUES (8, 'blogname', 'Old name', 'yes')" );
$pdo->exec( "INSERT INTO wp_users VALUES (1, 'admin', 'hashed-password')" );

mkdir( $root . '/existing-state/_tables', 0755, true );
$large_snapshot = $root . '/existing-state/_tables/plugin_snapshot.json';
file_put_contents( $large_snapshot, str_repeat( 'x', 16 * 1024 * 1024 ) );
$old_atime = time() - 7200;
touch( $large_snapshot, $old_atime, $old_atime );
clearstatcache( true, $large_snapshot );

$existing = WP_Markdown_Primary_Storage_Runtime::bootstrap_existing_cache(
	array( 'content_root' => $root . '/existing-content', 'state_root' => $root . '/existing-state' ),
	new WP_SQLite_Connection( $pdo ),
	'wordpress'
);
$existing_driver = $existing->get_driver();
clearstatcache( true, $large_snapshot );
mdi_runtime_assert( $old_atime === fileatime( $large_snapshot ), 'existing-cache bootstrap does not read or hash a large unchanged JSON snapshot' );
$existing_driver->query( "UPDATE wp_options SET option_value = 'Attached name' WHERE option_name = 'blogname'" );
$existing_driver->query( "UPDATE wp_users SET user_login = 'admin-existing' WHERE ID = 1" );
$existing_driver->query( "UPDATE wp_posts SET post_title = 'Attached post' WHERE ID = 12" );
$existing_changes = $existing_driver->flush_canonical_writes();
mdi_runtime_assert( 'Attached name' === $pdo->query( "SELECT option_value FROM wp_options WHERE option_name = 'blogname'" )->fetchColumn() && 'admin-existing' === $pdo->query( 'SELECT user_login FROM wp_users WHERE ID = 1' )->fetchColumn() && 'Attached post' === $pdo->query( 'SELECT post_title FROM wp_posts WHERE ID = 12' )->fetchColumn(), 'existing-cache attachment does not hydrate files into or replace populated SQLite rows' );
mdi_runtime_assert( file_exists( $root . '/existing-state/_options/blogname.json' ) && file_exists( $root . '/existing-state/_tables/users.json' ) && file_exists( $root . '/existing-content/post/cold-post.md' ), 'existing-cache attachment flushes populated options users and posts to canonical files' );
mdi_runtime_assert( array( '_options/blogname.json', '_tables/users.json', 'post/cold-post.md' ) === $existing_changes['created'], 'driver flush returns deterministic canonical paths for caller-managed durability' );
mdi_runtime_assert( $existing_changes === $GLOBALS['mdi_runtime_actions']['markdown_database_integration_flushed'][0][0], 'successful flush action exposes the same canonical change set' );
mdi_runtime_assert( array( 'created' => array(), 'changed' => array(), 'deleted' => array() ) === $existing_driver->flush_canonical_writes(), 'driver flush returns an empty change set at a clean boundary' );
$existing_driver->query( "INSERT INTO wp_posts (ID, post_title, post_status, post_name, post_type) VALUES (13, 'Ephemeral draft', 'auto-draft', '', 'post')" );
$existing_driver->query( "INSERT INTO wp_posts (ID, post_title, post_status, post_name, post_type) VALUES (14, 'Durable draft', 'draft', 'durable-draft', 'post')" );
$insert_changes = $existing_driver->flush_canonical_writes();
$auto_draft_full_reads = array_filter(
	$existing_driver->queries,
	static fn ( string $query ): bool => str_contains( $query, 'SELECT * FROM `wp_posts` WHERE ID = 13' )
);
mdi_runtime_assert( array( 'post/durable-draft.md' ) === $insert_changes['created'], 'insert persistence keeps normal drafts and omits ephemeral auto-drafts' );
mdi_runtime_assert( empty( $auto_draft_full_reads ), 'auto-draft inserts do not enter full-row shutdown persistence' );
$existing_driver->fail_status_queries = true;
$existing_driver->query( "INSERT INTO wp_posts (ID, post_title, post_status, post_name, post_type) VALUES (15, 'Fail-safe draft', 'draft', 'fail-safe-draft', 'post')" );
$existing_driver->fail_status_queries = false;
mdi_runtime_assert( array( 'post/fail-safe-draft.md' ) === $existing_driver->flush_canonical_writes()['created'], 'status lookup failures retain inserted posts for canonical persistence' );
$users_path = $root . '/existing-state/_tables/users.json';
unlink( $users_path );
mkdir( $users_path );
$existing_driver->query( "UPDATE wp_users SET user_login = 'blocked-write' WHERE ID = 1" );
$explicit_failure = false;
try {
	$existing_driver->flush_canonical_writes();
} catch ( RuntimeException $exception ) {
	$explicit_failure = str_contains( $exception->getMessage(), 'Failed to rename JSON file' );
}
mdi_runtime_assert( $explicit_failure, 'explicit driver flush propagates canonical persistence failures' );
rmdir( $users_path );

$runtime = WP_Markdown_Primary_Storage_Runtime::bootstrap(
	array( 'content_root' => $root . '/content', 'state_root' => $root . '/state' ),
	new WP_SQLite_Connection( $pdo ),
	'wordpress',
	null,
	true
);
$driver = $runtime->get_driver();
$operations = new WP_Markdown_SQLite_Operations( $driver, 'wp_' );
$post_commit_marker = "Post-commit persistence succeeds exactly once.  \t\n";
$post_commit_result = $driver->query( "UPDATE wp_posts SET post_content = '{$post_commit_marker}' WHERE ID = 12" );
$post_commit_row = (string) $pdo->query( 'SELECT post_content FROM wp_posts WHERE ID = 12' )->fetchColumn();
$post_commit_file = (string) file_get_contents( $root . '/content/post/cold-post.md' );
$post_commit_canonical = ( new WP_Markdown_Storage( $root . '/content' ) )->read_post( 12 );
$post_commit_index = $operations->file_index_receipt( 12 );
mdi_runtime_assert(
	false !== $post_commit_result
	&& $post_commit_marker === $post_commit_row
	&& $post_commit_marker === ( $post_commit_canonical->post_content ?? null )
	&& 1 === substr_count( $post_commit_row, $post_commit_marker )
	&& 1 === substr_count( $post_commit_file, $post_commit_marker )
	&& array( 'post_id' => 12 ) === $post_commit_index,
	'post-commit WordPress writes preserve terminal spaces and tabs across the row, canonical Markdown, and index'
);
$option_insert_mutation = $operations->mutations_for_query(
	"INSERT INTO wp_options (option_value, option_name, autoload) VALUES ('value', 'inserted_option', 'yes')",
	array( 'table' => 'wp_options', 'op' => 'INSERT', 'type' => 'DML' )
);
mdi_runtime_assert( array( 'inserted_option' ) === $option_insert_mutation[0]['resource_ids'], 'option INSERT mutation identity uses option_name rather than the numeric insert ID' );
$lazy_content = "Canonical body  \t\n";
$driver->query( "UPDATE `wp_posts` SET `post_content` = '{$lazy_content}', `post_title` = 'Written post' WHERE `ID` = 12" );
$driver->query( "UPDATE `wp_posts` SET `post_excerpt` = 'Quoted IN predicate' WHERE `ID` IN (12)" );
$driver->query( "UPDATE wp_options SET option_value = 'https://example.test' WHERE option_name = 'siteurl'" );
$driver->query( "UPDATE wp_options SET option_value = 'Canonical name' WHERE option_name = 'blogname'" );
$first = $runtime->flush();
mdi_runtime_assert( array( '_options/blogname.json', '_options/siteurl.json', 'post/cold-post.md' ) === $first['created'], 'explicit flush persists normal post and option mutations with relative paths' );
$driver->query( "INSERT INTO wp_terms (term_id, slug) VALUES (9, 'guides')" );
$driver->query( "INSERT INTO wp_term_taxonomy (term_taxonomy_id, term_id, taxonomy) VALUES (19, 9, 'category')" );
$driver->query( 'INSERT INTO wp_term_relationships (object_id, term_taxonomy_id) VALUES (12, 19)' );
$term_changes = $runtime->flush();
mdi_runtime_assert( in_array( 'post/cold-post.md', $term_changes['changed'], true ) && str_contains( (string) file_get_contents( $root . '/content/post/cold-post.md' ), 'guides' ), 'term relationship INSERT rewrites the affected Markdown frontmatter' );
$driver->query( "INSERT INTO wp_terms (term_id, slug) VALUES (10, 'updated-guides')" );
$driver->query( "INSERT INTO wp_term_taxonomy (term_taxonomy_id, term_id, taxonomy) VALUES (20, 10, 'category')" );
$driver->query( 'UPDATE wp_term_relationships SET term_taxonomy_id = 20 WHERE term_taxonomy_id IN (19)' );
$bulk_term_changes = $runtime->flush();
mdi_runtime_assert( in_array( 'post/cold-post.md', $bulk_term_changes['changed'], true ) && str_contains( (string) file_get_contents( $root . '/content/post/cold-post.md' ), 'updated-guides' ), 'bulk term relationship UPDATE conservatively rewrites Markdown frontmatter' );
$identity = $runtime->get_identity();
mdi_runtime_assert( '' !== $identity['hash'] && isset( $identity['files']['post/cold-post.md'] ), 'cache exposes canonical manifest identity' );

$driver->query( "UPDATE wp_options SET option_value = 'Canonical name two' WHERE option_name = 'blogname'" );
$changed = $runtime->flush();
mdi_runtime_assert( array( '_options/blogname.json' ) === $changed['changed'], 'changed canonical option path is reported' );

$driver->query( "UPDATE wp_options SET option_value = 'Canonical name six' WHERE option_name = 'blogname'" );
$same_size_changed = $runtime->flush();
mdi_runtime_assert( array( '_options/blogname.json' ) === $same_size_changed['changed'], 'same-size canonical option overwrite is reported by content hash' );

$driver->query( "UPDATE wp_posts SET post_name = 'moved-post' WHERE ID = 12" );
$moved = $runtime->flush();
mdi_runtime_assert( array( 'post/moved-post.md' ) === $moved['created'] && array( 'post/cold-post.md' ) === $moved['deleted'], 'slug movement reports canonical paths without a stale file' );
$driver->query( 'UPDATE wp_options SET option_value = option_value' );
$driver->query( 'DELETE FROM wp_options WHERE option_name = \'siteurl\'' );
$deleted = $runtime->flush();
mdi_runtime_assert( array( '_options/siteurl.json' ) === $deleted['deleted'], 'exact option deletion survives a mixed all-options flush' );

$lazy_round_trip_cases = array(
	12 => $lazy_content,
	16 => '',
	17 => 'Content without a final LF',
	18 => "CRLF content\r\nwith a final CRLF\r\n",
);
foreach ( $lazy_round_trip_cases as $post_id => $content ) {
	if ( 12 === $post_id ) {
		continue;
	}
	$driver->query( 'INSERT INTO wp_posts (ID, post_content, post_title, post_status, post_name, post_type) VALUES (' . $post_id . ', ' . $pdo->quote( $content ) . ", 'Lazy case {$post_id}', 'publish', 'lazy-case-{$post_id}', 'post')" );
}

$missing_identity_rejected = false;
try {
	WP_Markdown_Primary_Storage_Runtime::bootstrap( array( 'content_root' => $root . '/content', 'state_root' => $root . '/state' ), new WP_SQLite_Connection( $pdo ), 'wordpress', null, false );
} catch ( RuntimeException $exception ) {
	$missing_identity_rejected = 'A canonical identity is required for a warm SQLite cache.' === $exception->getMessage();
}
mdi_runtime_assert( $missing_identity_rejected, 'warm bootstrap rejects a missing canonical identity' );

$mismatch_rejected = false;
try {
	WP_Markdown_Primary_Storage_Runtime::bootstrap( array( 'content_root' => $root . '/content', 'state_root' => $root . '/state' ), new WP_SQLite_Connection( $pdo ), 'wordpress', $identity, false );
} catch ( RuntimeException $exception ) {
	$mismatch_rejected = 'The supplied SQLite cache identity does not match the canonical files.' === $exception->getMessage();
}
mdi_runtime_assert( $mismatch_rejected, 'warm bootstrap rejects a mismatched canonical identity' );

$pdo = null;
unlink( $cache );
$cold_pdo = new PDO( 'sqlite:' . $cache );
$cold_pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$cold_runtime = WP_Markdown_Primary_Storage_Runtime::bootstrap( array( 'content_root' => $root . '/content', 'state_root' => $root . '/state' ), new WP_SQLite_Connection( $cold_pdo ), 'wordpress', null, true );
$cold_driver = $cold_runtime->get_driver();
$lazy_round_trip_matches = array();
foreach ( $lazy_round_trip_cases as $post_id => $content ) {
	$cold_post = $cold_driver->query_cursor( 'SELECT ID, post_content FROM wp_posts WHERE ID = ' . $post_id )->fetch( PDO::FETCH_OBJ );
	$lazy_round_trip_matches[] = $content === ( $cold_post->post_content ?? null );
}
mdi_runtime_assert( 'Canonical name six' === $cold_pdo->query( "SELECT option_value FROM wp_options WHERE option_name = 'blogname'" )->fetchColumn() && 'Written post' === $cold_pdo->query( 'SELECT post_title FROM wp_posts WHERE ID = 12' )->fetchColumn() && ! in_array( false, $lazy_round_trip_matches, true ) && 4 === count( $lazy_round_trip_matches ), 'cold reconstruction creates WordPress core tables in an empty index and preserves canonical content exactly' );

$unsupported_cold_boot = false;
try {
	WP_Markdown_Primary_Storage_Runtime::bootstrap( array( 'content_root' => $root . '/content', 'state_root' => $root . '/state' ), new WP_SQLite_Connection( $cold_pdo ), 'wordpress', null, true, array(), 'wp_', new WP_Markdown_Backend_Capabilities( 'incomplete', array( 'disposable_index_operation' => true ) ) );
} catch ( WP_Markdown_Unsupported_Backend_Capability $exception ) {
	$unsupported_cold_boot = 'cold_reconstruction' === $exception->get_diagnostic()['capability'];
}
mdi_runtime_assert( $unsupported_cold_boot, 'primary cold reconstruction enforces backend capability with a structured diagnostic' );

$incomplete_backend = new WP_Markdown_Backend_Capabilities( 'incomplete', array( 'disposable_index_operation' => true ) );
$incomplete_storage = new WP_Markdown_Storage( $root . '/incomplete-content' );
$incomplete_driver = new WP_Markdown_Driver( new WP_SQLite_Connection( $cold_pdo ), 'wordpress', $incomplete_storage, $incomplete_backend );
$incomplete_driver->set_write_engine( new WP_Markdown_Write_Engine( $root . '/incomplete-content', $incomplete_storage, $incomplete_driver, 'wp_', $root . '/incomplete-state' ) );
$enforced = array();
foreach ( array(
	'table_mutation_capture' => static fn () => $incomplete_driver->query( "UPDATE wp_options SET option_value = 'blocked' WHERE option_name = 'blogname'" ),
	'schema_persistence' => static fn () => $incomplete_driver->query( 'CREATE TABLE wp_incomplete (id INTEGER)' ),
	'lazy_post_content_resolution' => static fn () => $incomplete_driver->query( 'SELECT post_content FROM wp_posts' ),
	'explicit_flush' => static fn () => $incomplete_driver->flush_canonical_writes(),
) as $capability => $operation ) {
	try {
		$operation();
	} catch ( WP_Markdown_Unsupported_Backend_Capability $exception ) {
		$enforced[ $capability ] = $exception->get_diagnostic()['capability'] === $capability;
	}
}
mdi_runtime_assert( ! in_array( false, $enforced, true ) && 4 === count( $enforced ), 'driver mutation, schema, lazy content, and flush boundaries fail closed for an incomplete backend' );

mdi_runtime_rm( $root );
exit( $failed ? 1 : 0 );
