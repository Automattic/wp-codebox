<?php
/**
 * Markdown Storage Engine
 *
 * Reads and writes WordPress posts as markdown files with YAML frontmatter.
 * Posts are stored hierarchically: directory structure matches the post
 * parent-child hierarchy. Parent posts that have children become directories
 * with their content in index.md.
 *
 * File layout:
 *   {content_dir}/{post_type}/slug.md              — leaf post (no children)
 *   {content_dir}/{post_type}/parent-slug/index.md — parent post (has children)
 *   {content_dir}/{post_type}/parent-slug/child.md  — child post
 *
 * The directory structure IS the hierarchy — no `parent` field in frontmatter.
 * The loader derives post_parent from the filesystem path.
 *
 * File format:
 *   ---
 *   id: 42
 *   title: "My Post Title"
 *   status: publish
 *   type: post
 *   author: 1
 *   date: "2026-04-13 21:17:48"
 *   modified: "2026-04-14 00:33:50"
 *   slug: my-post-title
 *   menu_order: 0
 *   comment_status: open
 *   ping_status: open
 *   ---
 *
 *   The post content goes here as markdown.
 *
 * Ref: GitHub issue #14
 *
 * @package Markdown_Database_Integration
 * @since 0.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-file-witness.php';

if ( ! class_exists( 'WP_Markdown_Yaml' ) ) {
	require_once __DIR__ . '/class-wp-markdown-yaml.php';
}
if ( ! class_exists( 'WP_Markdown_Frontmatter_Profiles' ) ) {
	require_once __DIR__ . '/class-wp-markdown-frontmatter-profiles.php';
}
if ( ! class_exists( 'WP_Markdown_Content_Layout_Profiles' ) ) {
	require_once __DIR__ . '/class-wp-markdown-content-layout-profiles.php';
}

class WP_Markdown_Storage {


	/**
	 * Base directory for markdown files.
	 *
	 * @var string
	 */
	private $content_dir;

	/**
	 * Post types explicitly excluded from markdown storage.
	 *
	 * @var string[]
	 */
	private $excluded_types = array();

	/**
	 * In-memory index of post ID → file path.
	 * Populated on first access, updated on writes.
	 *
	 * @var array<int, string>|null
	 */
	private $index = null;

	/**
	 * Callback to resolve a post's slug and parent ID by post ID.
	 * Set by the write engine so we can build hierarchical paths.
	 *
	 * Returns: (object) { post_name: string, post_parent: int, post_type: string }
	 *
	 * @var callable|null
	 */
	private $post_resolver = null;

	/**
	 * Callback to resolve a post's meta by post ID.
	 * Returns: array of { meta_key: string, meta_value: string }
	 *
	 * @var callable|null
	 */
	private $meta_resolver = null;

	/**
	 * Callback to resolve a post's terms by post ID.
	 * Returns: array of { taxonomy: string, slug: string }
	 *
	 * @var callable|null
	 */
	private $terms_resolver = null;

	/**
	 * Callback that persists a file-index update for a post.
	 *
	 * Signature: function ( int $post_id, string $relative_path, int $mtime, int $size ): void
	 *
	 * Invoked whenever the storage engine renames a file as a side effect of
	 * another write (parent promotion in resolve_parent_dir — a child write
	 * forces its ancestor's leaf file to migrate to `index.md`). Without this
	 * hook the persistent `_markdown_file_index` row points at a path that
	 * no longer exists on disk, and `sync_markdown_posts()` on the next
	 * warm boot treats the old path as a deletion and the new path as a
	 * fresh insert — churning the ancestor through a full delete-and-
	 * reinsert on every boot. See GitHub issue #68.
	 *
	 * Optional. Cold-boot paths that build storage before the driver exists
	 * simply skip the callback — their in-memory `$this->index` is enough
	 * until the index is materialised.
	 *
	 * @var callable|null
	 */
	private $index_writer = null;

	/** @var callable|null Receives a canonical file path before a mutation. */
	private $file_mutation_observer = null;

	/**
	 * Explicit frontmatter profile ID for this storage instance.
	 *
	 * @var string
	 */
	private string $frontmatter_profile = '';

	/** Explicit content-layout profile ID for this storage instance. */
	private string $content_layout_profile = '';

	/**
	 * Constructor.
	 *
	 * All post types are stored as markdown by default.
	 * Pass $excluded_types to opt specific types out.
	 *
	 * @param string   $content_dir    Base directory for markdown files.
	 * @param string[] $excluded_types Post types to exclude from markdown storage.
	 */
	public function __construct( string $content_dir, array $excluded_types = array() ) {
		$this->content_dir    = rtrim( $content_dir, '/' );
		$this->excluded_types = $excluded_types;
	}

	/**
	 * Set the post resolver callback.
	 *
	 * The resolver takes a post ID and returns an object with at minimum:
	 *   post_name (string), post_parent (int), post_type (string)
	 *
	 * @param callable $resolver
	 */
	public function set_post_resolver( callable $resolver ): void {
		$this->post_resolver = $resolver;
	}

	/**
	 * Set the meta resolver callback.
	 *
	 * @param callable $resolver Takes post ID, returns array of {meta_key, meta_value}.
	 */
	public function set_meta_resolver( callable $resolver ): void {
		$this->meta_resolver = $resolver;
	}

	/**
	 * Set the terms resolver callback.
	 *
	 * @param callable $resolver Takes post ID, returns array of {taxonomy, slug}.
	 */
	public function set_terms_resolver( callable $resolver ): void {
		$this->terms_resolver = $resolver;
	}

	/**
	 * Set the index-writer callback.
	 *
	 * Invoked whenever the storage engine renames a file as a side effect
	 * of another write (currently only parent promotion in
	 * resolve_parent_dir). Callback signature:
	 *
	 *     function ( int $post_id, string $relative_path, int $mtime, int $size ): void
	 *
	 * $relative_path is relative to the storage's content_dir. The callback
	 * is expected to upsert the corresponding row in `_markdown_file_index`
	 * so warm boot comparisons see the file as unchanged rather than as a
	 * delete + re-insert pair.
	 *
	 * See GitHub issue #68.
	 *
	 * @param callable $writer Index-update callback.
	 */
	public function set_index_writer( callable $writer ): void {
		$this->index_writer = $writer;
	}

	/** @param callable $observer Receives an absolute path before it is mutated. */
	public function set_file_mutation_observer( callable $observer ): void {
		$this->file_mutation_observer = $observer;
	}

	private function observe_file_mutation( string $path ): void {
		if ( null !== $this->file_mutation_observer ) {
			call_user_func( $this->file_mutation_observer, $path );
		}
	}

	/**
	 * Set an explicit frontmatter profile for reads and writes.
	 *
	 * @param string $profile Profile ID.
	 */
	public function set_frontmatter_profile( string $profile ): void {
		$this->frontmatter_profile = $profile;
	}

	/** Set the content-layout profile used for enumeration and path mapping. */
	public function set_content_layout_profile( string $profile ): void {
		$this->content_layout_profile = $profile;
	}

	/** @return array<string,mixed> */
	private function content_layout(): array {
		return WP_Markdown_Content_Layout_Profiles::resolve( $this->content_layout_profile, array( 'content_dir' => $this->content_dir ) );
	}

	/**
	 * Whether the layout profile finds canonical files itself.
	 *
	 * A profile that does supplies its own sources and its own mapping. The
	 * default profile supplies neither, so canonical files are found by
	 * walking the post-type tree.
	 */
	private function profile_enumerates_sources(): bool {
		return is_callable( $this->content_layout()['enumerate'] ?? null );
	}

	/**
	 * Write a post to a markdown file.
	 *
	 * Builds a hierarchical directory path based on the post's ancestry.
	 * If the post has a parent, it's written inside the parent's directory.
	 * If a parent post gains its first child, the parent's leaf file is
	 * promoted to a directory with index.md.
	 *
	 * @param object $post A post row object with WordPress column names.
	 * @return string|false The file path written, or false on failure.
	 */
	public function write_post( object $post, bool $persist_auto_draft = false ): string|false {
		$post_type = $post->post_type ?? 'post';

		// Skip excluded post types.
		if ( in_array( $post_type, $this->excluded_types, true ) ) {
			return false;
		}

		// Skip auto-drafts — they're ephemeral.
		$status = $post->post_status ?? '';
		if ( 'auto-draft' === $status && ! $persist_auto_draft ) {
			return false;
		}

		$slug = $post->post_name ?? '';
		$id   = (int) ( $post->ID ?? 0 );

		// Use ID as filename fallback if no slug.
		if ( empty( $slug ) ) {
			$slug = $id ? (string) $id : 'untitled-' . time();
		}

		$parent_id = (int) ( $post->post_parent ?? 0 );

		if ( $this->profile_enumerates_sources() ) {
			return $this->write_profile_post( $post );
		}

		// Build the hierarchical directory path.
		$type_dir = $this->content_dir . '/' . $this->sanitize_path( $post_type );
		$parent_dir = $this->resolve_parent_dir( $type_dir, $parent_id );

		if ( ! is_dir( $parent_dir ) ) {
			mkdir( $parent_dir, 0755, true );
		}

		$sanitized_slug = $this->sanitize_path( $slug );
		$slug_dir       = $parent_dir . '/' . $sanitized_slug;
		$file_path      = $parent_dir . '/' . $sanitized_slug . '.md';

		// If a directory with this slug already exists (i.e. this post has
		// children), write as index.md inside it instead of a sibling file.
		// This keeps the directory structure in sync with the hierarchy.
		if ( is_dir( $slug_dir ) ) {
			$file_path = $slug_dir . '/index.md';
		}

		// Build frontmatter.
		$frontmatter = $this->build_frontmatter( $post );

		// Build content.
		$content = $post->post_content ?? '';

		// Assemble the file.
		$output = "---\n";
		$output .= WP_Markdown_Yaml::encode_yaml( $frontmatter );
		$output .= "---\n\n";
		$output .= $content . "\n";

		$this->observe_file_mutation( $file_path );
		$result = file_put_contents( $file_path, $output, LOCK_EX );

		if ( false !== $result ) {
			// Ensure the index is built so we can detect path changes.
			// Without this, the cleanup block is skipped when the index is
			// null (lazy-init), leaving stale files on disk when posts are
			// reparented or renamed. See GitHub issue #31.
			if ( $id ) {
				// Claim the just-written path as canonical BEFORE any rebuild.
				// rebuild_index() respects pre-claimed entries and unlinks
				// competing disk copies against the claim, instead of applying
				// its depth heuristic. Without this, a shallow write competing
				// with a deeper stale copy (e.g. un-reparenting) could be
				// unlinked by rebuild's dedup — destroying the fresh write.
				// See GitHub issue #70.
				$previous_path = $this->index[ $id ] ?? null;
				if ( null === $this->index ) {
					$this->index = array();
				}
				$this->index[ $id ] = $file_path;

				if ( null === $previous_path ) {
					// No prior in-memory path — populate the rest of the index
					// by scanning disk. rebuild_index() honors the claim above,
					// so the fresh write is safe.
					$this->rebuild_index();
					// rebuild_index may have identified a stale copy at a
					// different path and already unlinked it; refresh
					// $previous_path from any surviving discrepancy.
					$previous_path = null;
				}

				// Remove old file if path changed (slug change or reparent).
				if ( null !== $previous_path && $previous_path !== $file_path ) {
					$this->safe_unlink( $previous_path );
					$this->cleanup_empty_dirs( dirname( $previous_path ), $type_dir );
				}
			}
			return $file_path;
		}

		return false;
	}

	/**
	 * Read a post from a markdown file by ID.
	 *
	 * @param int $post_id The post ID.
	 * @return object|null A post-like object, or null if not found.
	 */
	public function read_post( int $post_id ): ?object {
		$file_path = $this->find_file_by_id( $post_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return null;
		}

		return $this->parse_file( $file_path );
	}

	/** Return the currently indexed canonical path for a post. */
	public function path_for_post( int $post_id ): string|false {
		return $this->find_file_by_id( $post_id ) ?? false;
	}

	/**
	 * Delete a post's markdown file.
	 *
	 * If the post is a parent (has a directory), and the directory
	 * still has children, only the index.md is removed. If the
	 * directory becomes empty, it's cleaned up.
	 *
	 * @param int $post_id The post ID.
	 * @return bool True when deleted, false when absent or failed.
	 */
	public function delete_post( int $post_id ): bool {
		return 'deleted' === $this->delete_post_result( $post_id );
	}

	/**
	 * Delete a post's markdown file with an explicit absence/failure outcome.
	 *
	 * @return 'deleted'|'absent'|'failed'
	 */
	public function delete_post_result( int $post_id ): string {
		$file_path = $this->find_file_by_id( $post_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return 'absent';
		}
		if ( ! $this->existing_path_is_safe( $file_path ) ) {
			return 'failed';
		}

		$result = $this->safe_unlink( $file_path );

		if ( $result ) {
			// Clean up empty directories up to the post type dir.
			$dir = dirname( $file_path );
			$type_dir = $this->guess_type_dir( $file_path );
			$this->cleanup_empty_dirs( $dir, $type_dir );

			if ( null !== $this->index ) {
				unset( $this->index[ $post_id ] );
			}
		}

		return $result ? 'deleted' : 'failed';
	}

	/**
	 * Delete all markdown files (truncate).
	 *
	 * @param string $post_type Optional. Truncate only a specific post type directory.
	 */
	public function truncate( string $post_type = '' ): void {
		if ( ! empty( $post_type ) ) {
			$dir = $this->content_dir . '/' . $this->sanitize_path( $post_type );
			$this->remove_directory_recursive( $dir );
		} else {
			// Truncate all post type directories.
			$dirs = glob( $this->content_dir . '/*', GLOB_ONLYDIR );
			if ( $dirs ) {
				foreach ( $dirs as $dir ) {
					if ( ! str_starts_with( basename( $dir ), '_' ) ) {
						$this->remove_directory_recursive( $dir );
					}
				}
			}
		}
		$this->index = null;
	}

	/** Delete Markdown files while propagating any incomplete filesystem mutation. */
	public function truncate_strict( string $post_type = '' ): void {
		if ( ! is_dir( $this->content_dir ) ) { return; }
		if ( '' !== $post_type ) {
			$this->remove_directory_recursive_strict( $this->content_dir . '/' . $this->sanitize_path( $post_type ) );
		} else {
			$entries = scandir( $this->content_dir );
			if ( false === $entries ) { throw new RuntimeException( 'Markdown DB: Failed to inspect canonical content directory.' ); }
			foreach ( $entries as $entry ) {
				if ( '.' === $entry || '..' === $entry || str_starts_with( $entry, '_' ) ) { continue; }
				$path = $this->content_dir . '/' . $entry;
				if ( is_link( $path ) ) { throw new RuntimeException( 'Markdown DB: Refusing to truncate a linked content path.' ); }
				if ( is_dir( $path ) ) { $this->remove_directory_recursive_strict( $path ); }
			}
		}
		$this->index = null;
	}

	/**
	 * Get all markdown files as post objects.
	 *
	 * Recursively scans each post type directory. Derives post_parent
	 * from the directory structure: index.md files are parents, files
	 * inside a directory are children of that directory's index.md.
	 *
	 * Deduplicates by post ID. See GitHub issue #9.
	 *
	 * When $metadata_only is true, only frontmatter is parsed — content
	 * bodies are skipped. This dramatically speeds up boot by avoiding
	 * reading file bodies that will be lazy-loaded on demand.
	 * See: Index/Map Architecture design doc.
	 *
	 * @param bool $metadata_only If true, skip content bodies (for index boot).
	 * @return object[] Array of post-like objects (unique by ID).
	 */
	public function get_all_posts( bool $metadata_only = false ): array {
		return iterator_to_array( $this->get_all_posts_iterator( $metadata_only ), false );
	}

	/**
	 * Get lightweight metadata for every markdown file without parsing posts.
	 *
	 * Warm sync only needs path, mtime, size, and derived parent hints to diff
	 * against the persisted file index. Parsing every file into a post object at
	 * 100k+ corpus sizes exhausts PHP memory before the diff can prove nothing
	 * changed.
	 *
	 * @return array<string,array{mtime:int,size:int,absolute:string,parent_id:int|null}> Relative path keyed manifest.
	 */
	public function get_markdown_file_manifest(): array {
		return iterator_to_array( $this->get_markdown_file_manifest_iterator() );
	}

	/**
	 * Iterate lightweight metadata for every markdown file without retaining it.
	 *
	 * @return \Generator<string,array{mtime:int,size:int,absolute:string,parent_id:int|null}>
	 */
	/**
	 * @param bool                   $strict     Whether unsafe canonical state must raise.
	 * @param array<int,string>|null $post_types Restrict enumeration to these post types when the
	 *                                           layout stores one directory per type. A layout that
	 *                                           cannot derive a type from a path ignores the hint.
	 */
	public function get_markdown_file_manifest_iterator( bool $strict = false, ?array $post_types = null ): \Generator {
		if ( $strict && is_link( $this->content_dir ) ) {
			throw new RuntimeException( 'Markdown DB: Canonical content root must not be a link.' );
		}
		if ( $this->profile_enumerates_sources() ) {
			$identities = array();
			foreach ( $this->profile_source_paths() as $relative ) {
				$path = $this->profile_absolute_path( $relative );
				if ( null === $path ) {
					if ( $strict ) {
						throw new RuntimeException( 'Markdown DB: Content profile returned an unsafe source path.' );
					}
					continue;
				}
				$stat = @lstat( $path );
				if ( $strict && ( ! $this->existing_path_is_safe( $path ) || ! is_array( $stat ) || 1 !== ( $stat['nlink'] ?? 1 ) ) ) {
					throw new RuntimeException( 'Markdown DB: Canonical content source path is unsafe.' );
				}
				$post = $this->read_file( $path, true );
				if ( ! $post ) {
					if ( $strict ) {
						throw new RuntimeException( 'Markdown DB: Canonical content source is malformed.' );
					}
					continue;
				}
				$this->apply_layout_mapping( $post, $relative );
				$identity = (string) ( $post->_source_identity ?? $relative );
				if ( isset( $identities[ $identity ] ) ) {
					if ( $strict ) {
						throw new RuntimeException( 'Markdown DB: Canonical content contains a duplicate source identity.' );
					}
					error_log( sprintf( 'Markdown DB: duplicate source identity %s at %s and %s.', $identity, $identities[ $identity ], $relative ) );
					continue;
				}
				$identities[ $identity ] = $relative;
				yield $relative => array( 'mtime' => (int) filemtime( $path ), 'size' => (int) filesize( $path ), 'absolute' => $path, 'parent_id' => (int) $post->post_parent );
			}
			return;
		}
		if ( ! is_dir( $this->content_dir ) ) {
			return;
		}

		$dirs = glob( $this->content_dir . '/*', GLOB_ONLYDIR );
		if ( ! $dirs ) {
			return;
		}

		// One directory per post type, so a type-restricted read skips the
		// directories it cannot match instead of parsing the whole corpus.
		$scope = null === $post_types
			? null
			: array_values( array_filter( array_map( 'strval', $post_types ), static fn( string $type ): bool => '' !== $type ) );

		foreach ( $dirs as $type_dir ) {
			$dirname = basename( $type_dir );

			if ( str_starts_with( $dirname, '_' ) || in_array( $dirname, $this->excluded_types, true ) ) {
				continue;
			}
			if ( null !== $scope && ! in_array( $dirname, $scope, true ) ) {
				continue;
			}
			if ( is_link( $type_dir ) ) {
				if ( $strict ) {
					throw new RuntimeException( 'Markdown DB: Canonical post type directory must not be a link.' );
				}
				continue;
			}

			yield from $this->iterate_markdown_directory_manifest( $type_dir, $type_dir, 0, $strict );
		}
	}

	/**
	 * Iterate one markdown directory, deriving parent IDs from local index.md files.
	 *
	 * @param string $dir       Directory to scan.
	 * @param string $type_dir  Post type root directory.
	 * @param int    $parent_id Parent directory's index.md post ID.
	 * @return \Generator<string,array{mtime:int,size:int,absolute:string,parent_id:int|null}>
	 */
	private function iterate_markdown_directory_manifest( string $dir, string $type_dir, int $parent_id, bool $strict = false ): \Generator {
		if ( is_link( $dir ) ) {
			if ( $strict ) {
				throw new RuntimeException( 'Markdown DB: Canonical content directory must not be a link.' );
			}
			return;
		}
		$entries = scandir( $dir );
		if ( false === $entries ) {
			if ( $strict ) {
				throw new RuntimeException( 'Markdown DB: Canonical content directory is unreadable.' );
			}
			return;
		}

		$current_parent_id = 0;
		$index_path        = $dir . '/index.md';
		if ( file_exists( $index_path ) ) {
			$current_parent_id = $this->extract_id_from_file( $index_path ) ?: 0;
		}

		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}

			$path = $dir . '/' . $entry;
			// One look at the entry answers what it is, whether it is a link
			// and how it stands, rather than asking the filesystem three times
			// for the same facts.
			clearstatcache( true, $path );
			$stat = @lstat( $path );
			$mode = is_array( $stat ) ? ( $stat['mode'] & 0170000 ) : 0;
			if ( 0120000 === $mode ) {
				if ( $strict && ! str_starts_with( $entry, '_' ) ) {
					throw new RuntimeException( 'Markdown DB: Canonical content path must not be a link.' );
				}
				continue;
			}

			if ( 0040000 === $mode ) {
				if ( str_starts_with( $entry, '_' ) ) {
					continue;
				}

				yield from $this->iterate_markdown_directory_manifest( $path, $type_dir, $current_parent_id, $strict );
				continue;
			}

			if ( ! str_ends_with( $entry, '.md' ) ) {
				continue;
			}
			if ( $strict && ( ! is_array( $stat ) || 0100000 !== $mode || 1 !== ( $stat['nlink'] ?? 1 ) ) ) {
				throw new RuntimeException( 'Markdown DB: Canonical Markdown file is unsafe.' );
			}

			$derived_parent_id = null;
			if ( 'index.md' === $entry ) {
				$derived_parent_id = $parent_id;
			} elseif ( $dir !== $type_dir ) {
				$derived_parent_id = $current_parent_id;
			}

			// The look taken above is everything a witness is, and it was
			// taken a moment ago, so the entry carries it rather than leaving
			// the reader to ask the filesystem the same question again.
			yield $this->relative_path( $path ) => array(
				'mtime'     => (int) ( $stat['mtime'] ?? 0 ),
				'size'      => (int) ( $stat['size'] ?? 0 ),
				'absolute'  => $path,
				'parent_id' => $derived_parent_id,
				'witness'   => WP_Markdown_File_Witness::from_stat( $path, $stat ),
			);
		}
	}

	private function existing_path_is_safe( string $path ): bool {
		$root = realpath( $this->content_dir );
		$real = realpath( $path );
		if ( false === $root || false === $real || ! str_starts_with( $real, rtrim( $root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) ) {
			return false;
		}
		$current = rtrim( $this->content_dir, '/\\' );
		$relative = ltrim( substr( $path, strlen( $current ) ), '/\\' );
		foreach ( preg_split( '#[\\\\/]#', $relative ) ?: array() as $segment ) {
			$current .= DIRECTORY_SEPARATOR . $segment;
			if ( is_link( $current ) ) {
				return false;
			}
		}
		return true;
	}

	private function safe_unlink( string $path ): bool {
		if ( ! $this->existing_path_is_safe( $path ) ) {
			return false;
		}
		$before = @lstat( $path );
		if ( ! is_array( $before ) || is_link( $path ) ) {
			return false;
		}
		$this->observe_file_mutation( $path );
		$after = @lstat( $path );
		return is_array( $after ) && $before['dev'] === $after['dev'] && $before['ino'] === $after['ino'] && ! is_link( $path ) && @unlink( $path );
	}

	/**
	 * Parse one markdown file and apply a directory-derived parent hint.
	 *
	 * @param string   $file_path     Path to the markdown file.
	 * @param bool     $metadata_only If true, skip body content.
	 * @param int|null $parent_id     Directory-derived parent ID, or null to keep frontmatter.
	 * @return object|null A post-like object, or null on parse failure.
	 */
	public function read_file( string $file_path, bool $metadata_only = false, ?int $parent_id = null ): ?object {
		$post = $this->parse_file( $file_path, $metadata_only );
		if ( $post && null !== $parent_id ) {
			$post->post_parent = $parent_id;
		}
		if ( $post && $this->profile_enumerates_sources() ) {
			$this->apply_layout_mapping( $post, $this->relative_path( $file_path ) );
		}

		return $post;
	}

	/**
	 * Iterate markdown posts without retaining every parsed post object.
	 *
	 * Files with IDs are deduplicated by newest mtime before parsing, matching
	 * get_all_posts() without holding full post objects for the entire corpus.
	 * Files without IDs are yielded as they are found so callers can auto-assign.
	 *
	 * @param bool $metadata_only If true, skip content bodies.
	 * @return \Generator<int,object>
	 */
	public function get_all_posts_iterator( bool $metadata_only = false ): \Generator {
		$winners = array();

		foreach ( $this->get_markdown_file_manifest_iterator() as $file_info ) {
			// A metadata read is the post itself, so its frontmatter also
			// answers identity and is not read a second time. A content read
			// cannot reuse it, so identity stays the cheaper id-only scan.
			$metadata = $metadata_only ? $this->read_file( $file_info['absolute'], true, $file_info['parent_id'] ) : null;

			$id = $metadata ? (int) ( $metadata->ID ?? 0 ) : 0;
			if ( ! $id ) {
				// Identity shapes the parser does not map are still resolved
				// the long way, so no file loses its identity here.
				$id = (int) ( $this->extract_id_from_file( $file_info['absolute'] ) ?: 0 );
			}

			if ( ! $id ) {
				$post = $metadata ?? $this->read_file( $file_info['absolute'], $metadata_only, $file_info['parent_id'] );
				if ( $post ) {
					yield $post;
				}
				continue;
			}

			if ( ! isset( $winners[ $id ] ) || $file_info['mtime'] > $winners[ $id ]['mtime'] ) {
				$file_info['metadata'] = $metadata;
				$winners[ $id ]        = $file_info;
			}
		}

		foreach ( $winners as $file_info ) {
			// Content bodies are read one at a time as each winner is yielded,
			// so a full read never accumulates across the corpus.
			$post = $file_info['metadata'] ?? $this->read_file( $file_info['absolute'], $metadata_only, $file_info['parent_id'] );
			if ( $post ) {
				yield $post;
			}
		}
	}

	/** Write using the canonical source path the layout profile supplied. */
	private function write_profile_post( object $post ): string|false {
		$relative = $this->profile_path_for_post( $post );
		if ( false === $relative ) {
			return false;
		}
		$frontmatter = $this->build_frontmatter( $post );
		$file_path = $this->profile_absolute_path( $relative, true );
		if ( null === $file_path ) {
			return false;
		}
		if ( file_exists( $file_path ) && null === $this->profile_absolute_path( $relative ) ) {
			return false;
		}
		$existing_id = file_exists( $file_path ) ? $this->extract_id_from_file( $file_path ) : null;
		if ( null !== $existing_id && $existing_id !== (int) ( $post->ID ?? 0 ) ) {
			error_log( sprintf( 'Markdown DB: duplicate content route at %s (IDs %d and %d).', $relative, $existing_id, (int) ( $post->ID ?? 0 ) ) );
			return false;
		}
		if ( ! is_dir( dirname( $file_path ) ) && ! mkdir( dirname( $file_path ), 0755, true ) ) {
			return false;
		}
		if ( null === $this->profile_absolute_path( $relative, true ) ) {
			return false;
		}
		$output = "---\n" . WP_Markdown_Yaml::encode_yaml( $frontmatter ) . "---\n\n" . ( $post->post_content ?? '' ) . "\n";
		$id = (int) ( $post->ID ?? 0 );
		$old_path = $id > 0 ? $this->find_file_by_id( $id ) : null;
		$tmp_path = $this->stage_profile_write( $file_path, $output );
		if ( null === $tmp_path ) {
			return false;
		}
		if ( null !== $old_path && $old_path !== $file_path && file_exists( $old_path ) ) {
			if ( ! $this->safe_unlink( $old_path ) ) {
				@unlink( $tmp_path );
				return false;
			}
			$this->cleanup_empty_dirs( dirname( $old_path ), $this->content_dir );
		}
		$this->observe_file_mutation( $file_path );
		if ( ! $this->commit_profile_write( $tmp_path, $file_path ) ) {
			@unlink( $tmp_path );
			return false;
		}
		if ( $id > 0 ) {
			$this->index ??= array();
			$this->index[ $id ] = $file_path;
			$this->record_profile_index( $id, $file_path );
		}
		return $file_path;
	}

	/** Return the validated route the active layout profile selected. */
	public function profile_path_for_post( object $post ): string|false {
		$profile = $this->content_layout();
		if ( empty( $profile['path_for_post'] ) || ! is_callable( $profile['path_for_post'] ) ) {
			error_log( 'Markdown DB: content layout profile has no path_for_post callback.' );
			return false;
		}
		$frontmatter = $this->build_frontmatter( $post );
		$relative = call_user_func( $profile['path_for_post'], $post, $frontmatter, array( 'content_dir' => $this->content_dir, 'profile_id' => $profile['id'] ) );
		$relative = is_string( $relative ) ? $this->validate_profile_path( $relative ) : null;
		if ( null === $relative ) {
			error_log( 'Markdown DB: content layout profile returned an unsafe canonical path.' );
			return false;
		}
		return $relative;
	}

	/** @return string[] */
	private function profile_source_paths(): array {
		$profile = $this->content_layout();
		if ( empty( $profile['enumerate'] ) || ! is_callable( $profile['enumerate'] ) ) {
			return array();
		}
		$paths = call_user_func( $profile['enumerate'], $this->content_dir, array( 'profile_id' => $profile['id'] ) );
		$paths = is_iterable( $paths ) ? $paths : array();
		$result = array();
		foreach ( $paths as $path ) {
			if ( is_string( $path ) && null !== ( $path = $this->validate_profile_path( $path ) ) && null !== $this->profile_absolute_path( $path ) ) {
				$result[] = $path;
			}
		}
		sort( $result, SORT_STRING );
		return array_values( array_unique( $result ) );
	}

	private function apply_layout_mapping( object $post, string $relative_path ): void {
		$profile = $this->content_layout();
		if ( empty( $profile['map_source'] ) || ! is_callable( $profile['map_source'] ) ) {
			return;
		}
		$mapping = call_user_func( $profile['map_source'], $relative_path, (array) ( $post->_frontmatter ?? array() ), array( 'content_dir' => $this->content_dir, 'profile_id' => $profile['id'] ) );
		if ( ! is_array( $mapping ) ) {
			return;
		}
		foreach ( array( 'post_type', 'post_name', 'post_parent' ) as $field ) {
			if ( array_key_exists( $field, $mapping ) ) {
				$post->{$field} = 'post_parent' === $field ? (int) $mapping[ $field ] : (string) $mapping[ $field ];
			}
		}
		$post->_source_identity = (string) ( $mapping['source_identity'] ?? $relative_path );
		if ( '' === $post->_source_identity || str_contains( $post->_source_identity, '..' ) ) {
			$post->_source_identity = $relative_path;
		}
	}

	private function validate_profile_path( string $path ): ?string {
		$parts = explode( '/', str_replace( '\\', '/', trim( $path, '/' ) ) );
		$parts = array_values( array_filter( $parts, static fn( string $part ): bool => '.' !== $part && '' !== $part ) );
		$path = implode( '/', $parts );
		if ( '' === $path || in_array( '..', $parts, true ) || str_starts_with( $path, '_' ) || preg_match( '#(^|/)_#', $path ) ) {
			return null;
		}
		return $path;
	}

	private function profile_absolute_path( string $relative, bool $allow_missing = false ): ?string {
		$root = realpath( $this->content_dir );
		if ( false === $root ) {
			if ( ! $allow_missing || ! mkdir( $this->content_dir, 0755, true ) ) {
				return null;
			}
			$root = realpath( $this->content_dir );
		}
		$path = rtrim( $this->content_dir, '/' ) . '/' . $relative;
		$target = realpath( $allow_missing ? dirname( $path ) : $path );
		if ( false === $target || ( $target !== $root && ! str_starts_with( $target, $root . '/' ) ) ) {
			return null;
		}
		return $path;
	}

	private function record_profile_index( int $post_id, string $path ): void {
		if ( null !== $this->index_writer && false !== ( $mtime = @filemtime( $path ) ) && false !== ( $size = @filesize( $path ) ) ) {
			call_user_func( $this->index_writer, $post_id, $this->relative_path( $path ), (int) $mtime, (int) $size );
		}
	}

	/**
	 * Stage a profile write in a verified directory. PHP lacks openat(2), so this
	 * detects symlink and directory-identity changes immediately before and after
	 * the write and again before rename; any detected race is discarded.
	 */
	private function stage_profile_write( string $path, string $content ): ?string {
		$directory = dirname( $path );
		$identity = $this->profile_directory_identity( $directory );
		if ( null === $identity ) {
			return null;
		}
		$tmp = tempnam( $directory, '.markdown-db-' );
		if ( false === $tmp || false === file_put_contents( $tmp, $content, LOCK_EX ) || $identity !== $this->profile_directory_identity( $directory ) ) {
			if ( is_string( $tmp ) ) {
				@unlink( $tmp );
			}
			return null;
		}
		return $tmp;
	}

	private function commit_profile_write( string $tmp, string $path ): bool {
		$directory = dirname( $path );
		if ( null === $this->profile_directory_identity( $directory ) || ( file_exists( $path ) && is_link( $path ) ) ) {
			return false;
		}
		return @rename( $tmp, $path );
	}

	private function profile_directory_identity( string $directory ): ?string {
		$root = realpath( $this->content_dir );
		$real = realpath( $directory );
		if ( false === $root || false === $real || ( $real !== $root && ! str_starts_with( $real, $root . '/' ) ) ) {
			return null;
		}
		$current = rtrim( $this->content_dir, '/' );
		foreach ( explode( '/', ltrim( substr( $directory, strlen( $current ) ), '/' ) ) as $segment ) {
			if ( '' === $segment ) {
				continue;
			}
			$current .= '/' . $segment;
			if ( is_link( $current ) ) {
				return null;
			}
		}
		$stat = @lstat( $directory );
		return is_array( $stat ) ? $stat['dev'] . ':' . $stat['ino'] : null;
	}

	/**
	 * Resolve the parent directory for a post's file.
	 *
	 * Walks up the ancestor chain using the post resolver to build
	 * the full hierarchical path. If a parent post is currently stored
	 * as a leaf file (slug.md), promotes it to a directory (slug/index.md).
	 *
	 * @param string $type_dir  The post type root directory.
	 * @param int    $parent_id The post_parent ID (0 = top level).
	 * @return string The directory to write the file in.
	 */
	private function resolve_parent_dir( string $type_dir, int $parent_id ): string {
		if ( 0 === $parent_id || null === $this->post_resolver ) {
			return $type_dir;
		}

		// Build the ancestor chain (bottom-up, then reverse).
		$ancestors = array();
		$current_id = $parent_id;
		$seen = array(); // Guard against infinite loops.

		while ( $current_id > 0 && ! isset( $seen[ $current_id ] ) ) {
			$seen[ $current_id ] = true;

			$parent_post = call_user_func( $this->post_resolver, $current_id );
			if ( ! $parent_post ) {
				break;
			}

			$slug = $parent_post->post_name ?? '';
			if ( empty( $slug ) ) {
				$slug = (string) $current_id;
			}

			$ancestors[] = $this->sanitize_path( $slug );
			$current_id  = (int) ( $parent_post->post_parent ?? 0 );
		}

		// Reverse so we go from root → leaf.
		$ancestors = array_reverse( $ancestors );

		// Build the directory path, promoting leaf files along the way.
		$current_dir = $type_dir;
		foreach ( $ancestors as $slug ) {
			$target_dir  = $current_dir . '/' . $slug;
			$leaf_file   = $current_dir . '/' . $slug . '.md';
			$index_file  = $target_dir . '/index.md';

			if ( file_exists( $leaf_file ) && ! is_dir( $target_dir ) ) {
				// Promote leaf file to directory with index.md.
				mkdir( $target_dir, 0755, true );
				$this->observe_file_mutation( $leaf_file );
				$this->observe_file_mutation( $index_file );
				rename( $leaf_file, $index_file );
				$this->record_promoted_file( $index_file );
			} elseif ( file_exists( $leaf_file ) && is_dir( $target_dir ) && ! file_exists( $index_file ) ) {
				// Directory exists (has children) but the parent post is still
				// a sibling leaf file. Move it into the directory as index.md.
				$this->observe_file_mutation( $leaf_file );
				$this->observe_file_mutation( $index_file );
				rename( $leaf_file, $index_file );
				$this->record_promoted_file( $index_file );
			} elseif ( ! is_dir( $target_dir ) ) {
				mkdir( $target_dir, 0755, true );
			}

			$current_dir = $target_dir;
		}

		return $current_dir;
	}

	/**
	 * Record that a file was renamed during parent promotion.
	 *
	 * Updates the in-memory index for the duration of the request AND
	 * invokes the persistent index-writer callback so the SQLite
	 * `_markdown_file_index` row tracks the new path. Without the
	 * callback, warm boot would see the old path as deleted and the new
	 * path as new, churning the promoted post through a full delete-
	 * and-reinsert. See GitHub issue #68.
	 *
	 * Extracts the post ID from the new file's frontmatter. If the file
	 * has no parseable `id:` (shouldn't happen for renamed posts, but
	 * defend against corruption), silently returns — the next warm boot
	 * will detect the mismatch and recover via heal / sync.
	 *
	 * @param string $absolute_file_path The renamed file's absolute path.
	 */
	private function record_promoted_file( string $absolute_file_path ): void {
		$promoted_id = $this->extract_id_from_file( $absolute_file_path );
		if ( ! $promoted_id ) {
			return;
		}

		// Keep the in-memory index in sync so same-request lookups see the
		// post at its new path.
		if ( null !== $this->index ) {
			$this->index[ $promoted_id ] = $absolute_file_path;
		}

		if ( null === $this->index_writer ) {
			return;
		}

		// Relative-to-content-dir path matches what the loader stores when
		// it rebuilds the index from disk, so later mtime/size comparisons
		// see the same string the driver's update_file_index uses.
		$relative_path = $absolute_file_path;
		$prefix        = $this->content_dir . '/';
		if ( str_starts_with( $absolute_file_path, $prefix ) ) {
			$relative_path = substr( $absolute_file_path, strlen( $prefix ) );
		}

		$mtime = @filemtime( $absolute_file_path );
		$size  = @filesize( $absolute_file_path );
		if ( false === $mtime || false === $size ) {
			// Stat failed — defer to the next sync rather than writing
			// bogus values.
			return;
		}

		call_user_func( $this->index_writer, (int) $promoted_id, $relative_path, (int) $mtime, (int) $size );
	}

	/**
	 * Clean up empty directories after a file is deleted or moved.
	 *
	 * Walks up from $dir to $stop_dir, removing empty directories.
	 *
	 * @param string $dir      The directory to start cleaning from.
	 * @param string $stop_dir Stop when reaching this directory (don't delete it).
	 */
	private function cleanup_empty_dirs( string $dir, string $stop_dir ): void {
		while ( $dir !== $stop_dir && str_starts_with( $dir, $stop_dir ) ) {
			// Check if directory is empty (no files, no subdirs).
			$entries = @scandir( $dir );
			if ( false === $entries ) {
				break;
			}

			// Filter out . and ..
			$entries = array_diff( $entries, array( '.', '..' ) );

			if ( ! empty( $entries ) ) {
				break; // Directory has contents, stop.
			}

			@rmdir( $dir );
			$dir = dirname( $dir );
		}
	}

	/**
	 * Guess the post type directory from a file path.
	 *
	 * The post type dir is the first directory after content_dir.
	 *
	 * @param string $file_path
	 * @return string
	 */
	private function guess_type_dir( string $file_path ): string {
		$relative = $this->relative_path( $file_path );
		$parts    = explode( '/', $relative );
		if ( ! empty( $parts[0] ) ) {
			return $this->content_dir . '/' . $parts[0];
		}
		return $this->content_dir;
	}


	/**
	 * Get a file path relative to the content directory (for logging).
	 *
	 * @param string $path Absolute file path.
	 * @return string Relative path.
	 */
	private function relative_path( string $path ): string {
		if ( str_starts_with( $path, $this->content_dir . '/' ) ) {
			return substr( $path, strlen( $this->content_dir ) + 1 );
		}
		$root = realpath( $this->content_dir );
		if ( false !== $root && str_starts_with( $path, $root . '/' ) ) {
			return substr( $path, strlen( $root ) + 1 );
		}
		return $path;
	}

	/**
	 * Find a markdown file path by post ID.
	 *
	 * Uses the in-memory index for fast lookups, rebuilds it on first access.
	 *
	 * @param int $post_id The post ID.
	 * @return string|null File path, or null if not found.
	 */
	private function find_file_by_id( int $post_id ): ?string {
		if ( null === $this->index ) {
			$this->rebuild_index();
		}

		return $this->index[ $post_id ] ?? null;
	}

	/**
	 * Rebuild the in-memory index by scanning all markdown files recursively.
	 *
	 * Deduplicates by ID: when two files share the same ID,
	 * the most recently modified file wins. See GitHub issue #9.
	 */
	private function rebuild_index(): void {
		// Preserve any pre-claimed entries (e.g. set by write_post before
		// calling rebuild during a lazy init). Pre-claimed paths are the
		// authoritative canonical location for those IDs — any other disk
		// copy discovered during the scan is stale and should be unlinked,
		// regardless of path depth. See GitHub issue #70.
		$claimed     = is_array( $this->index ) ? $this->index : array();
		$this->index = array();
		$mtimes      = array();

		if ( ! is_dir( $this->content_dir ) ) {
			$this->index = $claimed;
			return;
		}

		// The corpus is walked in one place. This asks that walk what exists
		// and what identity each file carries, rather than keeping a second
		// opinion about either.
		$entries = array();
		foreach ( $this->get_markdown_file_manifest_iterator( false, null ) as $entry ) {
			$entries[] = $entry;
		}

		foreach ( $entries as $entry ) {
			$file = $entry['absolute'];
			$post = $this->read_file( $file, true, $entry['parent_id'] );
			$id   = (int) ( $post->ID ?? 0 );
			if ( $id < 1 ) {
				continue;
			}

			// If the caller pre-claimed a canonical path for this ID,
			// honor it unconditionally. Any competing copy is stale.
			if ( isset( $claimed[ $id ] ) ) {
				$canonical = $claimed[ $id ];
				if ( $file !== $canonical ) {
					$this->safe_unlink( $file );
					$this->cleanup_empty_dirs( dirname( $file ), $this->content_dir );
				}
				$this->index[ $id ] = $canonical;
				continue;
			}

			if ( ! isset( $this->index[ $id ] ) ) {
				$this->index[ $id ]  = $file;
				$mtimes[ $id ]       = $entry['mtime'];
				continue;
			}

			// Prefer most recently modified — the freshest write on disk is
			// the authoritative copy. See GitHub issues #31 and #70. The walk
			// already looked at each file, so its mtime is reused here.
			$existing       = $this->index[ $id ];
			$existing_mtime = $mtimes[ $id ] ?? @filemtime( $existing );
			$new_mtime      = $entry['mtime'];
			if ( false === $existing_mtime && false === $new_mtime ) {
				continue;
			}
			if ( false === $existing_mtime || $new_mtime > $existing_mtime ) {
				$this->safe_unlink( $existing );
				$this->cleanup_empty_dirs( dirname( $existing ), $this->content_dir );
				$this->index[ $id ] = $file;
				$mtimes[ $id ]      = $new_mtime;
				continue;
			}
			$this->safe_unlink( $file );
			$this->cleanup_empty_dirs( dirname( $file ), $this->content_dir );
		}

		// Ensure any claimed entries that didn't match a disk scan still
		// persist in the index. (Normal case: they did match and got set
		// above; this handles the edge where the claimed file is on disk
		// but in a post-type dir that was skipped or missed.)
		foreach ( $claimed as $id => $path ) {
			if ( ! isset( $this->index[ $id ] ) ) {
				$this->index[ $id ] = $path;
			}
		}
	}

	/**
	 * Extract the post ID from a markdown file's frontmatter.
	 *
	 * Uses a fast regex scan instead of full YAML parsing.
	 *
	 * @param string $file_path Path to the markdown file.
	 * @return int|null The post ID, or null.
	 */
	private function extract_id_from_file( string $file_path ): ?int {
		// Identity is a frontmatter field, so it is read from the frontmatter
		// rather than from a fixed number of bytes at the top of the file. A
		// window wide enough for most files silently loses the identity of the
		// rest, and can find a line in the body that reads like frontmatter.
		$raw = $this->read_frontmatter_only( $file_path );
		if ( ! is_string( $raw ) || '' === $raw || ! preg_match( '/^---\n(.+?)\n---/s', $raw, $block ) ) {
			return null;
		}
		$frontmatter = $block[1];

		if ( preg_match( '/^id:\s*(\d+)\s*$/m', $frontmatter, $m ) ) {
			return (int) $m[1];
		}

		if ( preg_match( '/^wordpress:\s*$.*?^  id:\s*(\d+)\s*$/ms', $frontmatter, $m ) ) {
			return (int) $m[1];
		}

		return null;
	}

	/**
	 * Parse a markdown file into a post-like object.
	 *
	 * Note: post_parent is NOT set here — it's derived from the directory
	 * structure by get_all_posts(). The caller is responsible for setting it.
	 *
	 * When $metadata_only is true, only frontmatter is parsed — the body
	 * content is skipped entirely (post_content set to empty string). This
	 * is used during boot to populate the SQLite index without reading
	 * file bodies. Content is lazy-loaded from disk on demand.
	 * See: Index/Map Architecture design doc.
	 *
	 * @param string $file_path     Path to the markdown file.
	 * @param bool   $metadata_only If true, skip body content (for index-only boot).
	 * @return object|null A post object, or null on parse failure.
	 */
	private function parse_file( string $file_path, bool $metadata_only = false ): ?object {
		if ( $metadata_only ) {
			// Fast path: read only enough of the file to get the frontmatter.
			// Avoids reading potentially large content bodies during boot.
			$raw = $this->read_frontmatter_only( $file_path );
		} else {
			$raw = file_get_contents( $file_path );
		}

		if ( false === $raw || '' === $raw ) {
			return null;
		}

		// Split frontmatter and content.
		if ( ! preg_match( '/^---\n(.+?)\n---\n\n?(.*)/s', $raw, $m ) ) {
			return null;
		}

		$frontmatter = WP_Markdown_Yaml::decode_yaml( $m[1] );
		// write_post() terminates every body with one LF; remove only that terminator.
		$content     = $metadata_only ? '' : ( str_ends_with( $m[2], "\n" ) ? substr( $m[2], 0, -1 ) : $m[2] );

		if ( ! $frontmatter ) {
			return null;
		}

		$context = array(
			'operation' => 'import',
			'file_path' => $file_path,
			'profile'   => $this->frontmatter_profile,
		);
		$profile = WP_Markdown_Frontmatter_Profiles::resolve_for_import( $frontmatter, $content, $context );
		$data    = array();
		if ( ! empty( $profile['import_post_data'] ) && is_callable( $profile['import_post_data'] ) ) {
			$data = (array) call_user_func( $profile['import_post_data'], $frontmatter, $content, array_merge( $context, array( 'profile_id' => $profile['id'] ?? '' ) ) );
		}

		$post = (object) $data;
		$post->post_content = (string) ( $post->post_content ?? $content );
		// Derive slug from the filename when the frontmatter has none.
		// Supports the "just drop a file" workflow — an AI agent or git
		// pull creating `wiki/my-topic.md` gets `my-topic` as post_name
		// without needing a slug field. `index.md` files (used when a
		// post has children) fall back to the parent directory name.
		// See GitHub issue #42.
		if ( '' === $post->post_name && '' !== $file_path ) {
			$stem = basename( $file_path, '.md' );
			if ( 'index' === $stem ) {
				$stem = basename( dirname( $file_path ) );
			}
			$post->post_name = $stem;
		}
		$post->ID                    = (int) ( $post->ID ?? 0 );
		$post->post_title            = (string) ( $post->post_title ?? '' );
		$post->post_status           = (string) ( $post->post_status ?? 'draft' );
		$post->post_type             = (string) ( $post->post_type ?? 'post' );
		$post->post_author           = (int) ( $post->post_author ?? 0 );
		$post->post_date             = (string) ( $post->post_date ?? '0000-00-00 00:00:00' );
		$post->post_date_gmt         = (string) ( $post->post_date_gmt ?? $post->post_date );
		$post->post_modified         = (string) ( $post->post_modified ?? $post->post_date );
		$post->post_modified_gmt     = (string) ( $post->post_modified_gmt ?? $post->post_modified );
		$post->post_name             = (string) ( $post->post_name ?? '' );
		$post->post_parent           = (int) ( $post->post_parent ?? 0 ); // Frontmatter fallback; overridden by directory structure in get_all_posts().
		$post->menu_order            = (int) ( $post->menu_order ?? 0 );
		$post->comment_status        = (string) ( $post->comment_status ?? 'open' );
		$post->ping_status           = (string) ( $post->ping_status ?? 'open' );
		$post->post_excerpt          = (string) ( $post->post_excerpt ?? '' );
		$post->post_content_filtered = (string) ( $post->post_content_filtered ?? '' );
		$post->post_mime_type        = (string) ( $post->post_mime_type ?? '' );
		$post->post_password         = (string) ( $post->post_password ?? '' );
		$post->to_ping               = (string) ( $post->to_ping ?? '' );
		$post->pinged                = (string) ( $post->pinged ?? '' );
		$post->guid                  = (string) ( $post->guid ?? '' );
		$post->comment_count         = (int) ( $post->comment_count ?? 0 );
		$post->filter                = (string) ( $post->filter ?? 'raw' );

		// Store the source file path on the post object.
		// Used by the loader to populate the _markdown_file_index table.
		$post->_source_file = $file_path;
		$post->_frontmatter = $frontmatter;
		if ( is_string( $frontmatter['source_identity'] ?? null ) && '' !== $frontmatter['source_identity'] ) {
			$post->_source_identity = $frontmatter['source_identity'];
		}
		$post->_frontmatter_profile = (string) ( $profile['id'] ?? '' );

		// Extract meta from frontmatter (key-value pairs).
		// These will be INSERTed into wp_postmeta by the loader.
		$post->_frontmatter_meta = isset( $post->_frontmatter_meta ) && is_array( $post->_frontmatter_meta ) ? $post->_frontmatter_meta : array();

		// Extract terms from frontmatter (taxonomy → [slugs]).
		// These will be resolved and INSERTed into wp_term_relationships by the loader.
		$post->_frontmatter_terms = isset( $post->_frontmatter_terms ) && is_array( $post->_frontmatter_terms ) ? $post->_frontmatter_terms : array();

		return $post;
	}

	/**
	 * Read only the frontmatter portion of a markdown file.
	 *
	 * Reads the file in chunks until the closing `---` delimiter is found,
	 * avoiding reading the potentially large content body. Returns the raw
	 * string up to and including the closing delimiter.
	 *
	 * @param string $file_path Path to the markdown file.
	 * @return string|false The frontmatter portion (with delimiters), or false on failure.
	 */
	private function read_frontmatter_only( string $file_path ) {
		$handle = fopen( $file_path, 'r' );
		if ( ! $handle ) {
			return false;
		}

		// Read in 4KB chunks — frontmatter is typically < 1KB.
		$buffer = '';
		$chunk_size = 4096;
		$found_end = false;

		// Read the opening "---\n".
		$first_line = fgets( $handle );
		if ( false === $first_line || trim( $first_line ) !== '---' ) {
			fclose( $handle );
			return false;
		}
		$buffer = $first_line;

		// Read until we find the closing "---\n".
		while ( ! feof( $handle ) ) {
			$line = fgets( $handle );
			if ( false === $line ) {
				break;
			}
			$buffer .= $line;
			if ( trim( $line ) === '---' ) {
				$found_end = true;
				break;
			}
		}

		fclose( $handle );

		if ( ! $found_end ) {
			return false;
		}

		// Append an empty content section so the regex in parse_file() matches.
		$buffer .= "\n";

		return $buffer;
	}

	/**
	 * Read the content body from a markdown file (everything after frontmatter).
	 *
	 * Used by the driver for lazy-loading post_content on demand.
	 * Only reads the body — skips the frontmatter header.
	 *
	 * @param string $file_path Absolute path to the markdown file.
	 * @return string|null The content body, or null on failure.
	 */
	public function read_content_from_file( string $file_path ): ?string {
		if ( ! file_exists( $file_path ) ) {
			return null;
		}

		$raw = file_get_contents( $file_path );
		if ( false === $raw ) {
			return null;
		}

		// Split frontmatter and content.
		if ( ! preg_match( '/^---\n.+?\n---\n\n?(.*)/s', $raw, $m ) ) {
			return null;
		}

		return str_ends_with( $m[1], "\n" ) ? substr( $m[1], 0, -1 ) : $m[1];
	}

	/**
	 * Inject or replace the `id:` field in a markdown file's frontmatter.
	 *
	 * Used by the loader when it auto-assigns an ID to a file that was
	 * dropped on disk without one (via AI agents, git pulls, or hand-
	 * written content). The rewrite is surgical — only the `id:` line is
	 * touched; body content, other frontmatter keys, and their order are
	 * preserved.
	 *
	 * The write is atomic (tmp file + rename) so a crash mid-write cannot
	 * leave a partially-updated file.
	 *
	 * See GitHub issue #42.
	 *
	 * @param string $file_path Absolute path to the .md file.
	 * @param int    $id        The post ID to inject.
	 * @return bool True on successful write, false on any failure.
	 */
	public function inject_id_into_frontmatter( string $file_path, int $id ): bool {
		if ( $id <= 0 || ! file_exists( $file_path ) ) {
			return false;
		}

		$raw = file_get_contents( $file_path );
		if ( false === $raw ) {
			return false;
		}

		// Split the file into frontmatter block + body. Frontmatter is
		// between a leading `---\n` and the next `---\n` on its own line.
		if ( ! preg_match( '/\A---\n(.*?)\n---\n?(.*)\z/s', $raw, $m ) ) {
			// No frontmatter block at all — prepend a minimal one.
			$new = "---\nid: {$id}\n---\n\n" . $raw;
			return $this->atomic_write( $file_path, $new );
		}

		$frontmatter = $m[1];
		$separator   = "---\n";
		// Preserve the original trailing newline/whitespace after the closing `---`.
		$after_close = '';
		if ( preg_match( '/\A---\n.*?\n(---\n?)(.*)\z/s', $raw, $m2 ) ) {
			$separator   = $m2[1];
			$after_close = $m2[2];
		} else {
			$after_close = $m[2];
		}

		// Replace existing `id:` line, or prepend one at the top of the block.
		$lines       = explode( "\n", $frontmatter );
		$id_replaced = false;
		foreach ( $lines as $i => $line ) {
			if ( preg_match( '/^id\s*:/i', $line ) ) {
				$lines[ $i ] = "id: {$id}";
				$id_replaced = true;
				break;
			}
		}
		if ( ! $id_replaced ) {
			array_unshift( $lines, "id: {$id}" );
		}

		$new_frontmatter = implode( "\n", $lines );
		$new_raw         = "---\n{$new_frontmatter}\n{$separator}{$after_close}";

		return $this->atomic_write( $file_path, $new_raw );
	}

	/**
	 * Atomically write content to a file.
	 *
	 * Writes to a temp file in the same directory and renames to the
	 * target. Rename is atomic on POSIX, so readers never observe a
	 * partially-written file.
	 *
	 * @param string $file_path Target file path.
	 * @param string $content   Content to write.
	 * @return bool True on success.
	 */
	private function atomic_write( string $file_path, string $content ): bool {
		$tmp = $file_path . '.' . uniqid() . '.tmp';
		if ( false === @file_put_contents( $tmp, $content, LOCK_EX ) ) {
			return false;
		}
		if ( ! @rename( $tmp, $file_path ) ) {
			@unlink( $tmp );
			return false;
		}
		return true;
	}

	/**
	 * Build the YAML frontmatter array from a post object.
	 *
	 * Includes `parent` as a fallback for flat layouts; directory structure
	 * takes precedence on read. See GitHub issue #14.
	 *
	 * Extension point: the assembled frontmatter array is passed through the
	 * `markdown_db_frontmatter` filter before being returned. Consumers that
	 * want to contribute additional fields — derived attribution, domain
	 * metadata, anything that should travel with the file rather than live
	 * in post meta — should hook that filter. Fields added via the filter
	 * are included in the written YAML; removing or renaming core fields
	 * (id, title, status, etc.) is unsupported and will break round-trip.
	 *
	 * @param object $post A WordPress post row.
	 * @return array Frontmatter key-value pairs.
	 */
	private function build_frontmatter( object $post ): array {
		$native_frontmatter = $this->build_native_frontmatter( $post );
		$context            = array(
			'operation'          => 'export',
			'profile'            => $this->frontmatter_profile,
			'native_frontmatter' => $native_frontmatter,
		);
		$profile            = WP_Markdown_Frontmatter_Profiles::resolve_for_export( $post, $context );

		if ( ! empty( $profile['export_frontmatter'] ) && is_callable( $profile['export_frontmatter'] ) ) {
			$fm = (array) call_user_func( $profile['export_frontmatter'], $post, array_merge( $context, array( 'profile_id' => $profile['id'] ?? '' ) ) );
		} else {
			$fm = $native_frontmatter;
		}

		if ( function_exists( 'apply_filters' ) ) {
			$fm = apply_filters( 'markdown_db_frontmatter', $fm, $post, (string) ( $profile['id'] ?? '' ) );
		}

		return $fm;
	}

	/**
	 * Build the native WordPress-safe YAML frontmatter array from a post object.
	 *
	 * @param object $post A WordPress post row.
	 * @return array Frontmatter key-value pairs.
	 */
	private function build_native_frontmatter( object $post ): array {
		$fm = array();

		$fm['id']             = (int) ( $post->ID ?? 0 );
		if ( is_string( $post->_source_identity ?? null ) && '' !== $post->_source_identity ) {
			$fm['source_identity'] = $post->_source_identity;
		}
		$fm['title']          = $post->post_title ?? '';
		$fm['status']         = $post->post_status ?? 'draft';
		$fm['type']           = $post->post_type ?? 'post';
		$fm['author']         = (int) ( $post->post_author ?? 0 );
		$fm['date']           = $post->post_date ?? '';
		$fm['date_gmt']       = $post->post_date_gmt ?? '';
		$fm['modified']       = $post->post_modified ?? '';
		$fm['modified_gmt']   = $post->post_modified_gmt ?? '';
		$fm['slug']           = $post->post_name ?? '';
		$fm['parent']         = (int) ( $post->post_parent ?? 0 );
		$fm['menu_order']     = (int) ( $post->menu_order ?? 0 );
		$fm['comment_status'] = $post->comment_status ?? 'open';
		$fm['ping_status']    = $post->ping_status ?? 'open';
		$fm['guid']           = $post->guid ?? '';
		$fm['comment_count']  = (int) ( $post->comment_count ?? 0 );

		// Excerpt — only include if non-empty.
		$excerpt = $post->post_excerpt ?? '';
		if ( ! empty( $excerpt ) ) {
			$fm['excerpt'] = $excerpt;
		}

		// Password — only include if set.
		$password = $post->post_password ?? '';
		if ( ! empty( $password ) ) {
			$fm['password'] = $password;
		}

		// MIME type — only include if set (attachments).
		$mime = $post->post_mime_type ?? '';
		if ( ! empty( $mime ) ) {
			$fm['mime_type'] = $mime;
		}

		$id = (int) ( $post->ID ?? 0 );

		// Post meta — fetch from SQLite and include in frontmatter.
		// Each post's .md file is self-contained. See GitHub issue #6.
		if ( $id > 0 && ( null !== $this->meta_resolver || isset( $post->_frontmatter_meta ) ) ) {
			$meta_rows = isset( $post->_frontmatter_meta ) ? $this->frontmatter_meta_rows( (array) $post->_frontmatter_meta ) : call_user_func( $this->meta_resolver, $id );
			if ( ! empty( $meta_rows ) ) {
				/**
				 * Filter the allowlist of internal (underscore-prefixed)
				 * meta keys to include in markdown frontmatter.
				 *
				 * WordPress meta starting with `_` is hidden from the
				 * admin UI and normally skipped by MDI, but a handful
				 * carry data users genuinely want to travel with the
				 * file: featured images (`_thumbnail_id`), page
				 * templates (`_wp_page_template`), etc.
				 *
				 * Return an array of internal meta keys to include.
				 *
				 * @since 0.3.0
				 *
				 * @param string[] $allowlist Internal meta keys to include
				 *                            in the frontmatter.
				 * @param object   $post      The post being serialized.
				 */
				$internal_meta_allowlist = apply_filters(
					'markdown_db_internal_meta_allowlist',
					array( '_thumbnail_id', '_wp_page_template' ),
					$post
				);
				$allowed_internal = array_flip( $internal_meta_allowlist );

				// Group by key so multi-row meta survives the round-trip.
				// WordPress allows multiple rows with the same meta_key per
				// post (ACF repeaters, WooCommerce product attributes, raw
				// `add_post_meta` calls without unique=true). A flat
				// $meta[$key] = $value assignment loses all but the last
				// row. See GitHub issue #20.
				$grouped = array();
				foreach ( $meta_rows as $row ) {
					$key   = $row->meta_key ?? '';
					$value = $row->meta_value ?? '';

					if ( '' === $key ) {
						continue;
					}

					// Skip internal meta unless it's explicitly allowlisted.
					if ( str_starts_with( $key, '_' ) && ! isset( $allowed_internal[ $key ] ) ) {
						continue;
					}

					$grouped[ $key ][] = $value;
				}

				if ( ! empty( $grouped ) ) {
					$meta = array();
					foreach ( $grouped as $key => $values ) {
						// Single row → scalar (cleanest YAML); multiple → array.
						$meta[ $key ] = ( count( $values ) === 1 ) ? $values[0] : $values;
					}
					$fm['meta'] = $meta;
				}
			}
		}

		// Terms — fetch from SQLite and group by taxonomy.
		if ( $id > 0 && ( null !== $this->terms_resolver || isset( $post->_frontmatter_terms ) ) ) {
			$term_rows = isset( $post->_frontmatter_terms ) ? $this->frontmatter_term_rows( (array) $post->_frontmatter_terms ) : call_user_func( $this->terms_resolver, $id );
			if ( ! empty( $term_rows ) ) {
				$terms = array();
				foreach ( $term_rows as $row ) {
					$taxonomy = $row->taxonomy ?? '';
					$slug     = $row->slug ?? '';
					if ( ! empty( $taxonomy ) && ! empty( $slug ) ) {
						$terms[ $taxonomy ][] = $slug;
					}
				}
				if ( ! empty( $terms ) ) {
					$fm['terms'] = $terms;
				}
			}
		}

		return $fm;
	}

	/** Normalize adapter-provided meta into the resolver row contract. */
	private function frontmatter_meta_rows( array $meta ): array {
		$rows = array();
		foreach ( $meta as $key => $values ) {
			foreach ( is_array( $values ) ? $values : array( $values ) as $value ) {
				$rows[] = (object) array( 'meta_key' => (string) $key, 'meta_value' => $value );
			}
		}
		return $rows;
	}

	/** Normalize adapter-provided terms into the resolver row contract. */
	private function frontmatter_term_rows( array $terms ): array {
		$rows = array();
		foreach ( $terms as $taxonomy => $slugs ) {
			foreach ( is_array( $slugs ) ? $slugs : array( $slugs ) as $slug ) {
				$rows[] = (object) array( 'taxonomy' => (string) $taxonomy, 'slug' => (string) $slug );
			}
		}
		return $rows;
	}

	private function sanitize_path( string $name ): string {
		// Remove anything that's not alphanumeric, dash, or underscore.
		$name = preg_replace( '/[^a-zA-Z0-9_-]/', '-', $name );
		$name = trim( $name, '-' );
		return $name ?: 'unnamed';
	}

	/**
	 * Remove all files and subdirectories in a directory (recursive).
	 *
	 * @param string $dir Directory path.
	 */
	private function remove_directory_recursive( string $dir ): void {
		if ( ! is_dir( $dir ) || is_link( $dir ) ) {
			return;
		}

		$entries = scandir( $dir );
		if ( false === $entries ) {
			return;
		}

		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}

			$path = $dir . '/' . $entry;
			if ( is_link( $path ) ) {
				continue;
			}
			if ( is_dir( $path ) ) {
				$this->remove_directory_recursive( $path );
				@rmdir( $path );
			} else {
				$this->safe_unlink( $path );
			}
		}
	}

	private function remove_directory_recursive_strict( string $dir ): void {
		if ( ! file_exists( $dir ) ) { return; }
		if ( ! is_dir( $dir ) || is_link( $dir ) ) { throw new RuntimeException( 'Markdown DB: Canonical content path is not a safe directory.' ); }
		$entries = scandir( $dir );
		if ( false === $entries ) { throw new RuntimeException( 'Markdown DB: Failed to inspect canonical content directory.' ); }
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) { continue; }
			$path = $dir . '/' . $entry;
			if ( is_link( $path ) ) { throw new RuntimeException( 'Markdown DB: Refusing to truncate a linked content path.' ); }
			if ( is_dir( $path ) ) {
				$this->remove_directory_recursive_strict( $path );
				if ( ! rmdir( $path ) ) { throw new RuntimeException( 'Markdown DB: Failed to remove canonical content directory.' ); }
			} elseif ( ! $this->safe_unlink( $path ) ) {
				throw new RuntimeException( 'Markdown DB: Failed to remove canonical content file.' );
			}
		}
	}

	/**
	 * Get the content directory path.
	 *
	 * @return string
	 */
	public function get_content_dir(): string {
		return $this->content_dir;
	}

	public function delete_relative_path( string $relative ): bool {
		$relative = $this->validate_profile_path( $relative );
		return null !== $relative && $this->safe_unlink( rtrim( $this->content_dir, '/\\' ) . DIRECTORY_SEPARATOR . $relative );
	}

	/**
	 * Get the excluded post types.
	 *
	 * @return string[]
	 */
	public function get_excluded_types(): array {
		return $this->excluded_types;
	}

	/**
	 * Check if a post type should be stored as markdown.
	 *
	 * All types are stored unless explicitly excluded.
	 *
	 * @param string $post_type The post type slug.
	 * @return bool
	 */
	public function is_markdown_type( string $post_type ): bool {
		return ! in_array( $post_type, $this->excluded_types, true );
	}
}
