# Changelog

## [0.13.9] - 2026-09-23

### Changed
- Internal improvements

## [0.13.8] - 2026-09-23

### Fixed
- never reissue a generic-table AUTO_INCREMENT value

## [0.13.7] - 2026-09-23

### Changed
- fast option inserts and shared reads to end lock-timeout failures

### Fixed
- accept double-quoted string literals and doubled-quote escapes

## [0.13.6] - 2026-09-23

### Fixed
- support ORDER BY on bounded single-table writes

## [0.13.5] - 2026-09-22

### Reverted
- frontmatter no longer acts as a second writer for post meta; the table store remains its single owner

## [0.13.4] - 2026-09-21

### Fixed
- stop discarding private post meta from markdown frontmatter
- keep the drop-in constructible during WP-CLI's fast db bootstrap

## [0.13.3] - 2026-09-18

### Fixed
- collect interrupted-write temp files with their generation

## [0.13.2] - 2026-09-18

### Fixed
- delete partitioned rows and collect orphan generations
- fail closed on indeterminate option reads

## [0.13.1] - 2026-09-13

### Changed
- correct materialized snapshot scan expectations
- Prove native transactional table capabilities
- Improve native SQL and WordPress workload compatibility
- Integrate native multisite repair stack
- support measured calendar query forms
- bootstrap fresh multisite state
- compose correlated subqueries and grouped UNIONs
- integrate WordPress query pipeline repairs
- cache normalized native predicate values
- avoid redundant post scan allocations
- harden obsidian bursty benchmark
- reuse witnessed indexes for non-key updates
- reuse manifest observations and bypass disabled profiling
- index equality candidates in native request snapshots
- filter native post candidates and expose verified workload costs
- skip catalogue publication during post allocation
- rescan the corpus only when the index cannot prove absence
- bound native post work to what each statement needs

### Fixed
- Fix native option and atomic claim mutations
- serialize reconciliation key bootstrap
- support native session aliases and verify REPLACE parity
- match LIKE against bodies that contain non-ASCII bytes
- write child posts to their canonical hierarchical path
- order posts by their modification columns
- share multisite transaction journals
- journal native post mutations
- compare missing-table outcomes
- preserve native transaction and lock semantics
- qualify snapshot schemas
- wire SQL snapshot input mode
- reject compound write subqueries
- require complete scoped post reads
- retain unique proof after indexed append
- serialize native post mutations
- verify post ownership before removing cached paths
- avoid WP-CLI path collision

## [0.13.0] - 2026-09-02

### Added
- complete native SQL coverage
- execute full-source equality joins
- evaluate scalar select expressions
- compare signed meta values
- execute WordPress search relevance
- rank rows by a LIKE match
- report ungrouped aggregates
- collapse DISTINCT rows on a single table
- allow a conjunction inside an OR
- answer range and BETWEEN comparisons
- serve canonical files without SQLite by default
- classify table durability

### Changed
- support PHP without mysqli
- support SQLite fuzzing on PHP 8.3
- fuzz the full database surface
- fuzz the native SQL surface
- report native MySQL surface coverage
- normalize duplicate keys once per index
- trust validated snapshot rows once
- reuse complete snapshot rows
- defer replace index rebuilds
- add primary SQLite decision rig
- use native scalar ordering
- normalize native sort keys once
- centralize native snapshot queries
- reuse native table snapshots per request
- profile plugin inventory operations
- reuse query compatibility comparison
- add seeded native SQLite differential
- benchmark concurrent database reads
- benchmark transactional plugin writes
- validate benchmark rig component paths
- seed native benchmark runtime
- attest benchmark database backend
- benchmark production query shapes

### Fixed
- cook markdown-database-integration
- keep runtime benchmark outside file profile
- validate generic text predicates
- execute production plugin predicates

## [0.12.0] - 2026-08-30

### Added
- apply multi-row INSERT VALUES as one statement
- let WordPress install itself into canonical storage
- dynamic defaults and comparison OR-groups in DML
- server variable, status, and DATABASE() introspection
- COUNT and SUM aggregates grouped over a JOIN
- execute tables keyed by an exact string primary key
- ENUM columns, CREATE TABLE IF NOT EXISTS, and DROP TABLE
- CALC_FOUND_ROWS with COUNT(*) and indexed column ordering
- default ORDER BY direction and trailing terminator
- unqualified JOIN columns and COUNT(*) over JOINs
- IS NOT NULL and indexed varchar-only scans
- indexed varchar columns filter by exact ASCII
- CREATE INDEX on persisted plugin tables
- INSERT ON DUPLICATE KEY UPDATE for snapshot tables
- residual equality scans for numeric columns
- LEFT JOIN ON filters, IS NULL, and ORDER BY col+0
- LEFT JOIN, unaliased tables, and JOIN FOUND_ROWS
- honor LIMIT on bounded equality JOINs
- INSERT IGNORE skips duplicate unique keys
- treat false constant predicates as empty
- INSERT SELECT literals FROM DUAL
- ADD INDEX and SHOW INDEX WHERE
- accept decimal SQL literals
- enforce ASCII prefix unique keys
- negate IN and LIKE
- disjoin LIKE across columns
- filter ASCII LIKE predicates
- persist wp_posts mutations as markdown
- look up unique char/varchar columns
- enforce exact ASCII unique keys
- default the canonical store to wp-content/db
- composite order with an ASCII collation guard
- filter inequality and same-column OR
- mutate core snapshot tables
- resolve canonical posts by slug
- support native table alterations
- support native generic table writes
- support native transaction boundaries
- support native plugin activation
- support native generic inserts
- support native table creation
- add native schema introspection
- boot WordPress on native canonical storage
- execute bounded native equality joins
- compose native partitioned plugin tables

### Changed
- declare native comparison workloads
- add native backend comparison rigs
- compact persisted option catalogue
- index empty table predicates
- scope residual post type reads
- cache unbounded table reads
- cache keyed table snapshots
- witness warm table snapshots
- verify only served post entries
- persist verified option catalogue
- persist verified post catalogue
- read each file's frontmatter once when reading metadata
- delete the walk nothing calls
- read every post through the shared walk
- walk the corpus once for reads and writes
- delete the legacy layout flag
- let a discovered file carry the look its discovery took
- say how a read is ordered, bounded and projected once
- hold what the corpus said in one catalogue
- give file identity and its verification one owner
- read each manifest entry with a single stat
- resolve a post looked up by identity straight to its file
- reuse the parse of an unchanged Markdown post
- answer bounded reads without decoding the whole snapshot
- separate mutation statements, INSERT parsing and the YAML codec
- seed core roles in the native lifecycle fixture
- share integer typing and DML routing
- group inc files by backend
- scope canonical post reads by type
- index persisted snapshot tables
- resolve canonical option mutations by path
- activate corpus plugins in dependency order
- probe native transaction durability
- extend native lifecycle coverage
- add native WordPress lifecycle gate
- Revert "refactor: remove SQLite runtime"
- Revert "test: add native request compatibility probe"
- reuse native schema contracts
- centralize native query planning
- simplify native option mutations
- scale native query execution

### Fixed
- bound primary index bootstrap
- support native snapshot table replace
- isolate canonical table writers
- read a post's identity from its frontmatter
- recover only journals whose writer is gone
- recognize a created core table by name
- type integer column defaults on post insert
- honor quoting in native statement separators
- support native option deletion
- resolve hashed option collation
- bind native post reads to file identity
- guard SQLite wp db check
- preserve primary bootstrap diagnostics

## [0.11.5] - 2026-08-25

### Fixed
- finalize invalid post reconciliation

## [0.11.4] - 2026-08-25

### Fixed
- retry contended post writes

## [0.11.3] - 2026-08-25

### Changed
- Execute COUNT(*) natively
- Fail closed on incomplete reconstruction
- Register generated core snapshots natively
- Gate concurrent warm synchronization
- Bound contended warm snapshot hydration
- Fail closed for partitioned plugin tables
- Discover persisted plugin schemas natively
- Generate native core schema catalog
- Query canonical comments natively

### Fixed
- stop tracking generated release zip
- keep warm bootstrap read-only

## [0.11.2] - 2026-08-25

### Changed
- Bound partition temp cleanup scans
- Cover hard-linked native posts
- Query canonical Markdown posts natively

## [0.11.1] - 2026-08-24

### Changed
- Update vulnerable CommonMark dependency

## [0.11.0] - 2026-08-24

### Changed
- Execute conjunctive native predicates
- Add typed native SQL parser
- Revert "Merge pull request #234 from Automattic/feat/233-native-mysql-sidecar"
- Prove native MySQL sidecar protocol
- Add exact native partition reads
- Add bounded native provider access
- Refactor native query contracts
- Add native bootstrap shadow verifier
- Preserve baselines on canonical delete failure
- Distinguish canonical deletion outcomes
- Isolate canonical persistence observers
- Preserve failed canonical post writes
- Bound canonical shutdown persistence
- Add native usermeta cache queries
- Prove lazy and recovery byte boundaries
- Cover lazy post content byte boundaries
- Preserve lazy post content bytes
- Preserve exact canonical post body bytes
- Add generic native canonical query engine
- Reconcile canonical post receipt line endings
- Use adapter-owned post transactions
- Recognize quoted post identities
- Harden query corpus quality gates
- Add wpdb compatibility corpus

## [0.10.2] - 2026-08-23

### Changed
- Preserve exact option deletions in full flushes

## [0.10.1] - 2026-08-23

### Changed
- Refresh outdated MDI drop-ins

## [0.10.0] - 2026-08-23

### Changed
- Publish mysql-full mutations canonically

- Add backend-neutral three-way content reconciliation with deterministic
- Add MySQL outbox impact planning
- Add durable MySQL mutation outbox
- Require native multisite prefix proof
- Verify native multisite prefix behavior
- Add MySQL wpdb mutation boundary
- Match lifecycle move receipt semantics
- Keep creation durability content-only
- Preserve path proof for canonical rewrites
- Add MySQL content-primary runtime
- Verify native MariaDB probe cleanup
- Correct MariaDB probe recovery fence proof
- Harden native MariaDB reconciliation probe
- Add durable reconciliation operation store
  plan categories, stale-plan protection, bounded continuations, root-scoped
  opt-in deletion, durable operation recovery, WP-CLI, and Abilities API
  surfaces.

All notable changes to this project will be documented in this file. Entries are generated by homeboy from git commits.

### Fixed
- Fix import source path fallback
- Fix WordPress zero-date inserts on SQLite
- Fix descendant moves after parent deletion
- Fix reconciliation review findings
- Fix canonical transaction capability detection

## [0.9.2] - 2026-08-12

### Changed
- Compose partition and query persistence policies

## [0.9.1] - 2026-08-12

### Fixed
- Fix canonical hydration transaction ownership

## [0.9.0] - 2026-08-12

### Changed
- Add row-partitioned table persistence
- Move SQLite runtime behind adapter
- Extract backend-neutral canonical persistence
- Add pluggable content layout profiles
- Add backend capability contract
- Stream large JSON table snapshots

### Fixed
- avoid restricted Playground path probes
- detect legacy SQLite result API by class

## [0.8.9] - 2026-07-28

### Fixed
- adapt released SQLite wpdb results

## [0.8.8] - 2026-07-28

### Fixed
- support stale drop-in upgrades

## [0.8.7] - 2026-07-28

### Changed
- keep driver alias at bootstrap boundary
- consolidate driver bootstrap coverage

### Fixed
- boot with Studio PDO driver name
- support released SQLite PDO driver
- Fix released SQLite driver compatibility

## [0.8.6] - 2026-07-28

### Fixed
- avoid SQLite SQL mode bootstrap fatal

## [0.8.5] - 2026-07-28

### Changed
- Refactor MDI onto the canonical SQLite PDO API

### Fixed
- Fix persistence amplification boundaries

## [0.8.4] - 2026-07-28

### Changed
- Make ephemeral option names filterable
- Reuse bounded temp paths for option persistence
- Skip auto-drafts before canonical persistence
- Bound canonical flush hashing to mutations
- Keep JSON manifest coherent after writes
- Preserve large JSON table rows
- Bound primary JSON table hydration memory
- Expose canonical flush change actions
- Return canonical changes from explicit flushes
- Support exporting an existing SQLite cache
- Prove constrained runtime cache reconstruction
- Complete constrained primary runtime
- Add storage-only primary runtime contract
- Clarify full database reconstruction
- Detect inactive Markdown database runtime
- Reset cached post content during warm sync
- Split primary content and state roots

### Fixed
- persist standalone index drops
- Fix concurrent JSON warm hydration

## [0.8.3] - 2026-06-25

### Changed
- Migrate import export conversion to Blocks Engine

## [0.8.2] - 2026-06-17

### Changed
- add MDI release gate scripts
- Make portable frontmatter canonical
- Add OKF frontmatter profile
- Add pluggable frontmatter profiles

## [0.8.1] - 2026-06-16

### Changed
- Make markdown import export conversion self-contained

### Fixed
- Fix markdown CLI lint release gate

## [0.8.0] - 2026-05-27

### Added
- add optional BFB import export conversion

## [0.7.0] - 2026-05-27

### Added
- add import export transform filters
- add markdown import export abilities
- add table persistence policy hooks

### Fixed
- register markdown abilities only during hooks
- mark drop-in for Studio preservation
- keep zero-ID posts out of $posts_by_id to avoid auto-increment key collisions

## [0.6.1] - 2026-05-09

### Fixed
- register recovery ability category early
- recover stranded sqlite posts

## [0.6.0] - 2026-05-09

### Added
- add MDI boot timing benchmark

### Changed
- emit boot timing metrics through results

### Fixed
- stream large corpus markdown sync
- stream warm sync file manifest
- avoid hydrating unchanged posts during warm sync
- preserve existing DB for partial primary stores
- remove plugin header from drop-in
- import primary seed posts after fallback install
- depend on upstream bench filtering

## [0.5.3] - 2026-04-29

### Changed
- make MDI storage-only

## [0.5.2] - 2026-04-28

### Fixed
- store editor block writes as markdown

## [0.5.1] - 2026-04-28

### Fixed
- pin BFB release

## [0.5.0] - 2026-04-28

### Added
- adopt Block Format Bridge as the conversion substrate (closes #82)

### Fixed
- refresh BFB substrate bundle
- use unique temp files for table JSON writes

## [0.4.0] - 2026-04-25

### Added
- stress harness comparing SDI / MDI mirror / MDI primary (closes #75)

### Fixed
- primary install table prefix and index path
- wire BENCH_CORPUS_SIZE through --setting-json + harden empty-corpus path

## [0.3.1] - 2026-04-22

### Fixed
- prevent rebuild_index from unlinking just-written file (#70)
- parent promotion updates _markdown_file_index (closes #68)
- wp_posts partitioned sync preserves markdown-type rows (closes #66)
- surgical delete for partitioned tables in sync_json_tables (closes #64)

## [0.3.0] - 2026-04-21

### Added
- multi-value meta + debounced post rewrites (#20 + #21)
- internal meta allowlist for frontmatter (#22)
- auto-assign post IDs and slugs for dropped-on-disk files (#42)
- PHP grep backend for post_content LIKE queries (#43)
- add markdown_db_frontmatter filter for extension fields
- per-file options storage — surgical sync, concurrency-safe (#55)
- Index/Map Architecture — SQLite as index, .md files as content store

### Changed
- remove dead code, consolidate duplicates
- store raw markdown in post_content, convert at render time
- defer non-post table writes to shutdown
- Embed postmeta and terms in frontmatter — self-contained .md files
- Persist ALL table DML — fix plugin table data loss on reboot
- remove dead code, fix naming, simplify dedup, gate writes
- Store hierarchical posts in matching directory structure
- Update README with conversion pipeline architecture
- Add markdown conversion pipeline — store clean markdown, not block markup
- Store all post types as markdown by default
- Phase 2: In-memory SQLite with markdown files as sole database
- Add README with architecture, installation, and test results
- Initial scaffold: WordPress database integration that stores posts as markdown files

### Fixed
- concurrent boot safety — isolated cold boot with atomic rename (#50)
- persist schema as SHOW CREATE TABLE snapshot instead of append log
- skip ALTER TABLE during boot, add self-healing for orphaned posts (#47)
- write parent posts as index.md inside their directory, not as siblings
- enable table-to-markdown conversion and ATX headings
- delete stale flat files when posts are reparented
- markdown conversion roundtrip — prevent corruption of .md files
- add missing property declarations for $dirty and $shutdown_registered
- use HTML intermediary instead of direct markdown-to-blocks at boot
- fall back to frontmatter parent for flat file layouts
- populate information schema for plugin tables created via raw PDO
- Fix loader rolling back all posts on duplicate ID collision

## [0.2.0] - 2026-04-21

Baseline version predating homeboy-managed releases. See git history for details.
