<?php
/** Atomic INSERT mutations for persisted generic table snapshots. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-native-table-statements.php';
require_once __DIR__ . '/class-wp-markdown-native-table-insert-parser.php';

final class WP_Markdown_Native_Table_Mutation_Runtime {
	private string $state_root;
	private WP_Markdown_Native_Table_Index $index;
	/** @var array<string,WP_Markdown_Native_Table_Index> */
	private array $temporary_indexes = array();
	/** @var array<string,WP_Markdown_File_Witness> */
	private array $unique_sets_verified = array();

	public function __construct(
		string $state_root,
		private WP_Markdown_Native_Table_Registry $registry,
		private WP_Markdown_Native_Table_Insert_Parser $parser = new WP_Markdown_Native_Table_Insert_Parser(),
		private ?WP_Markdown_Native_Transaction_Journal $transactions = null,
		private ?WP_Markdown_Native_Temporary_Tables $temporary_tables = null,
		private WP_Markdown_Native_SQL_Session $session = new WP_Markdown_Native_SQL_Session()
	) {
		$root = realpath( $state_root );
		if ( false === $root || ! is_dir( $root ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		$this->state_root = rtrim( $root, DIRECTORY_SEPARATOR );
		$this->index = new WP_Markdown_Native_Table_Index( $this->state_root . DIRECTORY_SEPARATOR . '_tables' );
	}

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		if ( 1 === preg_match( '/^\s*(?:UPDATE|DELETE)\b/i', $request->sql() ) ) {
			return $this->execute_write( $request );
		}
		$inserts = $this->parser->parse_rows( $request );
		if ( $inserts instanceof WP_Markdown_Query_Result ) {
			return $inserts;
		}
		if ( 1 !== count( $inserts ) ) {
			return $this->execute_rows( $request, $inserts );
		}
		return $this->execute_insert( $request, $inserts[0] );
	}

	/**
	 * Apply every row of a multi-row INSERT as one statement.
	 *
	 * MySQL reports the rows it affected and the identifier of the first row
	 * it inserted, and a statement that fails part way through leaves nothing
	 * behind, so the rows are applied inside a transaction.
	 *
	 * @param array<int,WP_Markdown_Native_Table_Insert> $inserts
	 */
	private function execute_rows( WP_Markdown_Query_Request $request, array $inserts ): WP_Markdown_Query_Result {
		$owns_transaction = null !== $this->transactions && $this->transactions->is_autocommit() && ! $this->transactions->is_active();
		if ( $owns_transaction && true !== $this->transactions->begin() ) {
			return $this->failure( 'mutation_transaction_failed', 'The canonical multi-row INSERT could not be isolated.' );
		}
		$affected = 0;
		$insert_id = 0;
		foreach ( $inserts as $insert ) {
			$result = $this->execute_insert( $request, $insert );
			if ( false === $result->return_value() ) {
				if ( $owns_transaction ) {
					$this->transactions->rollback();
					$this->registry->forget_snapshots();
				}
				return $result;
			}
			$affected += (int) $result->return_value();
			$row_id = (int) ( $result->wpdb_state()['insert_id'] ?? 0 );
			if ( 0 === $insert_id && 0 !== $row_id ) {
				$insert_id = $row_id;
			}
		}
		if ( $owns_transaction && true !== $this->transactions->commit() ) {
			return $this->failure( 'mutation_transaction_failed', 'The canonical multi-row INSERT could not be committed.' );
		}
		return WP_Markdown_Query_Result::mutated( $affected, $insert_id );
	}

	private function execute_insert( WP_Markdown_Query_Request $request, WP_Markdown_Native_Table_Insert $insert ): WP_Markdown_Query_Result {
		$prefix = $request->table_prefix();
		if ( ! str_starts_with( $insert->table(), $prefix ) ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native requires a table in the active prefix.' );
		}
		$suffix = substr( $insert->table(), strlen( $prefix ) );
		$table = $this->registry->table( $insert->table() );
		$definition = $this->registry->definition( $insert->table() );
		if ( 1 !== preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/D', $suffix )
			|| null === $table
			|| ! $table['provider'] instanceof WP_Markdown_Native_JSON_Snapshot_Provider
			|| ! is_array( $definition )
			|| ! $this->is_authoritative_definition( $suffix, $definition, $prefix, $insert->table() )
		) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can insert only into a persisted generic snapshot table.' );
		}

		$root = $this->root_for( $insert->table() );
		$directory = $this->tables_directory( $root );
		if ( $directory instanceof WP_Markdown_Query_Result ) {
			return $directory;
		}
		$lock = $this->table_lock( $directory, $suffix );
		if ( $lock instanceof WP_Markdown_Query_Result ) {
			return $lock;
		}

		try {
			$schema = $table['schema'];
			$provider = $table['provider'];
			$floors = $this->auto_increment_floors( $directory, $suffix );
			foreach ( $insert->upsert_assignments() ?? array() as $assignment ) {
				if ( ! $schema->has_column( $assignment['target'] ) || ( null !== $assignment['source'] && ! $schema->has_column( $assignment['source'] ) ) ) {
					return $this->failure( 'unsupported_column', 'The duplicate-key assignment references an undeclared column.' );
				}
				if ( $assignment['value'] instanceof WP_Markdown_Native_Query_Scalar_Expression ) {
					if ( ! WP_Markdown_Native_Scalar_Evaluator::supports( $assignment['value'] ) ) {
						return $this->failure( 'unsupported_mutation_expression', 'The duplicate-key assignment uses an unsupported expression.' );
					}
					foreach ( $assignment['value']->columns() as $column ) {
						if ( ! $schema->has_column( $column ) ) {
							return $this->failure( 'unsupported_column', 'The duplicate-key assignment references an undeclared column.' );
						}
					}
				}
			}
			if ( ! $this->supports_unique_indexes( $definition ) ) {
				return $this->failure( 'unsupported_unique_collation', 'mdi-native cannot enforce a persisted string or prefix unique key without its exact collation.' );
			}
			if ( null !== $insert->unless_exists() ) {
				$existing = $table['provider']->read( new WP_Markdown_Native_Table_Access( $schema->column_names(), null, $schema->natural_order(), PHP_INT_MAX ) );
				if ( $existing instanceof WP_Markdown_Query_Result ) {
					return $existing;
				}
				$existing = is_array( $existing ) ? $existing : iterator_to_array( $existing, false );
				foreach ( $existing as $row ) {
					if ( is_array( $row ) && $this->restricts( $row, $insert->unless_exists(), $schema ) ) {
						return WP_Markdown_Query_Result::mutated( 0 );
					}
				}
			}
			$path = $directory . '/' . $suffix . '.json';
			$table_index = $this->index_for( $root );
			$index = $insert->is_replace() || null !== $insert->upsert_assignments() || WP_Markdown_Native_Table_Index::supplies_identity( $insert->values(), $definition )
				? null
				: $table_index->load( $suffix, $path );
			if ( null !== $index ) {
				// The index enforces this candidate's keys, while this witnessed
				// snapshot proves the pre-existing keys were already unique.
				$unique_set_verified = $this->unique_set_is_verified( $suffix, $path );
				// The index answers identity and uniqueness, so the snapshot is
				// appended to rather than read, decoded, and republished.
				$row = $this->complete_row( $insert->values(), $definition, array(), $index['max'], $floors );
				if ( $row instanceof WP_Markdown_Query_Result ) {
					return $row;
				}
				if ( true !== $schema->validate_row( $row ) ) {
					return $this->failure( 'invalid_insert_row', 'The INSERT row is outside the persisted table schema.' );
				}
				if ( ! $this->unique_values_enforceable( $row, $definition ) ) {
					return $this->failure( 'unsupported_unique_collation', 'mdi-native cannot enforce a unique key that is not exact ASCII or integer identity.' );
				}
				if ( WP_Markdown_Native_Table_Index::duplicates( $index, $row, $definition, $schema ) ) {
					return $insert->ignores_duplicate()
						? WP_Markdown_Query_Result::mutated( 0 )
						: $this->failure( 'duplicate_key', 'The INSERT row duplicates a persisted unique key.' );
				}
				$appended = $this->append_row( $path, $row, 0 === $index['row_count'] );
				if ( $appended instanceof WP_Markdown_Query_Result ) {
					return $appended;
				}
				$table_index->remember( $suffix, $path, WP_Markdown_Native_Table_Index::with_row( $index, $row, $definition, $schema ) );
				if ( $unique_set_verified ) {
					$this->remember_verified_unique_set( $suffix, $path );
				}
				$provider->append_row( $row );
				$this->record_auto_increment( $directory, $suffix, $row, $definition, $floors );
				return $this->insert_result( $row, $definition );
			}

			$rows = $provider->rows();
			if ( $rows instanceof WP_Markdown_Query_Result ) {
				return $rows;
			}
			$rows = is_array( $rows ) ? $rows : iterator_to_array( $rows, false );
			$row = $this->complete_row( $insert->values(), $definition, $rows, null, $floors );
			if ( $row instanceof WP_Markdown_Query_Result ) {
				return $row;
			}
			if ( true !== $schema->validate_row( $row ) ) {
				return $this->failure( 'invalid_insert_row', 'The INSERT row is outside the persisted table schema.' );
			}
			if ( ! $this->unique_values_enforceable( $row, $definition ) ) {
				return $this->failure( 'unsupported_unique_collation', 'mdi-native cannot enforce a unique key that is not exact ASCII or integer identity.' );
			}
			$duplicates = $this->duplicate_row_offsets( $row, $rows, $definition, $schema );
			if ( array() !== $duplicates ) {
				if ( $insert->is_replace() ) {
					foreach ( $duplicates as $duplicate ) {
						unset( $rows[ $duplicate ] );
					}
					$rows[] = $row;
					$rows = array_values( $rows );
					$written = $this->write( $path, $rows );
					if ( $written instanceof WP_Markdown_Query_Result ) {
						return $written;
					}
					// REPLACE already scans and republishes the snapshot. Leave the
					// derived insert index for the next operation that needs it.
					$table_index->forget( $suffix, $this->transactions );
					$provider->replace_rows( $rows );
					$this->record_auto_increment( $directory, $suffix, $row, $definition, $floors );
					return WP_Markdown_Query_Result::mutated( count( $duplicates ) + 1, $this->auto_increment_value( $row, $definition ) );
				}
				if ( $insert->ignores_duplicate() ) {
					return WP_Markdown_Query_Result::mutated( 0 );
				}
				$upsert_assignments = $insert->upsert_assignments();
				if ( null === $upsert_assignments ) {
					return $this->failure( 'duplicate_key', 'The INSERT row duplicates a persisted unique key.' );
				}
				$duplicate = $duplicates[0];
				$updated = $rows[ $duplicate ];
				$scalar_runtime = new WP_Markdown_Native_Query_Runtime( $this->registry, new WP_Markdown_Native_Query_Parser() );
				foreach ( $upsert_assignments as $assignment ) {
					// Existing-column references see earlier assignments; VALUES sees the proposed insert.
					$value = match ( $assignment['kind'] ) {
						'inserted' => $row[ $assignment['source'] ],
						'expression' => $scalar_runtime->evaluate_scalar( $assignment['value'], $updated, $schema ),
						default => $assignment['value'],
					};
					$updated[ $assignment['target'] ] = null === $value ? null : (string) $value;
				}
				if ( true !== $schema->validate_row( $updated ) ) {
					return $this->failure( 'invalid_insert_row', 'The INSERT row is outside the persisted table schema.' );
				}
				if ( ! $this->unique_values_enforceable( $updated, $definition ) ) {
					return $this->failure( 'unsupported_unique_collation', 'The duplicate-key assignment requires an unsupported unique-key collation.' );
				}
				$others = $rows;
				unset( $others[ $duplicate ] );
				if ( $this->duplicate_row_offset( $updated, array_values( $others ), $definition, $schema ) !== null ) {
					return $this->failure( 'duplicate_key', 'The INSERT row duplicates a persisted unique key.' );
				}
				if ( $updated === $rows[ $duplicate ] ) {
					return WP_Markdown_Query_Result::mutated( 0 );
				}
				$rows[ $duplicate ] = $updated;
				$written = $this->write( $path, array_values( $rows ) );
				if ( $written instanceof WP_Markdown_Query_Result ) {
					return $written;
				}
				$table_index->save( $suffix, $path, WP_Markdown_Native_Table_Index::build( array_values( $rows ), $definition, $schema ), $this->transactions );
				$provider->replace_rows( array_values( $rows ) );
				return WP_Markdown_Query_Result::mutated( 2, $this->auto_increment_value( $updated, $definition ) );
			}
			$rows[] = $row;
			$written = $this->write( $path, $rows );
			if ( $written instanceof WP_Markdown_Query_Result ) {
				return $written;
			}
			$table_index->save( $suffix, $path, WP_Markdown_Native_Table_Index::build( $rows, $definition, $schema ), $this->transactions );
			$provider->replace_rows( $rows );
			$this->record_auto_increment( $directory, $suffix, $row, $definition, $floors );
			return WP_Markdown_Query_Result::mutated( 1, $this->auto_increment_value( $row, $definition ) );
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}

	/**
	 * Resolve the auto-increment identifier assigned to a completed row.
	 *
	 * @param array<string,mixed> $row        Completed row.
	 * @param array<string,mixed> $definition Compiled definition.
	 */
	private function insert_result( array $row, array $definition ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::mutated( 1, $this->auto_increment_value( $row, $definition ) );
	}

	/** @param array<string,mixed> $row @param array<string,mixed> $definition */
	private function auto_increment_value( array $row, array $definition ): int {
		foreach ( $definition['columns'] as $name => $column ) {
			if ( true === ( $column['auto_increment'] ?? false ) ) {
				return (int) $row[ $name ];
			}
		}
		return 0;
	}

	/**
	 * Append one encoded row inside the snapshot's JSON array.
	 *
	 * The existing rows are never decoded or re-encoded, so the cost of an
	 * insert does not grow with the size of the snapshot.
	 *
	 * @param array<string,mixed> $row Row to append.
	 */
	private function append_row( string $path, array $row, bool $empty ): true|WP_Markdown_Query_Result {
		if ( is_link( $path ) || ! is_file( $path ) ) {
			return $this->failure( 'unsafe_table_file', 'The canonical table file is unavailable or unsafe.' );
		}
		if ( null !== $this->transactions ) {
			$recorded = $this->is_temporary_path( $path ) ? $this->transactions->record_ephemeral( $path ) : $this->transactions->record( $path );
			if ( true !== $recorded ) {
				return $this->failure( 'transaction_journal_failed', $recorded );
			}
		}
		try {
			$encoded = json_encode( $row, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR );
		} catch ( Throwable ) {
			return $this->failure( 'table_encoding_failed', 'The canonical table row could not be encoded.' );
		}

		$handle = @fopen( $path, 'c+b' );
		if ( false === $handle ) {
			return $this->failure( 'table_append_failed', 'The canonical table file could not be opened for append.' );
		}
		try {
			$size = fstat( $handle )['size'] ?? 0;
			$window = (int) min( $size, 4096 );
			if ( 0 === $window || -1 === fseek( $handle, $size - $window ) ) {
				return $this->failure( 'table_append_failed', 'The canonical table file could not be positioned.' );
			}
			$tail = (string) fread( $handle, $window );
			$close = strrpos( $tail, ']' );
			if ( false === $close ) {
				return $this->failure( 'table_append_failed', 'The canonical table file has no array terminator.' );
			}
			$offset = $size - $window + $close;
			if ( -1 === fseek( $handle, $offset ) ) {
				return $this->failure( 'table_append_failed', 'The canonical table file could not be positioned.' );
			}
			$payload = ( $empty ? '' : ',' ) . $encoded . ']';
			if ( strlen( $payload ) !== fwrite( $handle, $payload ) ) {
				return $this->failure( 'table_append_failed', 'The canonical table row could not be appended.' );
			}
			if ( ! ftruncate( $handle, $offset + strlen( $payload ) ) ) {
				return $this->failure( 'table_append_failed', 'The canonical table file could not be truncated.' );
			}
			if ( ! fflush( $handle ) || ( function_exists( 'fsync' ) && ! fsync( $handle ) ) ) {
				return $this->failure( 'table_append_failed', 'The canonical table row could not be flushed.' );
			}
		} finally {
			fclose( $handle );
		}
		return true;
	}

	/**
	 * @param array<string,int|string|null>   $provided   Supplied columns.
	 * @param array<string,mixed>             $definition Compiled definition.
	 * @param array<int,array<string,mixed>>  $rows       Snapshot rows, empty when maxima are supplied.
	 * @param array<string,int>|null          $maxima     Known auto-increment maxima.
	 * @param array<string,int>               $floors     Durable high-water values that generated identifiers must exceed.
	 */
	private function complete_row( array $provided, array $definition, array $rows, ?array $maxima = null, array $floors = array() ): array|WP_Markdown_Query_Result {
		if ( array_diff_key( $provided, $definition['columns'] ) ) {
			return $this->failure( 'unsupported_column', 'The INSERT references an undeclared column.' );
		}
		if ( $this->session->strict() ) {
			$missing = array();
			foreach ( $definition['columns'] as $name => $column ) {
				if ( ! array_key_exists( $name, $provided ) && empty( $column['auto_increment'] ) && empty( $column['nullable'] ) && null === ( $column['default'] ?? null ) ) {
					$missing[] = $name;
					$this->session->warn_missing_default( $name, true );
				}
			}
			if ( array() !== $missing ) {
				return WP_Markdown_Query_Result::failure( array( 'code' => 1364, 'reason' => 'missing_required_column', 'message' => "Field '{$missing[0]}' doesn't have a default value" ) );
			}
		}
		$row = array();
		foreach ( $definition['columns'] as $name => $column ) {
			$generate_identity = true === ( $column['auto_increment'] ?? false )
				&& ( ! array_key_exists( $name, $provided ) || null === $provided[ $name ] || '0' === (string) $provided[ $name ] );
			if ( array_key_exists( $name, $provided ) && ! $generate_identity ) {
				$row[ $name ] = $provided[ $name ];
				continue;
			}
			if ( $generate_identity ) {
				$maximum = $maxima[ $name ] ?? null;
				if ( null === $maximum ) {
					$maximum = 0;
					foreach ( $rows as $existing ) {
						$maximum = max( $maximum, (int) $existing[ $name ] );
					}
				}
				// Like MySQL AUTO_INCREMENT, never reissue a value once used, even after
				// the row holding the current maximum is deleted.
				$maximum = max( $maximum, $floors[ $name ] ?? 0 );
				if ( PHP_INT_MAX === $maximum ) {
					return $this->failure( 'auto_increment_exhausted', 'The persisted auto-increment range is exhausted.' );
				}
				$row[ $name ] = (string) ( $maximum + 1 );
				continue;
			}
			$default = $column['default'] ?? null;
			if ( null !== $default ) {
				// MySQL evaluates dynamic defaults at write time. The canonical
				// store has no session time zone, so UTC is the honest clock.
				$dynamic = strtoupper( (string) $default );
				if ( 1 === preg_match( '/^CURRENT_TIMESTAMP(?:\(\))?$/i', (string) $default ) ) {
					$row[ $name ] = gmdate( 'Y-m-d H:i:s' );
					continue;
				}
				if ( 1 === preg_match( '/^CURRENT_DATE(?:\(\))?$/i', (string) $default ) ) {
					$row[ $name ] = gmdate( 'Y-m-d' );
					continue;
				}
				if ( 1 === preg_match( '/^CURRENT_TIME(?:\(\))?$/i', (string) $default ) ) {
					$row[ $name ] = gmdate( 'H:i:s' );
					continue;
				}
				$row[ $name ] = (string) $default;
				continue;
			}
			if ( true === ( $column['nullable'] ?? false ) ) {
				$row[ $name ] = null;
				continue;
			}
			if ( ! $this->session->strict() ) {
				$type = strtolower( $column['type'] ?? '' );
				$implicit = match ( $type ) {
					'tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint', 'decimal', 'numeric', 'float', 'double', 'real', 'year' => '0',
					'char', 'varchar', 'tinytext', 'text', 'mediumtext', 'longtext', 'tinyblob', 'blob', 'mediumblob', 'longblob', 'varbinary' => '',
					'date' => '0000-00-00',
					'datetime', 'timestamp' => '0000-00-00 00:00:00',
					'time' => '00:00:00',
					default => null,
				};
				if ( null !== $implicit ) {
					$row[ $name ] = $implicit;
					$this->session->warn_missing_default( $name );
					continue;
				}
			}
			return $this->failure( 'missing_required_column', 'The INSERT omits a required column without a deterministic default.' );
		}
		return $row;
	}

	/** @param array<string,mixed> $row @param array<int,array<string,mixed>> $rows @param array<string,mixed> $definition */
	private function duplicates_unique_index( array $row, array $rows, array $definition, WP_Markdown_Native_Table_Schema $schema ): bool {
		return null !== $this->duplicate_row_offset( $row, $rows, $definition, $schema );
	}

	/** @param array<string,mixed> $row @param array<int,array<string,mixed>> $rows @param array<string,mixed> $definition */
	private function duplicate_row_offset( array $row, array $rows, array $definition, WP_Markdown_Native_Table_Schema $schema ): ?int {
		$duplicates = $this->duplicate_row_offsets( $row, $rows, $definition, $schema );
		return $duplicates[0] ?? null;
	}

	/**
	 * Offsets of the persisted rows a candidate row would duplicate.
	 *
	 * The candidate's own comparison value cannot change while the persisted
	 * rows are examined, so each unique index normalizes it once and then
	 * compares that against every row rather than renormalizing both sides for
	 * every row it looks at.
	 *
	 * @return array<int,int>
	 */
	private function duplicate_row_offsets( array $row, array $rows, array $definition, WP_Markdown_Native_Table_Schema $schema ): array {
		$duplicates = array();
		foreach ( $definition['indexes'] as $index ) {
			if ( true !== ( $index['unique'] ?? false ) ) {
				continue;
			}
			$columns = $index['columns'];
			$names   = array_column( $columns, 'name' );
			if ( array() === $names || array_filter( $names, static fn( string $column ): bool => null === $row[ $column ] ) ) {
				continue;
			}
			$candidates = array();
			foreach ( $columns as $column ) {
				$name   = (string) ( $column['name'] ?? '' );
				$length = $column['length'] ?? null;
				$value  = $schema->column( $name )->normalize( $this->unique_index_value( $row[ $name ] ?? null, $length ) );
				if ( null === $value ) {
					// An uncomparable candidate value cannot duplicate any row.
					continue 2;
				}
				$candidates[] = array(
					'column' => $schema->column( $name ),
					'name'   => $name,
					'length' => $length,
					'value'  => $value,
				);
			}
			foreach ( $rows as $offset => $existing ) {
				$matches = true;
				foreach ( $candidates as $candidate ) {
					$value = $candidate['column']->normalize(
						$this->unique_index_value( $existing[ $candidate['name'] ] ?? null, $candidate['length'] )
					);
					if ( null === $value || $value !== $candidate['value'] ) {
						$matches = false;
						break;
					}
				}
				if ( $matches ) {
					$duplicates[ (int) $offset ] = (int) $offset;
				}
			}
		}
		return array_values( $duplicates );
	}

	/** @param array<string,mixed> $definition */
	/** Apply one generic UPDATE or DELETE to a persisted snapshot table. */
	private function execute_write( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		$write = $this->parser->parse_write( $request );
		if ( $write instanceof WP_Markdown_Query_Result ) {
			return $write;
		}

		$prefix = $request->table_prefix();
		if ( ! str_starts_with( $write->table(), $prefix ) ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native requires a table in the active prefix.' );
		}
		$suffix = substr( $write->table(), strlen( $prefix ) );
		$table = $this->registry->table( $write->table() );
		$definition = $this->registry->definition( $write->table() );
		$provider = is_array( $table ) ? $table['provider'] : null;
		$is_snapshot = $provider instanceof WP_Markdown_Native_JSON_Snapshot_Provider;
		$is_partition = $provider instanceof WP_Markdown_Native_JSON_Partition_Provider;
		if ( 1 !== preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/D', $suffix )
			|| null === $table
			|| ( ! $is_snapshot && ! $is_partition )
			|| ! is_array( $definition )
			|| ! $this->is_authoritative_definition( $suffix, $definition, $prefix, $write->table() )
		) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only a persisted generic snapshot table.' );
		}
		if ( $is_partition && $write->is_update() ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only a persisted generic snapshot table.' );
		}

		$schema = $table['schema'];
		if ( ! $this->supports_unique_indexes( $definition ) ) {
			return $this->failure( 'unsupported_unique_collation', 'mdi-native cannot enforce a persisted string or prefix unique key without its exact collation.' );
		}
		$predicates = $this->resolve_subquery_predicates( $write->predicates(), $schema, $write->table() );
		if ( $predicates instanceof WP_Markdown_Query_Result ) {
			return $predicates;
		}
		foreach ( $predicates as $predicate ) {
			foreach ( $this->predicate_columns( $predicate ) as $column ) {
				if ( ! $schema->has_column( $column ) ) {
					return $this->failure( 'unsupported_mutation_column', 'The WHERE restriction names a column outside the persisted table schema.' );
				}
			}
		}
		foreach ( $write->values() as $column => $value ) {
			if ( ! $schema->has_column( (string) $column ) ) {
				return $this->failure( 'unsupported_mutation_column', 'The assignment names a column outside the persisted table schema.' );
			}
			if ( $value instanceof WP_Markdown_Native_Query_Scalar_Expression ) {
				foreach ( $value->columns() as $source ) {
					if ( ! $schema->has_column( $source ) ) {
						return $this->failure( 'unsupported_mutation_column', 'The expression names a column outside the persisted table schema.' );
					}
				}
				foreach ( $value->predicates() as $predicate ) {
					if ( ! $schema->supports_predicate( $predicate ) ) {
						return $this->failure( 'unsupported_predicate', 'The assignment expression uses an unsupported predicate.' );
					}
				}
			}
		}
		if ( $is_partition ) {
			return $this->execute_partition_delete( $write, $table, $predicates );
		}
		$scalar_runtime = new WP_Markdown_Native_Query_Runtime( $this->registry, new WP_Markdown_Native_Query_Parser() );
		$root = $this->root_for( $write->table() );
		$directory = $this->tables_directory( $root );
		if ( $directory instanceof WP_Markdown_Query_Result ) {
			return $directory;
		}
		$lock = $this->table_lock( $directory, $suffix );
		if ( $lock instanceof WP_Markdown_Query_Result ) {
			return $lock;
		}

		try {
			$path = $directory . '/' . $suffix . '.json';
			$provider = $table['provider'];
			$table_index = $this->index_for( $root );
			$index = $table_index->load( $suffix, $path );
			$rows = $provider->rows();
			if ( $rows instanceof WP_Markdown_Query_Result ) {
				return $rows;
			}
			$rows = is_array( $rows ) ? $rows : iterator_to_array( $rows, false );
			if ( null !== $write->derived_selection() ) {
				$predicates = $this->materialize_derived_selection( $write->derived_selection(), $schema, $write->table(), $rows );
				if ( $predicates instanceof WP_Markdown_Query_Result ) {
					return $predicates;
				}
			}
			if ( null !== $index && $this->index_excludes( $index, $predicates ) ) {
				return WP_Markdown_Query_Result::mutated( 0 );
			}

			$selected = WP_Markdown_Native_Table_Write_Selection::selected_offsets( $rows, $predicates, $write, $schema );
			if ( null === $selected ) {
				return $this->failure( 'unsupported_order', 'The write ORDER BY names a column mdi-native cannot order.' );
			}
			$retained = array();
			$affected = 0;
			$preserves_index_values = $write->is_update() && $this->preserves_index_values( $write->values(), $definition );
			$updated_index = $preserves_index_values ? $index : null;
			foreach ( $rows as $offset => $row ) {
				if ( ! isset( $selected[ $offset ] ) ) {
					$retained[] = $row;
					continue;
				}
				++$affected;
				if ( ! $write->is_update() ) {
					continue;
				}
				$updated = $row;
				foreach ( $write->values() as $column => $value ) {
					$value = $value instanceof WP_Markdown_Native_Query_Scalar_Expression
						? $scalar_runtime->evaluate_scalar( $value, $updated, $schema )
						: $value;
					$updated[ $column ] = null === $value ? null : (string) $value;
				}
				if ( true !== $schema->validate_row( $updated ) ) {
					return $this->failure( 'invalid_update_row', 'The UPDATE row is outside the persisted table schema.' );
				}
				if ( null !== $updated_index ) {
					$updated_index = WP_Markdown_Native_Table_Index::with_non_key_update( $updated_index, $row, $updated );
				}
				$retained[] = $updated;
			}

			if ( 0 === $affected ) {
				$table_index->remember( $suffix, $path, WP_Markdown_Native_Table_Index::build( $rows, $definition, $schema ) );
				return WP_Markdown_Query_Result::mutated( 0 );
			}
			$unique_set_verified = $write->is_update()
				&& $this->preserves_unique_values( $write->values(), $definition )
				&& $this->unique_set_is_verified( $suffix, $path );
			if ( ! $unique_set_verified ) {
				$violation = $this->unique_set_violation( $retained, $definition, $schema );
				if ( $violation instanceof WP_Markdown_Query_Result ) {
					return $violation;
				}
			}
			$written = $this->write( $path, $retained );
			if ( $written instanceof WP_Markdown_Query_Result ) {
				return $written;
			}
			$this->remember_verified_unique_set( $suffix, $path );
			// The sidecar is derived state. Keep this runtime's witnessed index
			// current without republishing it after every canonical table write.
			$table_index->remember( $suffix, $path, $updated_index ?? WP_Markdown_Native_Table_Index::build( $retained, $definition, $schema ) );
			$provider->replace_rows( $retained );
			return WP_Markdown_Query_Result::mutated( $affected );
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}

	/**
	 * @param array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group> $predicates
	 */
	private function execute_partition_delete( WP_Markdown_Native_Table_Write $write, array $table, array $predicates ): WP_Markdown_Query_Result {
		if ( null !== $write->derived_selection() ) {
			return $this->failure( 'unsupported_derived_selection', 'mdi-native requires one bounded ordered same-table primary-key selection.' );
		}
		$provider = $table['provider'];
		if ( ! $provider instanceof WP_Markdown_Native_JSON_Partition_Provider ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only a persisted generic snapshot table.' );
		}
		$schema = $table['schema'];
		$identity_column = $provider->identity_column();
		if ( array( $identity_column ) !== $schema->identity_columns() ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only a persisted generic snapshot table.' );
		}
		$lock = $provider->exclusive_lock();
		if ( $lock instanceof WP_Markdown_Query_Result ) {
			return $lock;
		}
		try {
			$generation = $provider->active_generation_directory();
			if ( $generation instanceof WP_Markdown_Query_Result ) {
				return $generation;
			}
			if ( null === $generation ) {
				return WP_Markdown_Query_Result::mutated( 0 );
			}
			// An ORDER BY must rank every matching row before LIMIT applies, so the
			// identity fast path (which visits candidates in literal order) is skipped.
			$identities = array() === $write->order_by() ? $this->partition_identity_candidates( $predicates, $identity_column ) : null;
			$affected = 0;
			if ( null !== $identities ) {
				foreach ( $identities as $value ) {
					if ( $affected >= $write->limit() ) {
						break;
					}
					$normalized = $schema->column( $identity_column )->normalize( $value );
					if ( ! is_int( $normalized ) && ! is_string( $normalized ) ) {
						return $this->failure( 'invalid_partition_identity', 'The requested partition identity cannot be normalized.' );
					}
					$identity = (string) $normalized;
					$row = $provider->row_for_identity( $generation, $identity );
					if ( $row instanceof WP_Markdown_Query_Result ) {
						return $row;
					}
					if ( null === $row || ! $this->restricts( $row, $predicates, $schema ) ) {
						continue;
					}
					$deleted = $provider->delete_identity( $generation, $identity, $this->transactions );
					if ( $deleted instanceof WP_Markdown_Query_Result ) {
						return $deleted;
					}
					if ( true === $deleted ) {
						++$affected;
					}
				}
				return WP_Markdown_Query_Result::mutated( $affected );
			}
			$rows = $provider->scan_generation( $generation );
			if ( $rows instanceof WP_Markdown_Query_Result ) {
				return $rows;
			}
			if ( array() !== $write->order_by() ) {
				$rows = is_array( $rows ) ? $rows : iterator_to_array( $rows, false );
				$selected = WP_Markdown_Native_Table_Write_Selection::selected_offsets( $rows, $predicates, $write, $schema );
				if ( null === $selected ) {
					return $this->failure( 'unsupported_order', 'The write ORDER BY names a column mdi-native cannot order.' );
				}
				// The selection is already bounded by ORDER BY … LIMIT; delete exactly it.
				$rows = array_values( array_intersect_key( $rows, $selected ) );
			}
			foreach ( $rows as $row ) {
				if ( $affected >= $write->limit() ) {
					break;
				}
				if ( ! $this->restricts( $row, $predicates, $schema ) ) {
					continue;
				}
				$normalized = $schema->column( $identity_column )->normalize( $row[ $identity_column ] ?? null );
				if ( ! is_int( $normalized ) && ! is_string( $normalized ) ) {
					return $this->failure( 'invalid_partition_identity', 'The requested partition identity cannot be normalized.' );
				}
				$deleted = $provider->delete_identity( $generation, (string) $normalized, $this->transactions );
				if ( $deleted instanceof WP_Markdown_Query_Result ) {
					return $deleted;
				}
				if ( true === $deleted ) {
					++$affected;
				}
			}
			return WP_Markdown_Query_Result::mutated( $affected );
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}

	/**
	 * @param array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group> $predicates
	 * @return array<int,int|string>|null
	 */
	private function partition_identity_candidates( array $predicates, string $identity_column ): ?array {
		foreach ( $predicates as $predicate ) {
			if ( ! $predicate instanceof WP_Markdown_Native_Table_Predicate
				|| $identity_column !== $predicate->column()
				|| ! in_array( $predicate->operator(), array( '=', 'IN' ), true )
				|| $predicate->matches_null()
				|| array() === $predicate->values()
			) {
				continue;
			}
			return $predicate->values();
		}
		return null;
	}

	/**
	 * Materialize the bounded derived side only after the target lock is held.
	 * This is the generic lock-select-update primitive used by claim queues.
	 *
	 * @return array<int,WP_Markdown_Native_Table_Predicate>|WP_Markdown_Query_Result
	 */
	private function materialize_derived_selection( WP_Markdown_Native_Table_Derived_Selection $selection, WP_Markdown_Native_Table_Schema $schema, string $target_table, array $rows ): array|WP_Markdown_Query_Result {
		$primary_key = $selection->primary_key();
		if ( array( $primary_key ) !== $schema->identity_columns() ) {
			return $this->failure( 'unsupported_derived_selection', 'mdi-native requires a single-column primary-key join.' );
		}
		$plan = ( new WP_Markdown_Native_Query_Parser() )->lower( $selection->query() );
		if ( ! $plan instanceof WP_Markdown_Native_Query_Plan ) {
			return $plan;
		}
		if ( 0 !== strcasecmp( $target_table, $plan->table() )
			|| array( $primary_key ) !== $plan->projection()
			|| array() === $plan->order_by()
			|| PHP_INT_MAX === $plan->limit()
			|| 0 !== $plan->limit_offset()
			|| $plan->counts_all()
			|| $plan->calculates_found_rows()
			|| $plan->is_distinct()
			|| null !== $plan->group_by()
			|| array() !== $plan->aggregates()
			|| array() !== $plan->scalar_projection()
			|| array() !== $plan->having()
			|| array() !== $plan->scalar_predicates()
			|| array() !== $plan->scalar_having()
			|| array() !== $plan->subqueries()
			|| null !== $plan->union()
			|| $plan->union_all()
			|| array() !== $plan->union_order_by()
			|| null !== $plan->union_limit()
			|| 0 !== $plan->union_limit_offset()
			|| array() !== $plan->joins()
			|| null !== $plan->boolean_predicate()
			|| null !== $plan->derived()
			|| array() !== $plan->index_hints()
		) {
			return $this->failure( 'unsupported_derived_selection', 'mdi-native requires one bounded ordered same-table primary-key selection.' );
		}
		foreach ( $plan->projection_sources() as $source ) {
			if ( ! in_array( $source, array( null, $target_table, $plan->table_alias() ), true ) ) {
				return $this->failure( 'unsupported_derived_selection', 'mdi-native requires a same-table primary-key projection.' );
			}
		}
		$predicates = array();
		foreach ( $plan->predicates() as $predicate ) {
			$predicate = $this->derived_selection_predicate( $predicate, $schema, $target_table );
			if ( $predicate instanceof WP_Markdown_Query_Result ) {
				return $predicate;
			}
			$predicates[] = $predicate;
		}
		foreach ( $plan->order_by() as $order ) {
			if ( ! in_array( $order['source'], array( null, $target_table, $plan->table_alias() ), true )
				|| ! $schema->has_column( $order['column'] )
				|| ! $schema->allows_order( $order['column'] )
				|| null !== ( $order['expression'] ?? null )
				|| null !== ( $order['field'] ?? null )
				|| null !== ( $order['case'] ?? null )
				|| true === ( $order['numeric'] ?? false )
			) {
				return $this->failure( 'unsupported_derived_selection', 'mdi-native requires simple same-table ordering for a derived selection.' );
			}
		}
		if ( $plan->is_unsatisfiable() ) {
			return array( new WP_Markdown_Native_Table_Predicate( $primary_key, array(), false ) );
		}
		$selected = array_values( array_filter( $rows, fn( array $row ): bool => $this->restricts( $row, $predicates, $schema ) ) );
		$selected = $schema->ordered_rows( $selected, $plan->order_by() );
		if ( null === $selected ) {
			return $this->failure( 'unsupported_derived_selection', 'mdi-native cannot apply the requested derived selection ordering.' );
		}
		$values = array();
		foreach ( array_slice( $selected, 0, $plan->limit() ) as $row ) {
			$value = $row[ $primary_key ] ?? null;
			if ( null === $value ) {
				return $this->failure( 'unsupported_derived_selection', 'mdi-native requires a non-null selected primary key.' );
			}
			$values[] = (string) $value;
		}
		return array( new WP_Markdown_Native_Table_Predicate( $primary_key, $values, false ) );
	}

	private function derived_selection_predicate( WP_Markdown_Native_Query_Predicate $predicate, WP_Markdown_Native_Table_Schema $schema, string $target_table ): WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Query_Result {
		if ( ! in_array( $predicate->operator(), array( '=', 'IN', '<>', '<', '<=', '>', '>=' ), true )
			|| ! in_array( $predicate->source(), array( null, $target_table ), true )
			|| null !== $predicate->comparison_column()
			|| null !== $predicate->cast()
			|| ! $schema->supports_predicate( $predicate )
		) {
			return $this->failure( 'unsupported_derived_selection', 'mdi-native requires simple same-table derived selection predicates.' );
		}
		$alternatives = array();
		foreach ( $predicate->any() as $alternative ) {
			$alternative = $this->derived_selection_predicate( $alternative, $schema, $target_table );
			if ( $alternative instanceof WP_Markdown_Query_Result || $alternative instanceof WP_Markdown_Native_Table_Predicate_Group ) {
				return $alternative instanceof WP_Markdown_Query_Result ? $alternative : $this->failure( 'unsupported_derived_selection', 'mdi-native requires flat derived selection alternatives.' );
			}
			$alternatives[] = $alternative;
		}
		$restriction = new WP_Markdown_Native_Table_Predicate( $predicate->column(), $predicate->values(), false, '=' === $predicate->operator() || 'IN' === $predicate->operator() ? '=' : $predicate->operator() );
		return array() === $alternatives ? $restriction : new WP_Markdown_Native_Table_Predicate_Group( array_merge( array( $restriction ), $alternatives ) );
	}

	/**
	 * Materialize typed IN subqueries before any target-table mutation begins.
	 *
	 * The SELECT executor owns query validation and provider error propagation;
	 * this write path only turns its one projected column into its established
	 * membership predicate.
	 *
	 * @param array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Native_Table_Subquery_Predicate> $predicates
	 * @return array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group>|WP_Markdown_Query_Result
	 */
	private function resolve_subquery_predicates( array $predicates, WP_Markdown_Native_Table_Schema $schema, string $target_table ): array|WP_Markdown_Query_Result {
		$resolved = array();
		$query_parser = new WP_Markdown_Native_Query_Parser();
		$query_runtime = new WP_Markdown_Native_Query_Runtime( $this->registry, $query_parser );
		foreach ( $predicates as $predicate ) {
			if ( $predicate instanceof WP_Markdown_Native_Table_Predicate_Group ) {
				$terms = $this->resolve_subquery_predicates( $predicate->any(), $schema, $target_table );
				if ( $terms instanceof WP_Markdown_Query_Result ) { return $terms; }
				$resolved[] = new WP_Markdown_Native_Table_Predicate_Group( $terms, $predicate->all() );
				continue;
			}
			if ( ! $predicate instanceof WP_Markdown_Native_Table_Subquery_Predicate ) {
				$resolved[] = $predicate;
				continue;
			}
			if ( ! $schema->has_column( $predicate->column() ) ) {
				return $this->failure( 'unsupported_mutation_column', 'The WHERE restriction names a column outside the persisted table schema.' );
			}
			$plan = $query_parser->lower( $predicate->query() );
			if ( ! $plan instanceof WP_Markdown_Native_Query_Plan ) {
				return $plan;
			}
			if ( 0 === strcasecmp( $target_table, $plan->table() ) ) {
				return $this->failure( 'unsupported_subquery_shape', 'mdi-native cannot materialize a write subquery from its target table before the mutation lock.' );
			}
			if ( array() !== $plan->joins()
				|| null !== $plan->union()
				|| array() !== $plan->subqueries()
				|| $this->has_comparison_predicate( $plan->predicates() )
			) {
				return $this->failure( 'unsupported_subquery_shape', 'mdi-native write subqueries must be uncorrelated single-table SELECTs.' );
			}
			if ( 1 !== count( $plan->projection() ) ) {
				return $this->failure( 'unsupported_subquery_shape', 'mdi-native IN subqueries must project exactly one column.' );
			}
			$result = $query_runtime->execute_plan( $plan );
			if ( false === $result->return_value() ) {
				return $result;
			}
			$state = $result->wpdb_state();
			$columns = $state['col_info'];
			if ( 1 !== count( $columns ) || ! is_string( $columns[0]->name ?? null ) || '' === $columns[0]->name ) {
				return $this->failure( 'unsupported_subquery_shape', 'mdi-native IN subqueries must return exactly one named result column.' );
			}
			$rows = $state['last_result'];
			$values = array();
			foreach ( $rows as $row ) {
				$value = $row->{ $columns[0]->name } ?? null;
				if ( null !== $value ) {
					$values[] = $value;
				}
			}
			$resolved[] = new WP_Markdown_Native_Table_Predicate( $predicate->column(), $values, false );
		}
		return $resolved;
	}

	/** @param array<int,WP_Markdown_Native_Query_Predicate> $predicates */
	private function has_comparison_predicate( array $predicates ): bool {
		foreach ( $predicates as $predicate ) {
			if ( null !== $predicate->comparison_column() ) {
				return true;
			}
		}
		return false;
	}

	/** @param array{summary:array<string,array{null:int,empty:int}>} $index @param array<int,mixed> $predicates */
	private function index_excludes( array $index, array $predicates ): bool {
		foreach ( $predicates as $predicate ) {
			if ( $this->index_predicate_excludes( $index, $predicate ) ) {
				return true;
			}
		}
		return false;
	}

	/** @param array{summary:array<string,array{null:int,empty:int}>} $index */
	private function index_predicate_excludes( array $index, mixed $predicate ): bool {
		if ( $predicate instanceof WP_Markdown_Native_Table_Predicate_Group ) {
			foreach ( $predicate->any() as $alternative ) {
				$excluded = $this->index_predicate_excludes( $index, $alternative );
				if ( $excluded === $predicate->all() ) {
					return $excluded;
				}
			}
			return ! $predicate->all();
		}
		if ( ! $predicate instanceof WP_Markdown_Native_Table_Predicate || '=' !== $predicate->operator() ) {
			return false;
		}
		$counts = $index['summary'][ $predicate->column() ] ?? null;
		if ( ! is_array( $counts ) ) {
			return false;
		}
		$can_match = $predicate->matches_null() && 0 < $counts['null'];
		foreach ( $predicate->values() as $value ) {
			if ( '' !== $value ) {
				return false;
			}
			$can_match = $can_match || 0 < $counts['empty'];
		}
		return ! $can_match;
	}

	/**
	 * Decide whether one row satisfies every conjunctive restriction.
	 *
	 * @param array<string,mixed>                          $row        Canonical row.
	 * @param array<int,WP_Markdown_Native_Table_Predicate> $predicates Restrictions.
	 */
	/**
	 * @param array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group> $predicates
	 */
	private function restricts( array $row, array $predicates, WP_Markdown_Native_Table_Schema $schema ): bool {
		return WP_Markdown_Native_Table_Write_Selection::restricts( $row, $predicates, $schema );
	}

	/** @param WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group $predicate @return array<int,string> */
	private function predicate_columns( $predicate ): array {
		if ( $predicate instanceof WP_Markdown_Native_Table_Predicate_Group ) {
			$columns = array();
			foreach ( $predicate->any() as $alternative ) {
				foreach ( $this->predicate_columns( $alternative ) as $column ) {
					$columns[] = $column;
				}
			}
			return array_values( array_unique( $columns ) );
		}
		return array( $predicate->column() );
	}

	private function supports_unique_indexes( array $definition ): bool {
		foreach ( $definition['indexes'] as $index ) {
			if ( true !== ( $index['unique'] ?? false ) ) {
				continue;
			}
			foreach ( $index['columns'] as $column ) {
				$name   = $column['name'] ?? '';
				$type   = (string) ( $definition['columns'][ $name ]['type'] ?? '' );
				$length = $column['length'] ?? null;
				if ( ! $this->unique_column_type_supported( $type ) ) {
					return false;
				}
				if ( null !== $length && ( ! is_int( $length ) || $length < 1 || WP_Markdown_Native_Schema_Catalog::is_integer( $type ) ) ) {
					return false;
				}
			}
		}
		return true;
	}

	private function unique_index_value( mixed $value, mixed $length ): mixed {
		if ( null === $value || ! is_int( $length ) ) {
			return $value;
		}
		return is_string( $value ) ? substr( $value, 0, $length ) : $value;
	}

	private function unique_column_type_supported( string $type ): bool {
		return WP_Markdown_Native_Schema_Catalog::is_integer( $type ) || in_array( $type, array( 'char', 'varchar' ), true );
	}

	/** @param array<string,mixed> $row @param array<string,mixed> $definition */
	private function unique_values_enforceable( array $row, array $definition ): bool {
		foreach ( $definition['indexes'] as $index ) {
			if ( true !== ( $index['unique'] ?? false ) ) {
				continue;
			}
			foreach ( $index['columns'] as $column ) {
				$name  = (string) ( $column['name'] ?? '' );
				$value = $row[ $name ] ?? null;
				$type  = (string) ( $definition['columns'][ $name ]['type'] ?? '' );
				if ( null === $value || WP_Markdown_Native_Schema_Catalog::is_integer( $type ) ) {
					continue;
				}
				if ( ! is_string( $value ) || 1 === preg_match( '/[^\x00-\x7F]/', $value ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/** @param array<string,int|string|null> $values @param array<string,mixed> $definition */
	private function preserves_unique_values( array $values, array $definition ): bool {
		foreach ( $definition['indexes'] as $index ) {
			if ( true !== ( $index['unique'] ?? false ) ) {
				continue;
			}
			foreach ( $index['columns'] as $column ) {
				if ( array_key_exists( (string) ( $column['name'] ?? '' ), $values ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/** @param array<string,int|string|null> $values @param array<string,mixed> $definition */
	private function preserves_index_values( array $values, array $definition ): bool {
		if ( ! $this->preserves_unique_values( $values, $definition ) ) {
			return false;
		}
		foreach ( $definition['columns'] as $name => $column ) {
			if ( true === ( $column['auto_increment'] ?? false ) && array_key_exists( $name, $values ) ) {
				return false;
			}
		}
		return true;
	}

	private function unique_set_is_verified( string $suffix, string $path ): bool {
		return isset( $this->unique_sets_verified[ $suffix ] )
			&& $this->unique_sets_verified[ $suffix ]->is( WP_Markdown_File_Witness::take( $path ) );
	}

	private function remember_verified_unique_set( string $suffix, string $path ): void {
		$witness = WP_Markdown_File_Witness::take( $path );
		if ( null === $witness ) {
			unset( $this->unique_sets_verified[ $suffix ] );
			return;
		}
		$this->unique_sets_verified[ $suffix ] = $witness;
	}

	/**
	 * @param array<int,array<string,mixed>> $rows
	 * @param array<string,mixed>            $definition
	 */
	private function unique_set_violation( array $rows, array $definition, WP_Markdown_Native_Table_Schema $schema ): ?WP_Markdown_Query_Result {
		$seen = array();
		foreach ( $rows as $row ) {
			if ( ! $this->unique_values_enforceable( $row, $definition ) ) {
				return $this->failure( 'unsupported_unique_collation', 'mdi-native cannot enforce a unique key that is not exact ASCII or integer identity.' );
			}
			foreach ( $definition['indexes'] as $position => $index ) {
				if ( true !== ( $index['unique'] ?? false ) ) {
					continue;
				}
				$parts = array();
				foreach ( $index['columns'] as $column ) {
					$name = (string) ( $column['name'] ?? '' );
					if ( ! array_key_exists( $name, $row ) || null === $row[ $name ] ) {
						// MySQL permits multiple NULL values in a unique index.
						continue 2;
					}
					$key = $schema->value_key(
						$name,
						$this->unique_index_value( $row[ $name ], $column['length'] ?? null )
					);
					if ( null === $key ) {
						continue 2;
					}
					$parts[] = $key;
				}
				$name = (string) ( $index['name'] ?? $position );
				$key  = implode( "\x1f", $parts );
				if ( isset( $seen[ $name ][ $key ] ) ) {
					return $this->failure( 'duplicate_key', 'The UPDATE row duplicates a persisted unique key.' );
				}
				$seen[ $name ][ $key ] = true;
			}
		}
		return null;
	}

	/** @param array<string,mixed> $definition */
	/**
	 * Report whether a definition is authoritative enough to mutate.
	 *
	 * A plugin table earns trust from its persisted schema file. A core table
	 * carries no such file because its definition is generated from WordPress
	 * core itself and verified against a recorded hash, which is the stronger
	 * provenance of the two.
	 *
	 * @param array<string,mixed> $definition
	 */
	private function is_authoritative_definition( string $suffix, array $definition, string $prefix, string $table ): bool {
		return $this->is_persisted_definition( $suffix, $definition, $prefix, $this->root_for( $table ) )
			|| $this->is_generated_core_definition( $suffix, $definition );
	}

	/** @param array<string,mixed> $definition */
	private function is_generated_core_definition( string $suffix, array $definition ): bool {
		return WP_Markdown_Native_Schema_Catalog::is_generated_core_definition( $suffix, $definition );
	}

	private function is_persisted_definition( string $suffix, array $definition, string $prefix, string $root ): bool {
		$directory = realpath( $root . '/_schema' );
		$path = false === $directory ? '' : $directory . '/' . $suffix . '.sql';
		if ( false === $directory || is_link( $root . '/_schema' ) || ! is_file( $path ) || is_link( $path ) ) {
			return false;
		}
		try {
			$compiled = WP_Markdown_Native_Schema_Catalog::compile( (string) file_get_contents( $path ), array( $prefix ) );
			return array( $suffix => $definition ) === $compiled;
		} catch ( Throwable ) {
			return false;
		}
	}

	/*
	 * Durable AUTO_INCREMENT high-water marks.
	 *
	 * Generic tables derived the next identifier from the largest value still
	 * present, so deleting the newest row handed its identifier out again. MySQL
	 * never does that, and callers rely on it: Action Scheduler deletes a claim
	 * row on release while completed actions keep its claim_id, so a reissued
	 * claim_id re-selected those finished actions on every queue run. The high
	 * water per table lives beside the snapshot, is only raised, and is updated
	 * under the table lock every insert already holds. It is not journaled:
	 * like MySQL, a rolled-back insert does not return its value.
	 */

	/** @return array<string,int> */
	private function auto_increment_floors( string $directory, string $suffix ): array {
		$path = $this->auto_increment_path( $directory, $suffix, false );
		if ( null === $path || ! is_file( $path ) || is_link( $path ) ) {
			return array();
		}
		$record = json_decode( (string) @file_get_contents( $path ), true );
		if ( ! is_array( $record ) || 1 !== ( $record['version'] ?? null ) || ! is_array( $record['high_water'] ?? null ) ) {
			return array();
		}
		$floors = array();
		foreach ( $record['high_water'] as $column => $value ) {
			if ( is_string( $column ) && is_int( $value ) && $value >= 0 ) {
				$floors[ $column ] = $value;
			}
		}
		return $floors;
	}

	/**
	 * @param array<string,mixed> $row        Inserted row.
	 * @param array<string,mixed> $definition Compiled definition.
	 * @param array<string,int>   $floors     High-water values read before the insert.
	 */
	private function record_auto_increment( string $directory, string $suffix, array $row, array $definition, array $floors ): void {
		$high_water = $floors;
		$changed    = false;
		foreach ( $definition['columns'] as $name => $column ) {
			if ( true !== ( $column['auto_increment'] ?? false ) || ! isset( $row[ $name ] ) || ! is_numeric( $row[ $name ] ) ) {
				continue;
			}
			// An explicit identifier above the counter raises it, as in MySQL.
			$value = (int) $row[ $name ];
			if ( $value > ( $high_water[ $name ] ?? 0 ) ) {
				$high_water[ $name ] = $value;
				$changed             = true;
			}
		}
		$path = $changed ? $this->auto_increment_path( $directory, $suffix, true ) : null;
		if ( null === $path ) {
			return;
		}
		$json = json_encode( array( 'version' => 1, 'high_water' => $high_water ) );
		$temp = $path . '.tmp-' . getmypid() . '-' . bin2hex( random_bytes( 8 ) );
		if ( false === $json || false === @file_put_contents( $temp, $json ) || ! @rename( $temp, $path ) ) {
			// A missing record only loses the floor; the rows still bound the next value.
			@unlink( $temp );
		}
	}

	private function auto_increment_path( string $directory, string $suffix, bool $create ): ?string {
		$records = $directory . '/.auto_increment';
		if ( ! is_dir( $records ) && ( ! $create || ( ! @mkdir( $records, 0755 ) && ! is_dir( $records ) ) ) ) {
			return null;
		}
		$real = realpath( $records );
		if ( false === $real || is_link( $records ) || dirname( $real ) !== $directory ) {
			return null;
		}
		return $real . '/' . $suffix . '.json';
	}

	private function tables_directory( string $root ): string|WP_Markdown_Query_Result {
		$path = $root . '/_tables';
		if ( ! file_exists( $path ) && ! @mkdir( $path, 0755 ) && ! is_dir( $path ) ) {
			return $this->failure( 'tables_directory_failed', 'The canonical tables directory could not be created.' );
		}
		$directory = realpath( $path );
		if ( false === $directory || ! is_dir( $directory ) || is_link( $path ) || dirname( $directory ) !== $root ) {
			return $this->failure( 'unsafe_tables_directory', 'The canonical tables directory is unavailable or unsafe.' );
		}
		return $directory;
	}

	/** Coordinate only writers that publish the same canonical table. */
	private function table_lock( string $directory, string $suffix ) {
		$path = $directory . '/.mdi-native-' . hash( 'sha256', $suffix ) . '.lock';
		$lock = @fopen( $path, 'c+b' );
		if ( false === $lock || ! flock( $lock, LOCK_EX ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock );
			}
			return $this->failure( 'mutation_lock_failed', 'The canonical table mutation lock could not be acquired.' );
		}
		return $lock;
	}

	/** @param array<int,array<string,mixed>> $rows */
	private function write( string $path, array $rows ): true|WP_Markdown_Query_Result {
		if ( is_link( $path ) || ( file_exists( $path ) && ! is_file( $path ) ) ) {
			return $this->failure( 'unsafe_table_file', 'The canonical table file is unavailable or unsafe.' );
		}
		if ( null !== $this->transactions ) {
			$recorded = $this->is_temporary_path( $path ) ? $this->transactions->record_ephemeral( $path ) : $this->transactions->record( $path );
			if ( true !== $recorded ) {
				return $this->failure( 'transaction_journal_failed', $recorded );
			}
		}
		try {
			$json = json_encode( $rows, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR );
			$temp = $path . '.tmp-' . getmypid() . '-' . bin2hex( random_bytes( 8 ) );
		} catch ( Throwable ) {
			return $this->failure( 'table_encoding_failed', 'The canonical table rows could not be encoded.' );
		}
		$handle = @fopen( $temp, 'x+b' );
		if ( false === $handle ) {
			return $this->failure( 'table_temp_failed', 'The canonical table temporary file could not be created.' );
		}
		$error = null;
		try {
			$length = strlen( $json );
			$offset = 0;
			while ( $offset < $length ) {
				$written = fwrite( $handle, substr( $json, $offset ) );
				if ( false === $written || 0 === $written ) {
					$error = $this->failure( 'table_write_failed', 'The canonical table rows could not be written.' );
					break;
				}
				$offset += $written;
			}
			if ( null === $error && ( ! fflush( $handle ) || ( function_exists( 'fsync' ) && ! fsync( $handle ) ) ) ) {
				$error = $this->failure( 'table_flush_failed', 'The canonical table rows could not be flushed.' );
			}
		} finally {
			fclose( $handle );
		}
		if ( null !== $error ) {
			@unlink( $temp );
			return $error;
		}
		if ( ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			return $this->failure( 'table_publish_failed', 'The canonical table rows could not be atomically published.' );
		}
		return true;
	}

	private function root_for( string $table ): string {
		return null !== $this->temporary_tables && $this->temporary_tables->has( $table )
			? $this->temporary_tables->root()
			: $this->state_root;
	}

	private function index_for( string $root ): WP_Markdown_Native_Table_Index {
		if ( $root === $this->state_root ) {
			return $this->index;
		}
		return $this->temporary_indexes[ $root ] ??= new WP_Markdown_Native_Table_Index( $root . DIRECTORY_SEPARATOR . '_tables' );
	}

	private function is_temporary_path( string $path ): bool {
		return null !== $this->temporary_tables && str_starts_with( $path, $this->temporary_tables->root() . DIRECTORY_SEPARATOR );
	}

	private function failure( string $reason, string $message ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::failure(
			array(
				'code'    => 'markdown_db_native_table_mutation_failed',
				'reason'  => $reason,
				'message' => $message,
			)
		);
	}
}
