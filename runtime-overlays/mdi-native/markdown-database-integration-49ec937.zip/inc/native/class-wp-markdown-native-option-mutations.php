<?php
/** Typed atomic mutations for canonical WordPress options. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_Markdown_Native_Option_Mutation {
	/**
	 * @param array{option_value?:string,autoload?:string} $values
	 * @param array{option_value?:string,autoload?:string} $upsert_values
	 */
	public function __construct(
		private readonly string $operation,
		private readonly string $option_name,
		private readonly array $values,
		private readonly ?string $expected_option_value = null,
		private readonly bool $expected_option_value_is_binary = false,
		private readonly array $upsert_values = array(),
		private readonly bool $ignore_duplicate = false
	) {
		if ( ! in_array( $operation, array( 'insert', 'upsert', 'update', 'delete' ), true ) ) {
			throw new InvalidArgumentException( 'Unsupported option mutation operation.' );
		}
	}

	public function is_insert(): bool {
		return 'insert' === $this->operation;
	}

	public function is_upsert(): bool {
		return 'upsert' === $this->operation;
	}

	public function is_delete(): bool {
		return 'delete' === $this->operation;
	}

	public function ignores_duplicate(): bool {
		return $this->ignore_duplicate;
	}

	public function option_name(): string {
		return $this->option_name;
	}

	/** @return array<string,string> */
	public function values(): array {
		return $this->values;
	}

	public function expected_option_value(): ?string {
		return $this->expected_option_value;
	}

	public function expected_option_value_is_binary(): bool {
		return $this->expected_option_value_is_binary;
	}

	/** @return array{option_value?:string,autoload?:string} */
	public function upsert_values(): array {
		return $this->upsert_values;
	}
}

final class WP_Markdown_Native_Option_Mutation_Parser {
	/** @var array<int,WP_Markdown_Native_SQL_Token> */
	private array $tokens = array();
	private int $position = 0;

	/** @return array<int,WP_Markdown_Native_Option_Mutation>|WP_Markdown_Query_Result */
	public function parse( WP_Markdown_Query_Request $request ): array|WP_Markdown_Query_Result {
		try {
			$this->tokens = ( new WP_Markdown_Native_SQL_Tokenizer() )->tokenize( $request->sql() );
			$this->position = 0;
			if ( 0 === strcasecmp( 'UPDATE', (string) $this->current()->value() ) ) {
				$update = $this->parse_update( $request );
				return $update instanceof WP_Markdown_Query_Result ? $update : array( $update );
			}
			if ( 0 === strcasecmp( 'DELETE', (string) $this->current()->value() ) ) {
				$delete = $this->parse_delete( $request );
				return $delete instanceof WP_Markdown_Query_Result ? $delete : array( $delete );
			}
			$this->word( 'INSERT' );
			$ignore_duplicate = false;
			if ( 0 === strcasecmp( 'IGNORE', (string) $this->current()->value() ) ) {
				$ignore_duplicate = true;
				++$this->position;
			}
			$this->word( 'INTO' );
			$table = $this->identifier();
			if ( $request->table_prefix() . 'options' !== $table ) {
				return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only the active canonical options table.' );
			}

			$columns = $this->identifier_list();
			$this->word( 'VALUES' );
			// WordPress writes a fresh site's options as one multi-row INSERT.
			$rows = array();
			do {
				$values = $this->literal_list();
				if ( count( $columns ) !== count( $values ) || array( 'autoload', 'option_name', 'option_value' ) !== $this->set( $columns ) ) {
					return $this->failure( 'unsupported_option_upsert', 'mdi-native requires one complete canonical option row.' );
				}
				$row = array_combine( $columns, $values );
				if ( false === $row ) {
					return $this->failure( 'unsupported_option_upsert', 'mdi-native requires one complete canonical option row.' );
				}
				$rows[] = $row;
				if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
					break;
				}
				++$this->position;
			} while ( true );
			if ( WP_Markdown_Native_SQL_Token::END === $this->current()->type() ) {
				++$this->position;
				return array_map(
					static function ( array $row ) use ( $ignore_duplicate ): WP_Markdown_Native_Option_Mutation {
						$option_name = (string) $row['option_name'];
						unset( $row['option_name'] );
						/** @var array<string,string> $row */
						return new WP_Markdown_Native_Option_Mutation( 'insert', $option_name, $row, null, false, array(), $ignore_duplicate );
					},
					$rows
				);
			}
			if ( 1 !== count( $rows ) ) {
				return $this->failure( 'unsupported_option_upsert', 'mdi-native requires one canonical option row for an upsert.' );
			}
			/** @var array{option_name:string,option_value:string,autoload:string} $row */
			$row = $rows[0];
			$option_name = $row['option_name'];
			unset( $row['option_name'] );

			$this->word( 'ON' );
			$this->word( 'DUPLICATE' );
			$this->word( 'KEY' );
			$this->word( 'UPDATE' );
			$assignments = array();
			$assigned = array();
			do {
				$target = $this->identifier();
				if ( ! in_array( $target, array( 'option_name', 'option_value', 'autoload' ), true ) || isset( $assigned[ $target ] ) ) {
					return $this->failure( 'unsupported_option_upsert', 'mdi-native supports deterministic canonical option upsert assignments.' );
				}
				$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
				if ( 0 === strcasecmp( 'VALUES', (string) $this->current()->value() ) ) {
					$this->word( 'VALUES' );
					$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
					$source = $this->identifier();
					$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
					if ( $target !== $source ) {
						return $this->failure( 'unsupported_option_upsert', 'mdi-native requires deterministic VALUES assignments for an option upsert.' );
					}
					if ( 'option_name' !== $target ) {
						$assignments[ $target ] = $row[ $target ];
					}
				} elseif ( 'autoload' === $target && WP_Markdown_Native_SQL_Token::STRING === $this->current()->type() ) {
					$assignments[ $target ] = (string) $this->current()->value();
					++$this->position;
				} else {
					return $this->failure( 'unsupported_option_upsert', 'mdi-native requires deterministic option upsert assignments.' );
				}
				$assigned[ $target ] = true;
				if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
					break;
				}
				++$this->position;
			} while ( true );
			$this->type( WP_Markdown_Native_SQL_Token::END );
			return array( new WP_Markdown_Native_Option_Mutation( 'upsert', $option_name, $row, null, false, $assignments ) );
		} catch ( WP_Markdown_Native_SQL_Parse_Error $error ) {
			return WP_Markdown_Query_Result::failure(
				array(
					'code'       => 'markdown_db_native_unsupported_query',
					'reason'     => $error->reason(),
					'message'    => 'mdi-native supports typed canonical option mutations and bounded SELECT queries only.',
					'sql_offset' => $error->sql_offset(),
				)
			);
		}
	}

	private function parse_update( WP_Markdown_Query_Request $request ): WP_Markdown_Native_Option_Mutation|WP_Markdown_Query_Result {
		$this->word( 'UPDATE' );
		$table = $this->identifier();
		if ( $request->table_prefix() . 'options' !== $table ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only the active canonical options table.' );
		}
		$this->word( 'SET' );
		$changes = array();
		do {
			$column = $this->identifier();
			if ( ! in_array( $column, array( 'option_value', 'autoload' ), true ) || isset( $changes[ $column ] ) ) {
				return $this->failure( 'unsupported_option_update', 'mdi-native option updates may set option_value and autoload once each.' );
			}
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$changes[ $column ] = (string) $this->type( WP_Markdown_Native_SQL_Token::STRING )->value();
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		$this->word( 'WHERE' );
		if ( 'option_name' !== $this->identifier() ) {
			return $this->failure( 'unsupported_option_update', 'mdi-native option updates require one exact option_name identity.' );
		}
		$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
		$option_name = (string) $this->type( WP_Markdown_Native_SQL_Token::STRING )->value();
		$expected_option_value = null;
		$expected_option_value_is_binary = false;
		if ( 0 === strcasecmp( 'AND', (string) $this->current()->value() ) ) {
			++$this->position;
			if ( 0 === strcasecmp( 'BINARY', (string) $this->current()->value() ) ) {
				++$this->position;
				$expected_option_value_is_binary = true;
			}
			if ( 'option_value' !== $this->identifier() ) {
				return $this->failure( 'unsupported_option_update', 'mdi-native option updates may condition only on the current option value.' );
			}
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$expected_option_value = (string) $this->type( WP_Markdown_Native_SQL_Token::STRING )->value();
		}
		$this->type( WP_Markdown_Native_SQL_Token::END );
		return new WP_Markdown_Native_Option_Mutation( 'update', $option_name, $changes, $expected_option_value, $expected_option_value_is_binary );
	}

	private function parse_delete( WP_Markdown_Query_Request $request ): WP_Markdown_Native_Option_Mutation|WP_Markdown_Query_Result {
		$this->word( 'DELETE' );
		$this->word( 'FROM' );
		if ( $request->table_prefix() . 'options' !== $this->identifier() ) {
			return $this->failure( 'unsupported_mutation_table', 'mdi-native can mutate only the active canonical options table.' );
		}
		$this->word( 'WHERE' );
		if ( 'option_name' !== $this->identifier() ) {
			return $this->failure( 'unsupported_option_delete', 'mdi-native option deletes require one exact option_name identity.' );
		}
		$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
		$option_name = (string) $this->type( WP_Markdown_Native_SQL_Token::STRING )->value();
		$expected_option_value = null;
		if ( 0 === strcasecmp( 'AND', (string) $this->current()->value() ) ) {
			++$this->position;
			if ( 'option_value' !== $this->identifier() ) {
				return $this->failure( 'unsupported_option_delete', 'mdi-native option deletes may condition only on the current option value.' );
			}
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$expected_option_value = (string) $this->type( WP_Markdown_Native_SQL_Token::STRING )->value();
		}
		$this->type( WP_Markdown_Native_SQL_Token::END );
		return new WP_Markdown_Native_Option_Mutation( 'delete', $option_name, array(), $expected_option_value );
	}

	/** @return array<int,string> */
	private function identifier_list(): array {
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$values = array();
		do {
			$value = $this->identifier();
			if ( isset( $values[ $value ] ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'duplicate_mutation_column', $this->current()->sql_offset(), 'Duplicate mutation column.' );
			}
			$values[ $value ] = $value;
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		return array_values( $values );
	}

	/** @return array<int,string> */
	private function literal_list(): array {
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$values = array();
		do {
			$token = $this->current();
			if ( ! in_array( $token->type(), array( WP_Markdown_Native_SQL_Token::STRING, WP_Markdown_Native_SQL_Token::INTEGER ), true ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_option_literal', $token->sql_offset(), 'Expected a string or non-negative integer option value.' );
			}
			++$this->position;
			$values[] = (string) $token->value();
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		return $values;
	}

	private function identifier(): string {
		$token = $this->current();
		if ( ! in_array( $token->type(), array( WP_Markdown_Native_SQL_Token::WORD, WP_Markdown_Native_SQL_Token::KEYWORD, WP_Markdown_Native_SQL_Token::QUOTED_IDENTIFIER ), true ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Expected an identifier.' );
		}
		++$this->position;
		return (string) $token->value();
	}

	private function word( string $expected ): void {
		$token = $this->current();
		if ( 0 !== strcasecmp( $expected, (string) $token->value() ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Unexpected SQL token.' );
		}
		++$this->position;
	}

	private function type( string $expected ): WP_Markdown_Native_SQL_Token {
		$token = $this->current();
		if ( $expected !== $token->type() ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Unexpected SQL token.' );
		}
		++$this->position;
		return $token;
	}

	private function current(): WP_Markdown_Native_SQL_Token {
		return $this->tokens[ $this->position ];
	}

	/** @param array<int,string> $values @return array<int,string> */
	private function set( array $values ): array {
		sort( $values, SORT_STRING );
		return $values;
	}

	private function failure( string $reason, string $message ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::failure(
			array(
				'code'    => 'markdown_db_native_unsupported_query',
				'reason'  => $reason,
				'message' => $message,
			)
		);
	}
}

final class WP_Markdown_Native_Option_Mutation_Runtime {
	private string $state_root;
	private WP_Markdown_Native_Table_Schema $schema;
	private WP_Markdown_Native_Option_Provider $provider;

	public function __construct(
		string $state_root,
		private WP_Markdown_Native_Option_Mutation_Parser $parser = new WP_Markdown_Native_Option_Mutation_Parser(),
		private ?WP_Markdown_Native_Transaction_Journal $transactions = null
	) {
		$root = realpath( $state_root );
		if ( false === $root || ! is_dir( $root ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		$this->state_root = rtrim( $root, DIRECTORY_SEPARATOR );
		$this->schema = WP_Markdown_Native_Runtime_Factory::options_schema();
		$this->provider = new WP_Markdown_Native_Option_Provider( $this->state_root, $this->schema );
	}

	public function execute( WP_Markdown_Query_Request $request ): WP_Markdown_Query_Result {
		$mutations = $this->parser->parse( $request );
		if ( $mutations instanceof WP_Markdown_Query_Result ) {
			return $mutations;
		}
		if ( 1 === count( $mutations ) ) {
			return $this->mutate( $mutations[0] );
		}

		// A statement carrying many rows reports the rows it affected and the
		// identifier of the first row it created, and leaves nothing behind
		// when one of them fails.
		$owns_transaction = null !== $this->transactions && $this->transactions->is_autocommit() && ! $this->transactions->is_active();
		if ( $owns_transaction && true !== $this->transactions->begin() ) {
			return $this->failure( 'mutation_transaction_failed', 'The canonical multi-row option INSERT could not be isolated.' );
		}
		$affected = 0;
		$insert_id = 0;
		foreach ( $mutations as $mutation ) {
			$result = $this->mutate( $mutation );
			if ( false === $result->return_value() ) {
				if ( $owns_transaction ) {
					$this->transactions->rollback();
				}
				return $result;
			}
			$affected += (int) $result->return_value();
			$row_id = (int) ( $result->wpdb_state()['insert_id'] ?? 0 );
			if ( 0 === $insert_id && 0 !== $row_id ) {
				$insert_id = $row_id;
			}
		}
		if ( $owns_transaction && true !== $this->transactions->commit() ) {
			return $this->failure( 'mutation_transaction_failed', 'The canonical multi-row option INSERT could not be committed.' );
		}
		return WP_Markdown_Query_Result::mutated( $affected, $insert_id );
	}

	private function mutate( WP_Markdown_Native_Option_Mutation $mutation ): WP_Markdown_Query_Result {
		$directory = $this->options_directory();
		if ( $directory instanceof WP_Markdown_Query_Result ) {
			return $directory;
		}
		$lock = @fopen( $directory . '/.mdi-native.lock', 'c+b' );
		if ( false === $lock || ! flock( $lock, LOCK_EX ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock );
			}
			return $this->failure( 'mutation_lock_failed', 'The canonical option mutation lock could not be acquired.' );
		}

		try {
			$identity = $this->schema->value_key( 'option_name', $mutation->option_name() );
			if ( null === $identity ) {
				return $this->failure( 'unsupported_option_collation', 'The option mutation requires a deterministic ASCII identity.' );
			}

			// A canonical option resolves to a deterministic path, so the common
			// mutation reads one row rather than the whole options directory.
			$existing   = $this->existing_at_canonical_path( $directory, $mutation->option_name(), $identity );
			$maximum_id = 0;
			$file_count = null;
			if ( null === $existing ) {
				// A miss still has to prove the identity is absent under any other
				// canonical filename. Collated identities share a filename stem up to
				// case, so only those few files need reading, not every row.
				$filenames = $this->option_filenames( $directory );
				if ( $filenames instanceof WP_Markdown_Query_Result ) {
					return $filenames;
				}
				$existing = $this->existing_by_collated_stem( $directory, $filenames, $mutation->option_name(), $identity );
				if ( $existing instanceof WP_Markdown_Query_Result ) {
					return $existing;
				}
				$file_count = count( $filenames );
				if ( null === $existing && ( $mutation->is_insert() || $mutation->is_upsert() ) ) {
					$allocated = $this->allocator_high_water( $file_count );
					if ( null !== $allocated ) {
						$maximum_id = $allocated;
					} else {
						// No trustworthy allocator record: derive the next identifier
						// from every row, as before, and reseed the record after writing.
						$maximum_id = $this->scanned_maximum_id();
						if ( $maximum_id instanceof WP_Markdown_Query_Result ) {
							return $maximum_id;
						}
						// Identifiers never go backwards, as with MySQL AUTO_INCREMENT: a
						// stale record still bounds every identifier issued here.
						$maximum_id = max( $maximum_id, $this->allocator_record()['high_water'] ?? 0 );
					}
				}
			}

			if ( ! $mutation->is_insert() && ! $mutation->is_upsert() && null === $existing ) {
				return WP_Markdown_Query_Result::mutated( 0 );
			}
			if ( $mutation->is_insert() && null !== $existing ) {
				if ( $mutation->ignores_duplicate() ) {
					return WP_Markdown_Query_Result::mutated( 0 );
				}
				return $this->failure( 'duplicate_key', 'The canonical option identity already exists.' );
			}
			if ( null !== $mutation->expected_option_value() ) {
				if ( $mutation->expected_option_value_is_binary() ) {
					if ( $mutation->expected_option_value() !== $existing['row']['option_value'] ) {
						return WP_Markdown_Query_Result::mutated( 0 );
					}
				} elseif ( null === $this->schema->value_key( 'option_value', $mutation->expected_option_value() ) || null === $this->schema->value_key( 'option_value', $existing['row']['option_value'] ) ) {
					return $this->failure( 'unsupported_option_collation', 'The option mutation requires an unsupported option-value collation.' );
				} elseif ( ! $this->schema->values_match( 'option_value', $mutation->expected_option_value(), $existing['row']['option_value'] ) ) {
					return WP_Markdown_Query_Result::mutated( 0 );
				}
			}
			if ( $mutation->is_delete() ) {
				$journaled = $this->journal( $existing['path'] );
				if ( true !== $journaled ) {
					return $journaled;
				}
				if ( ! @unlink( $existing['path'] ) ) {
					return $this->failure( 'option_delete_failed', 'The canonical option row could not be deleted.' );
				}
				$this->record_deleted_option();
				return WP_Markdown_Query_Result::mutated( 1 );
			}
			$is_insert = null === $existing;
			if ( $is_insert && PHP_INT_MAX === $maximum_id ) {
				return $this->failure( 'option_id_exhausted', 'The canonical option ID range is exhausted.' );
			}
			$option_id = $is_insert ? $maximum_id + 1 : (int) $existing['row']['option_id'];
			$values = $mutation->values();
			$row = ! $mutation->is_insert() && ! $mutation->is_upsert()
				? array_merge( $existing['row'], $values )
				: ( $mutation->is_upsert() && null !== $existing
					? array_merge( $existing['row'], $mutation->upsert_values() )
					: array(
					'option_id'    => $option_id,
					'option_name'  => $mutation->option_name(),
					'option_value' => $values['option_value'],
					'autoload'     => $values['autoload'],
					) );
			if ( ! $this->schema->validate_row( $row ) ) {
				return $this->failure( 'invalid_option_row', 'The option mutation is outside the canonical WordPress schema.' );
			}
			if ( null !== $existing && $existing['row'] === $row ) {
				return WP_Markdown_Query_Result::mutated( 0 );
			}

			$path = ! $mutation->is_insert() && ! $mutation->is_upsert()
				? $existing['path']
				: $directory . '/' . WP_Markdown_Canonical_Option_Path::filename( $mutation->option_name() );
			if ( $mutation->is_upsert() && null !== $existing && $existing['path'] !== $path ) {
				return $this->failure( 'noncanonical_option_identity', 'The existing option identity does not use its canonical filename.' );
			}
			$written = $this->write( $path, $row );
			if ( $written instanceof WP_Markdown_Query_Result ) {
				return $written;
			}
			if ( $is_insert && null !== $file_count ) {
				$this->record_allocation( $option_id, $file_count + 1 );
			}
			$rows_affected = $mutation->is_upsert() ? ( $is_insert ? 1 : 2 ) : 1;
			return WP_Markdown_Query_Result::mutated( $rows_affected, $is_insert ? $option_id : 0 );
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}

	/**
	 * Canonical option filenames in the store, excluding temporaries and locks.
	 *
	 * @return array<int,string>|WP_Markdown_Query_Result
	 */
	private function option_filenames( string $directory ): array|WP_Markdown_Query_Result {
		$entries = @scandir( $directory );
		if ( false === $entries ) {
			return $this->failure( 'options_directory_unreadable', 'The canonical options directory could not be listed.' );
		}
		return array_values( array_filter( $entries, static fn( string $entry ): bool => str_ends_with( $entry, '.json' ) ) );
	}

	/**
	 * Find a row whose collated identity matches under a noncanonical filename.
	 *
	 * @param array<int,string> $filenames Canonical option filenames.
	 * @return array{path:string,row:array<string,mixed>}|WP_Markdown_Query_Result|null
	 */
	private function existing_by_collated_stem( string $directory, array $filenames, string $name, string $identity ): array|WP_Markdown_Query_Result|null {
		$stem      = strtolower( WP_Markdown_Canonical_Option_Path::stem( $name ) );
		$canonical = WP_Markdown_Canonical_Option_Path::filename( $name );
		$found     = null;
		foreach ( $filenames as $filename ) {
			if ( $filename === $canonical || ! in_array( $stem, array_map( 'strtolower', WP_Markdown_Canonical_Option_Path::filename_stems( $filename ) ), true ) ) {
				continue;
			}
			$path = $directory . '/' . $filename;
			if ( is_link( $path ) || ! is_file( $path ) ) {
				continue;
			}
			$row = json_decode( (string) @file_get_contents( $path ), true );
			if ( ! is_array( $row ) || ! isset( $row['option_name'] ) || $identity !== $this->schema->value_key( 'option_name', $row['option_name'] ) ) {
				continue;
			}
			if ( null !== $found ) {
				return $this->failure( 'duplicate_collated_identity', 'Canonical option files contain duplicate collated identities.' );
			}
			foreach ( $this->schema->column_names() as $column ) {
				if ( ! array_key_exists( $column, $row ) ) {
					return $this->failure( 'invalid_option_row', 'A canonical option file is missing a schema column.' );
				}
			}
			$found = array( 'path' => $path, 'row' => $row );
		}
		return $found;
	}

	/** The largest option_id across every canonical row: the slow, authoritative path. */
	private function scanned_maximum_id(): int|WP_Markdown_Query_Result {
		$rows = $this->provider->read(
			new WP_Markdown_Native_Table_Access(
				$this->schema->column_names(),
				null,
				$this->schema->natural_order(),
				PHP_INT_MAX
			)
		);
		if ( $rows instanceof WP_Markdown_Query_Result ) {
			return $rows;
		}
		$maximum_id = 0;
		foreach ( $rows as $candidate ) {
			$maximum_id = max( $maximum_id, (int) $candidate['option_id'] );
		}
		return $maximum_id;
	}

	/*
	 * Option identifier allocation.
	 *
	 * Allocating max(option_id) + 1 by reading every row costs time proportional
	 * to the whole options store, and it runs under the exclusive mutation lock,
	 * so every new option stalled all other writers. The allocator record keeps
	 * the high-water identifier and the file count it was valid for. Every insert
	 * and delete made here updates it under the same lock; an update changes
	 * neither. Any other change to the set of files (another writer, a restored
	 * backup, a rolled-back transaction) leaves the count different, so the next
	 * insert falls back to the full scan and reseeds. A stale record can only
	 * cost speed, never a duplicate identifier.
	 */

	/** High-water option_id when the record still describes this file set. */
	private function allocator_high_water( int $file_count ): ?int {
		$record = $this->allocator_record();
		if ( null === $record || $record['count'] !== $file_count ) {
			return null;
		}
		return $record['high_water'];
	}

	private function record_allocation( int $option_id, int $file_count ): void {
		$record = $this->allocator_record();
		$high   = max( $option_id, null === $record ? 0 : $record['high_water'] );
		$this->write_allocator_record( $high, $file_count );
	}

	private function record_deleted_option(): void {
		$record = $this->allocator_record();
		if ( null === $record ) {
			return;
		}
		// The count describes the file set this record trusts. A delete only keeps
		// it trustworthy when the record already matched; otherwise the next
		// insert's mismatch correctly forces a rescan either way.
		$this->write_allocator_record( $record['high_water'], max( 0, $record['count'] - 1 ) );
	}

	private function allocator_path(): ?string {
		$directory = $this->state_root . '/_indexes';
		if ( ! file_exists( $directory ) && ! @mkdir( $directory, 0755 ) && ! is_dir( $directory ) ) {
			return null;
		}
		$root = realpath( $directory );
		if ( false === $root || is_link( $directory ) || dirname( $root ) !== $this->state_root ) {
			return null;
		}
		return $root . '/option-id-allocator.json';
	}

	/** @return array{high_water:int,count:int}|null */
	private function allocator_record(): ?array {
		$path = $this->allocator_path();
		if ( null === $path || ! is_file( $path ) || is_link( $path ) ) {
			return null;
		}
		$record = json_decode( (string) @file_get_contents( $path ), true );
		if ( ! is_array( $record ) || 1 !== ( $record['version'] ?? null ) || ! is_int( $record['high_water'] ?? null ) || ! is_int( $record['count'] ?? null ) || $record['high_water'] < 0 || $record['count'] < 0 ) {
			return null;
		}
		return array( 'high_water' => $record['high_water'], 'count' => $record['count'] );
	}

	private function write_allocator_record( int $high_water, int $count ): void {
		$path = $this->allocator_path();
		if ( null === $path ) {
			return;
		}
		$json = json_encode( array( 'version' => 1, 'high_water' => $high_water, 'count' => $count ) );
		$temp = $path . '.tmp-' . getmypid() . '-' . bin2hex( random_bytes( 8 ) );
		if ( false === $json || false === @file_put_contents( $temp, $json ) || ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			// An unwritable record must not survive with a count that could match
			// again later; without it the next insert simply rescans.
			@unlink( $path );
		}
	}

	private function options_directory(): string|WP_Markdown_Query_Result {
		$path = $this->state_root . '/_options';
		// The first option written to a site creates its store, which is how
		// an installation takes hold in an empty directory.
		if ( ! file_exists( $path ) && ! @mkdir( $path, 0755 ) && ! is_dir( $path ) ) {
			return $this->failure( 'options_directory_failed', 'The canonical options directory could not be created.' );
		}
		$root = realpath( $path );
		if ( false === $root || ! is_dir( $root ) || is_link( $path ) || dirname( $root ) !== $this->state_root ) {
			return $this->failure( 'unsafe_options_directory', 'The canonical options directory is unavailable or unsafe.' );
		}
		return $root;
	}

	/** @param array<string,mixed> $row */
	/**
	 * Resolve one canonical option row by its deterministic path.
	 *
	 * @return array{path:string,row:array<string,mixed>}|null
	 */
	private function existing_at_canonical_path( string $directory, string $name, string $identity ): ?array {
		$path = $directory . '/' . WP_Markdown_Canonical_Option_Path::filename( $name );
		if ( ! is_file( $path ) || is_link( $path ) ) {
			return null;
		}
		$contents = @file_get_contents( $path );
		if ( false === $contents ) {
			return null;
		}
		$row = json_decode( $contents, true );
		if ( ! is_array( $row ) || ! isset( $row['option_name'] ) ) {
			return null;
		}
		if ( $identity !== $this->schema->value_key( 'option_name', $row['option_name'] ) ) {
			return null;
		}
		foreach ( $this->schema->column_names() as $column ) {
			if ( ! array_key_exists( $column, $row ) ) {
				return null;
			}
		}
		return array( 'path' => $path, 'row' => $row );
	}

	/** Journal a canonical path so an open transaction can restore it. */
	private function journal( string $path ): true|WP_Markdown_Query_Result {
		if ( null === $this->transactions ) {
			return true;
		}
		$recorded = $this->transactions->record( $path );
		return true === $recorded ? true : $this->failure( 'transaction_journal_failed', $recorded );
	}

	private function write( string $path, array $row ): true|WP_Markdown_Query_Result {
		$journaled = $this->journal( $path );
		if ( true !== $journaled ) {
			return $journaled;
		}
		try {
			$json = json_encode( $row, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR );
			$temp = $path . '.tmp-' . getmypid() . '-' . bin2hex( random_bytes( 8 ) );
		} catch ( Throwable ) {
			return $this->failure( 'option_encoding_failed', 'The canonical option row could not be encoded.' );
		}
		$handle = @fopen( $temp, 'x+b' );
		if ( false === $handle ) {
			return $this->failure( 'option_temp_failed', 'The canonical option temporary file could not be created.' );
		}
		$error = null;
		try {
			$length = strlen( $json );
			$offset = 0;
			while ( $offset < $length ) {
				$written = fwrite( $handle, substr( $json, $offset ) );
				if ( false === $written || 0 === $written ) {
					$error = $this->failure( 'option_write_failed', 'The canonical option row could not be written.' );
					break;
				}
				$offset += $written;
			}
			if ( null === $error && ( ! fflush( $handle ) || ( function_exists( 'fsync' ) && ! fsync( $handle ) ) ) ) {
				$error = $this->failure( 'option_flush_failed', 'The canonical option row could not be flushed.' );
			}
		} finally {
			fclose( $handle );
		}
		if ( null !== $error ) {
			@unlink( $temp );
			return $error;
		}
		if ( ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			return $this->failure( 'option_publish_failed', 'The canonical option row could not be atomically published.' );
		}
		return true;
	}

	private function failure( string $reason, string $message ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::failure(
			array(
				'code'    => 'markdown_db_native_mutation_failed',
				'reason'  => $reason,
				'message' => $message,
			)
		);
	}
}
