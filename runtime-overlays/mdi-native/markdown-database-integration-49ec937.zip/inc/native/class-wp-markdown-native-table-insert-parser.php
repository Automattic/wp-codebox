<?php
/** Bounded INSERT parsing for generic table snapshots. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_Markdown_Native_Table_Insert_Parser {
	/** @var array<int,WP_Markdown_Native_SQL_Token> */
	private array $tokens = array();
	private int $position = 0;

	/** Parse the single row a caller requires, rejecting a multi-row statement. */
	public function parse( WP_Markdown_Query_Request $request ): WP_Markdown_Native_Table_Insert|WP_Markdown_Query_Result {
		$rows = $this->parse_rows( $request );
		if ( $rows instanceof WP_Markdown_Query_Result ) {
			return $rows;
		}
		return 1 === count( $rows )
			? $rows[0]
			: $this->failure( 'unsupported_grammar', 'mdi-native requires one INSERT row for this table.' );
	}

	/** @return array<int,WP_Markdown_Native_Table_Insert>|WP_Markdown_Query_Result */
	public function parse_rows( WP_Markdown_Query_Request $request ): array|WP_Markdown_Query_Result {
		$sql = trim( $request->sql() );
		if ( str_ends_with( $sql, ';' ) ) {
			$sql = rtrim( substr( $sql, 0, -1 ) );
		}
		if ( '' === $sql || WP_Markdown_Native_SQL_Tokenizer::contains_statement_separator( $sql ) ) {
			return $this->failure( 'unsupported_grammar', 'mdi-native requires one INSERT statement.' );
		}

		try {
			$this->tokens = ( new WP_Markdown_Native_SQL_Tokenizer() )->tokenize( $sql );
			$this->position = 0;
			$replace = 0 === strcasecmp( 'REPLACE', (string) $this->current()->value() );
			$this->word( $replace ? 'REPLACE' : 'INSERT' );
			$ignore_duplicate = 0 === strcasecmp( 'IGNORE', (string) $this->current()->value() );
			if ( $ignore_duplicate ) {
				if ( $replace ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $this->current()->sql_offset(), 'mdi-native does not combine REPLACE with IGNORE.' );
				}
				++$this->position;
			}
			if ( $replace && ! $this->is_word( 'INTO' ) ) {
				// MySQL permits the INTO keyword to be omitted for REPLACE.
			} else {
				$this->word( 'INTO' );
			}
			$table = $this->identifier();
			$columns = $this->identifier_list();
			if ( 0 === strcasecmp( 'SELECT', (string) $this->current()->value() ) ) {
				$this->word( 'SELECT' );
				$rows = array( $this->select_literals() );
				$this->word( 'FROM' );
				$this->word( 'DUAL' );
				$unless_exists = $this->dual_absent_predicates( $table );
			} else {
				$this->word( 'VALUES' );
				// One statement may carry many rows, which is how WordPress
				// writes a fresh site's options in a single INSERT.
				$rows = array();
				do {
					$rows[] = $this->literal_list();
					if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
						break;
					}
					++$this->position;
				} while ( true );
				$unless_exists = null;
			}
			$upsert_assignments = null;
			if ( 0 === strcasecmp( 'ON', (string) $this->current()->value() ) ) {
				if ( $replace || $ignore_duplicate || null !== $unless_exists ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $this->current()->sql_offset(), 'mdi-native cannot combine INSERT IGNORE or INSERT SELECT FROM DUAL with ON DUPLICATE KEY UPDATE.' );
				}
				$upsert_assignments = $this->upsert_assignments( $table );
			}
			$this->type( WP_Markdown_Native_SQL_Token::END );
			$inserts = array();
			foreach ( $rows as $values ) {
				if ( count( $columns ) !== count( $values ) ) {
					return $this->failure( 'invalid_insert_row', 'mdi-native requires one value for every INSERT column.' );
				}
				$row = array_combine( $columns, $values );
				if ( false === $row ) {
					return $this->failure( 'invalid_insert_row', 'mdi-native requires one nonempty INSERT row.' );
				}
				$inserts[] = new WP_Markdown_Native_Table_Insert( $table, $row, $unless_exists, $ignore_duplicate, $upsert_assignments, $replace );
			}
			return $inserts;
		} catch ( WP_Markdown_Native_SQL_Parse_Error $error ) {
			return WP_Markdown_Query_Result::failure(
				array(
					'code'       => 'markdown_db_native_unsupported_query',
					'reason'     => $error->reason(),
					'message'    => 'mdi-native supports one typed generic INSERT row.',
					'sql_offset' => $error->sql_offset(),
				)
			);
		}
	}

	/** Parse one generic UPDATE or DELETE against a persisted snapshot table. */
	public function parse_write( WP_Markdown_Query_Request $request ): WP_Markdown_Native_Table_Write|WP_Markdown_Query_Result {
		$sql = trim( $request->sql() );
		if ( str_ends_with( $sql, ';' ) ) {
			$sql = rtrim( substr( $sql, 0, -1 ) );
		}
		if ( '' === $sql || WP_Markdown_Native_SQL_Tokenizer::contains_statement_separator( $sql ) ) {
			return $this->failure( 'unsupported_grammar', 'mdi-native requires one UPDATE or DELETE statement.' );
		}

		try {
			$this->tokens = ( new WP_Markdown_Native_SQL_Tokenizer() )->tokenize( $sql );
			$this->position = 0;
			$kind = 0 === strcasecmp( 'DELETE', (string) $this->current()->value() ) ? 'delete' : 'update';
			$values = array();
			if ( 'delete' === $kind ) {
				$this->word( 'DELETE' );
				$this->word( 'FROM' );
				$table = $this->identifier();
			} else {
				$this->word( 'UPDATE' );
				$table = $this->identifier();
				if ( $this->is_word( 'SET' ) ) {
					$this->word( 'SET' );
					$values = $this->assignments( $table );
					$derived_selection = null;
				} else {
					$derived_selection = $this->derived_selection( $table );
					$values = $this->literal_assignments();
				}
			}
			$predicates = isset( $derived_selection ) && null !== $derived_selection ? array() : $this->where_predicates();
			$order_by = array();
			if ( $this->is_word( 'ORDER' ) ) {
				if ( isset( $derived_selection ) && null !== $derived_selection ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $this->current()->sql_offset(), 'mdi-native does not support ORDER BY on a derived selection UPDATE.' );
				}
				$order_by = $this->write_order_by();
			}
			$limit = PHP_INT_MAX;
			if ( $this->is_word( 'LIMIT' ) ) {
				if ( isset( $derived_selection ) && null !== $derived_selection ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $this->current()->sql_offset(), 'mdi-native does not support LIMIT on a derived selection UPDATE.' );
				}
				$this->word( 'LIMIT' );
				$limit = (int) $this->type( WP_Markdown_Native_SQL_Token::INTEGER )->value();
			}
			$this->type( WP_Markdown_Native_SQL_Token::END );
			return new WP_Markdown_Native_Table_Write( $kind, $table, $values, $predicates, $derived_selection ?? null, $limit, $order_by );
		} catch ( WP_Markdown_Native_SQL_Parse_Error $error ) {
			return WP_Markdown_Query_Result::failure(
				array(
					'code'       => 'markdown_db_native_unsupported_query',
					'reason'     => $error->reason(),
					'message'    => 'mdi-native supports one bounded generic UPDATE or DELETE.',
					'sql_offset' => $error->sql_offset(),
				)
			);
		}
	}

	/** Parse UPDATE target alias JOIN (same-table SELECT pk ... FOR UPDATE) alias ON pk equality SET literals. */
	private function derived_selection( string $table ): WP_Markdown_Native_Table_Derived_Selection {
		$target_alias = $this->identifier();
		$this->word( 'JOIN' );
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$parser = new WP_Markdown_Native_Select_AST_Parser( $this->tokens, $this->position );
		$query = $parser->parse_nested();
		if ( ! $query instanceof WP_Markdown_Native_SQL_Select ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_derived_selection', $this->current()->sql_offset(), 'mdi-native requires a typed derived SELECT.' );
		}
		$this->position = $parser->position();
		if ( 2 > $this->position
			|| ! isset( $this->tokens[ $this->position - 2 ], $this->tokens[ $this->position - 1 ] )
			|| 0 !== strcasecmp( 'FOR', (string) $this->tokens[ $this->position - 2 ]->value() )
			|| 0 !== strcasecmp( 'UPDATE', (string) $this->tokens[ $this->position - 1 ]->value() )
		) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_derived_selection', $this->current()->sql_offset(), 'mdi-native requires the derived selection to lock rows with FOR UPDATE.' );
		}
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		$derived_alias = $this->identifier();
		if ( 0 === strcasecmp( $target_alias, $derived_alias ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_derived_selection', $this->current()->sql_offset(), 'mdi-native requires distinct target and derived aliases.' );
		}
		$this->word( 'ON' );
		list( $left_alias, $left_column ) = $this->qualified_identifier();
		$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
		list( $right_alias, $right_column ) = $this->qualified_identifier();
		if ( 0 !== strcasecmp( $target_alias, $left_alias ) || 0 !== strcasecmp( $derived_alias, $right_alias ) || 0 !== strcasecmp( $left_column, $right_column ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_derived_selection', $this->current()->sql_offset(), 'mdi-native requires target and derived aliases to join on the same primary key.' );
		}
		$this->word( 'SET' );
		return new WP_Markdown_Native_Table_Derived_Selection( $left_column, $query );
	}

	/** @return array{string,string} */
	private function qualified_identifier(): array {
		$alias = $this->identifier();
		$this->type( WP_Markdown_Native_SQL_Token::DOT );
		return array( $alias, $this->identifier() );
	}

	/** @return array<string,int|string|null> */
	private function literal_assignments(): array {
		$values = array();
		do {
			$column = $this->identifier();
			if ( array_key_exists( $column, $values ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'duplicate_mutation_column', $this->current()->sql_offset(), 'Repeated UPDATE targets are not supported.' );
			}
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$values[ $column ] = $this->literal();
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		return $values;
	}

	/** @return array<string,int|string|null|WP_Markdown_Native_Query_Scalar_Expression> */
	private function assignments( string $table ): array {
		$values = array();
		do {
			$column = $this->identifier();
			if ( array_key_exists( $column, $values ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'duplicate_mutation_column', $this->current()->sql_offset(), 'Repeated UPDATE targets are not supported.' );
			}
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$parser = new WP_Markdown_Native_Select_AST_Parser( $this->tokens, $this->position );
			$expression = $parser->scalar_value();
			$this->position = $parser->position();
			foreach ( $expression->columns() as $source ) {
				if ( null !== $source->qualifier() && 0 !== strcasecmp( $table, $source->qualifier() ) ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_mutation_column', $source->sql_offset(), 'An UPDATE expression must reference its target table.' );
				}
			}
			$values[ $column ] = 'literal' === $expression->kind()
				? ( null === $expression->literal() ? null : (string) $expression->literal() )
				: ( new WP_Markdown_Native_Query_Parser() )->lower_scalar_expression( $expression, null, $table );
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		return $values;
	}

	/**
	 * Parse a bounded WHERE clause into conjunctive per-column predicates.
	 *
	 * Disjunctions must stay within one column so the restriction keeps the
	 * engine's existing predicate semantics instead of a second evaluator.
	 *
	 * @return array<int,WP_Markdown_Native_Table_Predicate>
	 */
	/**
	 * Parse a bounded WHERE clause with SQL precedence: AND binds tighter than OR.
	 *
	 * @return array<int,WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Native_Table_Subquery_Predicate>
	 */
	private function where_predicates(): array {
		if ( WP_Markdown_Native_SQL_Token::END === $this->current()->type()
			|| 0 !== strcasecmp( 'WHERE', (string) $this->current()->value() ) ) {
			return array();
		}
		$this->word( 'WHERE' );

		$predicate = $this->where_disjunction();
		return $predicate instanceof WP_Markdown_Native_Table_Predicate_Group && $predicate->all()
			? $predicate->any()
			: array( $predicate );
	}

	/** @return WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Native_Table_Subquery_Predicate|null */
	private function where_disjunction() {
		$alternatives = array( $this->where_conjunction() );
		while ( $this->is_word( 'OR' ) ) {
			++$this->position;
			$alternatives[] = $this->where_conjunction();
		}
		$alternatives = array_values( array_filter( $alternatives ) );
		if ( array() === $alternatives ) {
			return null;
		}
		foreach ( $alternatives as $alternative ) {
			if ( 1 !== count( $alternatives ) && $this->has_subquery( $alternative ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_subquery_shape', $this->current()->sql_offset(), 'mdi-native supports IN subqueries only as conjunctive write restrictions.' );
			}
		}
		return 1 === count( $alternatives )
			? $alternatives[0]
			: new WP_Markdown_Native_Table_Predicate_Group( $alternatives );
	}

	/** @return WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Native_Table_Subquery_Predicate|null */
	private function where_conjunction() {
		$terms = array( $this->where_factor() );
		while ( $this->is_word( 'AND' ) ) {
			++$this->position;
			$terms[] = $this->where_factor();
		}
		return 1 === count( $terms ) ? $terms[0] : new WP_Markdown_Native_Table_Predicate_Group( $terms, true );
	}

	private function has_subquery( mixed $predicate ): bool {
		if ( $predicate instanceof WP_Markdown_Native_Table_Subquery_Predicate ) { return true; }
		if ( $predicate instanceof WP_Markdown_Native_Table_Predicate_Group ) {
			foreach ( $predicate->any() as $term ) {
				if ( $this->has_subquery( $term ) ) { return true; }
			}
		}
		return false;
	}

	/** @return WP_Markdown_Native_Table_Predicate|WP_Markdown_Native_Table_Predicate_Group|WP_Markdown_Native_Table_Subquery_Predicate|null */
	private function where_factor() {
		if ( WP_Markdown_Native_SQL_Token::LEFT_PAREN === $this->current()->type() ) {
			++$this->position;
			$group = $this->where_disjunction();
			$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
			return $group;
		}
		$column = $this->identifier();
		$token = $this->current();
		if ( 0 === strcasecmp( 'IS', (string) $token->value() ) ) {
			++$this->position;
			if ( 0 === strcasecmp( 'NOT', (string) $this->current()->value() ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_predicate', $token->sql_offset(), 'Unsupported IS NOT restriction.' );
			}
			$this->word( 'NULL' );
			return new WP_Markdown_Native_Table_Predicate( $column, array(), true );
		}
		$comparison = $this->comparison_operator();
		if ( null !== $comparison ) {
			$value = $this->literal();
			if ( null === $value ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_predicate', $token->sql_offset(), 'Comparisons with NULL never match.' );
			}
			return new WP_Markdown_Native_Table_Predicate( $column, array( $value ), false, $comparison );
		}
		if ( 0 === strcasecmp( 'IN', (string) $token->value() ) ) {
			++$this->position;
			if ( WP_Markdown_Native_SQL_Token::LEFT_PAREN === $this->current()->type()
				&& 0 === strcasecmp( 'SELECT', (string) $this->tokens[ $this->position + 1 ]->value() )
			) {
				++$this->position;
				$parser = new WP_Markdown_Native_Select_AST_Parser( $this->tokens, $this->position );
				$query = $parser->parse_nested();
				if ( ! $query instanceof WP_Markdown_Native_SQL_Select ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_subquery_shape', $token->sql_offset(), 'mdi-native IN restrictions require a SELECT row projection.' );
				}
				$this->position = $parser->position();
				$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
				return new WP_Markdown_Native_Table_Subquery_Predicate( $column, $query );
			}
			$values = array();
			foreach ( $this->literal_list() as $value ) {
				if ( null === $value ) {
					throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_predicate', $token->sql_offset(), 'Unsupported NULL IN member.' );
				}
				$values[] = $value;
			}
			return new WP_Markdown_Native_Table_Predicate( $column, $values, false );
		}
		if ( WP_Markdown_Native_SQL_Token::EQUALS !== $token->type() ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_predicate', $token->sql_offset(), 'Unsupported WHERE restriction.' );
		}
		++$this->position;
		$value = $this->literal();
		if ( null === $value ) {
			// `column = NULL` never matches in MySQL.
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_predicate', $token->sql_offset(), 'Unsupported NULL equality restriction.' );
		}
		return new WP_Markdown_Native_Table_Predicate( $column, array( $value ), false );
	}

	/**
	 * Parse a single-table write's `ORDER BY col [ASC|DESC][, …]`.
	 *
	 * @return array<int,array{column:string,descending:bool}>
	 */
	private function write_order_by(): array {
		$this->word( 'ORDER' );
		$this->word( 'BY' );
		$order_by = array();
		do {
			if ( array() !== $order_by ) {
				$this->type( WP_Markdown_Native_SQL_Token::COMMA );
			}
			$column = $this->identifier();
			$descending = false;
			if ( $this->is_word( 'DESC' ) ) {
				++$this->position;
				$descending = true;
			} elseif ( $this->is_word( 'ASC' ) ) {
				++$this->position;
			}
			$order_by[] = array(
				'column'     => $column,
				'descending' => $descending,
			);
		} while ( WP_Markdown_Native_SQL_Token::COMMA === $this->current()->type() );
		return $order_by;
	}

	/** @return '<>'|'<'|'<='|'>'|'>='|null */
	private function comparison_operator(): ?string {
		$type = $this->current()->type();
		if ( in_array( $type, array( WP_Markdown_Native_SQL_Token::NOT_EQUALS, WP_Markdown_Native_SQL_Token::LESS_THAN, WP_Markdown_Native_SQL_Token::LESS_EQUALS, WP_Markdown_Native_SQL_Token::GREATER_THAN, WP_Markdown_Native_SQL_Token::GREATER_EQUALS ), true ) ) {
			++$this->position;
			return match ( $type ) {
				WP_Markdown_Native_SQL_Token::NOT_EQUALS => '<>',
				WP_Markdown_Native_SQL_Token::LESS_THAN => '<',
				WP_Markdown_Native_SQL_Token::LESS_EQUALS => '<=',
				WP_Markdown_Native_SQL_Token::GREATER_THAN => '>',
				default => '>=',
			};
		}
		return null;
	}

	private function is_word( string $expected ): bool {
		return 0 === strcasecmp( $expected, (string) $this->current()->value() );
	}

	private function literal(): int|string|null {
		$token = $this->current();
		if ( WP_Markdown_Native_SQL_Token::STRING === $token->type() || WP_Markdown_Native_SQL_Token::INTEGER === $token->type() || WP_Markdown_Native_SQL_Token::DECIMAL === $token->type() ) {
			++$this->position;
			return (string) $token->value();
		}
		if ( 0 === strcasecmp( 'NULL', (string) $token->value() ) ) {
			++$this->position;
			return null;
		}
		throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_literal', $token->sql_offset(), 'Unsupported literal.' );
	}

	/** @return array<int,string> */
	private function identifier_list(): array {
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$columns = array();
		do {
			$column = $this->identifier();
			if ( isset( $columns[ $column ] ) ) {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'duplicate_mutation_column', $this->current()->sql_offset(), 'Duplicate INSERT column.' );
			}
			$columns[ $column ] = $column;
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		return array_values( $columns );
	}

	/** @return array<int,array{target:string,kind:string,source:?string,value:int|string|null|WP_Markdown_Native_Query_Scalar_Expression}> */
	private function upsert_assignments( string $table ): array {
		$this->word( 'ON' );
		$this->word( 'DUPLICATE' );
		$this->word( 'KEY' );
		$this->word( 'UPDATE' );
		$assignments = array();
		do {
			$target = $this->identifier();
			$this->type( WP_Markdown_Native_SQL_Token::EQUALS );
			$source = null;
			$value = null;
			if ( $this->is_word( 'VALUES' ) ) {
				$this->word( 'VALUES' );
				$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
				$source = $this->identifier();
				$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
				$kind = 'inserted';
			} else {
				$parser = new WP_Markdown_Native_Select_AST_Parser( $this->tokens, $this->position );
				$expression = $parser->scalar_value();
				$this->position = $parser->position();
				foreach ( $expression->columns() as $column ) {
					if ( null !== $column->qualifier() && 0 !== strcasecmp( $table, $column->qualifier() ) ) {
						throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_mutation_column', $column->sql_offset(), 'A duplicate-key expression must reference its target table.' );
					}
				}
				$value = 'literal' === $expression->kind()
					? $expression->literal()
					: ( new WP_Markdown_Native_Query_Parser() )->lower_scalar_expression( $expression, null, $table );
				$kind = $value instanceof WP_Markdown_Native_Query_Scalar_Expression ? 'expression' : 'literal';
			}
			$assignments[] = array( 'target' => $target, 'kind' => $kind, 'source' => $source, 'value' => $value );
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		return $assignments;
	}

	/** @return array<int,int|string|null> */
	private function select_literals(): array {
		$values = array();
		do {
			$values[] = $this->literal();
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		return $values;
	}

	/** @return array<int,WP_Markdown_Native_Table_Predicate>|null */
	private function dual_absent_predicates( string $table ): ?array {
		$this->word( 'WHERE' );
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$this->word( 'SELECT' );
		if ( 0 === strcasecmp( 'NULL', (string) $this->current()->value() ) ) {
			$this->word( 'NULL' );
			$this->word( 'FROM' );
			$this->word( 'DUAL' );
			$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
			$this->word( 'IS' );
			$this->word( 'NULL' );
			return null;
		}
		$this->identifier();
		$this->word( 'FROM' );
		$from = $this->identifier();
		if ( 0 !== strcasecmp( $from, $table ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $this->current()->sql_offset(), 'INSERT SELECT FROM DUAL can only absent-check the target table.' );
		}
		$predicates = $this->where_predicates();
		if ( 0 === strcasecmp( 'LIMIT', (string) $this->current()->value() ) ) {
			$this->word( 'LIMIT' );
			$this->type( WP_Markdown_Native_SQL_Token::INTEGER );
		}
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		$this->word( 'IS' );
		$this->word( 'NULL' );
		return $predicates;
	}

	/** @return array<int,int|string|null> */
	private function literal_list(): array {
		$this->type( WP_Markdown_Native_SQL_Token::LEFT_PAREN );
		$values = array();
		do {
			$token = $this->current();
			if ( WP_Markdown_Native_SQL_Token::STRING === $token->type() ) {
				$values[] = (string) $token->value();
				++$this->position;
			} elseif ( WP_Markdown_Native_SQL_Token::INTEGER === $token->type() || WP_Markdown_Native_SQL_Token::DECIMAL === $token->type() ) {
				$values[] = (string) $token->value();
				++$this->position;
			} elseif ( 0 === strcasecmp( 'NULL', (string) $token->value() ) ) {
				$values[] = null;
				++$this->position;
			} else {
				throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_literal', $token->sql_offset(), 'Unsupported INSERT literal.' );
			}
			if ( WP_Markdown_Native_SQL_Token::COMMA !== $this->current()->type() ) {
				break;
			}
			++$this->position;
		} while ( true );
		$this->type( WP_Markdown_Native_SQL_Token::RIGHT_PAREN );
		return $values;
	}

	private function identifier(): string {
		$token = $this->current();
		if ( ! in_array( $token->type(), array( WP_Markdown_Native_SQL_Token::WORD, WP_Markdown_Native_SQL_Token::KEYWORD, WP_Markdown_Native_SQL_Token::QUOTED_IDENTIFIER ), true ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Expected an identifier.' );
		}
		++$this->position;
		return (string) $token->value();
	}

	private function word( string $expected ): void {
		$token = $this->current();
		if ( 0 !== strcasecmp( $expected, (string) $token->value() ) ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Unexpected SQL token.' );
		}
		++$this->position;
	}

	private function type( string $expected ): WP_Markdown_Native_SQL_Token {
		$token = $this->current();
		if ( $expected !== $token->type() ) {
			throw new WP_Markdown_Native_SQL_Parse_Error( 'unsupported_grammar', $token->sql_offset(), 'Unexpected SQL token.' );
		}
		++$this->position;
		return $token;
	}

	private function current(): WP_Markdown_Native_SQL_Token {
		return $this->tokens[ $this->position ];
	}

	private function failure( string $reason, string $message ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::failure(
			array(
				'code'    => 'markdown_db_native_unsupported_query',
				'reason'  => $reason,
				'message' => $message,
			)
		);
	}
}
