<?php
/** DDL schema compiler, generated core catalog, and native descriptor builder. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_Markdown_Native_Schema_Catalog {
	private const SCHEMA = 'mdi-native-core-schema/v1';

	/**
	 * @param array<int,string> $prefixes
	 * @param array<int,string> $exact_tables Table identities already validated by the caller.
	 * @return array<string,array<string,mixed>>
	 */
	public static function compile( string $ddl, array $prefixes, array $exact_tables = array() ): array {
		$prefixes = array_values( array_unique( array_filter( $prefixes, 'is_string' ) ) );
		$exact_tables = array_values( array_unique( array_filter( $exact_tables, 'is_string' ) ) );
		usort( $prefixes, static fn( string $left, string $right ): int => strlen( $right ) <=> strlen( $left ) );
		$tables = array();
		foreach ( explode( ';', $ddl ) as $statement ) {
			if ( preg_match( '/CREATE\s+(?:TEMPORARY\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(`?[A-Za-z0-9_]+`?)\s*\((.*)\)\s*.*$/is', trim( $statement ), $table ) ) {
				$tables[] = $table;
			}
		}
		if ( array() === $tables ) {
			throw new InvalidArgumentException( 'Schema DDL contains no CREATE TABLE statements.' );
		}

		$catalog = array();
		foreach ( $tables as $table ) {
			$name = trim( $table[1], '`' );
			$qualified = false;
			foreach ( $prefixes as $prefix ) {
				if ( '' !== $prefix && str_starts_with( $name, $prefix ) ) {
					$name = substr( $name, strlen( $prefix ) );
					$qualified = true;
					break;
				}
			}
			if ( ! $qualified && in_array( $name, $exact_tables, true ) ) {
				$qualified = true;
			}
			if ( ! $qualified || '' === $name || isset( $catalog[ $name ] ) ) {
				throw new InvalidArgumentException( 'Schema DDL contains a duplicate or unqualified table.' );
			}

			$columns = array();
			$indexes = array();
			foreach ( self::split_definitions( $table[2] ) as $line ) {
				$line = rtrim( trim( $line ), ',' );
				if ( '' === $line ) {
					continue;
				}
				if ( preg_match( '/^(PRIMARY\s+KEY|UNIQUE\s+KEY|UNIQUE\s+INDEX|KEY|INDEX)\s*(?:`?([A-Za-z0-9_]+)`?)?\s*\((.+)\)$/i', $line, $index ) ) {
					$index_columns = array();
					foreach ( explode( ',', $index[3] ) as $column ) {
						if ( ! preg_match( '/^\s*`?([A-Za-z0-9_]+)`?(?:\(([0-9]+)\))?\s*$/', $column, $part ) ) {
							throw new InvalidArgumentException( 'Schema DDL contains an unsupported index expression.' );
						}
						$index_columns[] = array(
							'name'   => $part[1],
							'length' => isset( $part[2] ) ? (int) $part[2] : null,
						);
					}
					$kind = strtoupper( preg_replace( '/\s+/', ' ', $index[1] ) );
					$primary = 'PRIMARY KEY' === $kind;
					$indexes[] = array(
						'name'    => $primary ? 'PRIMARY' : $index[2],
						'unique'  => $primary || str_starts_with( $kind, 'UNIQUE ' ),
						'columns' => $index_columns,
					);
					continue;
				}
				if ( ! preg_match( '/^`?([A-Za-z0-9_]+)`?\s+([A-Za-z]+)(?:\(([^)]*)\))?\s*(unsigned\b)?(.*)$/i', $line, $column ) ) {
					throw new InvalidArgumentException( 'Schema DDL contains an unsupported column definition.' );
				}
				$length = null;
				if ( '' !== ( $column[3] ?? '' ) ) {
					$length = ctype_digit( $column[3] ) ? (int) $column[3] : $column[3];
				}
				$tail = $column[5] ?? '';
				$default = null;
				if ( preg_match( '/\bdefault\s+(\'(?:[^\']|\'\')*\'|[^\s,]+)/i', $tail, $matched_default ) ) {
					$literal = $matched_default[1];
					if ( 0 !== strcasecmp( $literal, 'NULL' ) ) {
						$default = str_starts_with( $literal, "'" )
							? str_replace( "''", "'", substr( $literal, 1, -1 ) )
							: $literal;
					}
				}
				$columns[ $column[1] ] = array(
					'type'           => strtolower( $column[2] ),
					'length'         => $length,
					'unsigned'       => '' !== ( $column[4] ?? '' ),
					'nullable'       => 1 !== preg_match( '/\bNOT\s+NULL\b/i', $tail ),
					'default'        => $default,
					'auto_increment' => 1 === preg_match( '/\bauto_increment\b/i', $tail ),
				);
				if ( 1 === preg_match( '/\bPRIMARY\s+KEY\b/i', $tail ) ) {
					$indexes[] = array(
						'name'    => 'PRIMARY',
						'unique'  => true,
						'columns' => array( array( 'name' => $column[1], 'length' => null ) ),
					);
				}
			}
			if ( array() === $columns ) {
				throw new InvalidArgumentException( 'Schema DDL table contains no columns.' );
			}
			$catalog[ $name ] = array( 'columns' => $columns, 'indexes' => $indexes );
		}
		return $catalog;
	}

	/** @return array<int,string> */
	private static function split_definitions( string $body ): array {
		$definitions = array();
		$current = '';
		$depth = 0;
		$quote = null;
		$length = strlen( $body );
		for ( $offset = 0; $offset < $length; ++$offset ) {
			$character = $body[ $offset ];
			if ( null !== $quote ) {
				$current .= $character;
				if ( $character === $quote ) {
					if ( "'" === $quote && $offset + 1 < $length && "'" === $body[ $offset + 1 ] ) {
						$current .= $body[ ++$offset ];
					} else {
						$quote = null;
					}
				}
				continue;
			}
			if ( in_array( $character, array( "'", '"', '`' ), true ) ) {
				$quote = $character;
				$current .= $character;
				continue;
			}
			if ( '(' === $character ) {
				++$depth;
			} elseif ( ')' === $character ) {
				--$depth;
			} elseif ( ',' === $character && 0 === $depth ) {
				$definitions[] = trim( $current );
				$current = '';
				continue;
			}
			$current .= $character;
		}
		if ( '' !== trim( $current ) ) {
			$definitions[] = trim( $current );
		}
		return $definitions;
	}

	/** @return array{schema:string,wordpress_version:string,single_site:array<string,mixed>,multisite:array<string,mixed>,hashes:array<string,string>} */
	public static function artifact(): array {
		static $artifact = null;
		if ( null !== $artifact ) {
			return $artifact;
		}
		$artifact = require __DIR__ . '/generated/wp-core-schema-catalog.php';
		if ( ! is_array( $artifact ) || self::SCHEMA !== ( $artifact['schema'] ?? null ) ) {
			throw new RuntimeException( 'The generated WordPress core schema catalog is invalid.' );
		}
		return $artifact;
	}

	/**
	 * The server identity the engine reports to WordPress.
	 *
	 * The numeric part states which MySQL semantics the engine implements,
	 * which is what WordPress reads the version for: utf8mb4 storage and
	 * modern collation behaviour are what canonical files actually provide.
	 * The suffix keeps the engine identifiable as itself.
	 */
	public const SERVER_VERSION = '8.0.0-mdi-native';

	/**
	 * Report whether a table name belongs to WordPress core.
	 *
	 * A core table is identified by name because its definition varies
	 * between WordPress releases while the canonical form it maps to does
	 * not. Matching on the definition would let a core table created by a
	 * different release be mistaken for a plugin's own table.
	 */
	public static function is_core_table( string $suffix ): bool {
		return isset( self::definitions()[ $suffix ] ) || isset( self::definitions( true )[ $suffix ] );
	}

	/**
	 * Report whether a compiled definition is one WordPress core generates.
	 *
	 * @param array<string,mixed> $definition
	 */
	public static function is_generated_core_definition( string $suffix, array $definition ): bool {
		foreach ( array( false, true ) as $multisite ) {
			$definitions = self::definitions( $multisite );
			if ( isset( $definitions[ $suffix ] ) && $definitions[ $suffix ] === $definition ) {
				return true;
			}
		}
		return false;
	}

	/** @return array<string,array<string,mixed>> */
	public static function definitions( bool $multisite = false ): array {
		$artifact = self::artifact();
		return $multisite ? $artifact['multisite'] : $artifact['single_site'];
	}

	/** @param array<int,string> $prefixes */
	public static function assert_current( string $ddl, array $prefixes, bool $multisite ): void {
		$compiled = self::compile( $ddl, $prefixes );
		$artifact = self::artifact();
		$scope    = $multisite ? 'multisite' : 'single_site';
		if ( ! hash_equals( $artifact['hashes'][ $scope ], self::hash( $compiled ) ) ) {
			throw new RuntimeException( 'The generated native schema catalog does not match this WordPress core.' );
		}
	}

	/** @param array<string,mixed> $definitions */
	public static function hash( array $definitions ): string {
		return hash( 'sha256', json_encode( $definitions, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR ) );
	}

	/**
	 * @param 'integer'|'string'|'mixed' $numeric_storage
	 * @param array{columns?:array<string,array<string,mixed>>,natural_order?:string,order_columns?:array<int,string>} $overlay
	 */
	public static function table_schema(
		string $table,
		string $numeric_storage,
		array $overlay = array(),
		bool $multisite = false
	): WP_Markdown_Native_Table_Schema {
		$definitions = self::definitions( $multisite );
		if ( ! isset( $definitions[ $table ] ) ) {
			throw new InvalidArgumentException( 'A generated core table and numeric storage representation are required.' );
		}
		return self::schema( $definitions[ $table ], $numeric_storage, $overlay );
	}

	/**
	 * @param array<string,mixed> $definition
	 * @param 'integer'|'string'|'mixed' $numeric_storage
	 * @param array{columns?:array<string,array<string,mixed>>,natural_order?:string,order_columns?:array<int,string>} $overlay
	 */
	public static function schema(
		array $definition,
		string $numeric_storage,
		array $overlay = array()
	): WP_Markdown_Native_Table_Schema {
		if ( ! isset( $definition['columns'], $definition['indexes'] )
			|| ! is_array( $definition['columns'] )
			|| ! is_array( $definition['indexes'] )
			|| ! in_array( $numeric_storage, array( 'integer', 'string', 'mixed' ), true )
		) {
			throw new InvalidArgumentException( 'A compiled table definition and numeric storage representation are required.' );
		}
		$columns = array();
		foreach ( $definition['columns'] as $name => $column_definition ) {
			$column_overlay = $overlay['columns'][ $name ] ?? array();
			$normalizer = $column_overlay['normalizer'] ?? self::normalizer( $column_definition );
			$columns[ $name ] = new WP_Markdown_Native_Column(
				self::field_type( $column_definition['type'] ),
				(bool) $column_definition['nullable'],
				$column_overlay['validator'] ?? self::validator( $column_definition, $numeric_storage ),
				$normalizer,
				$column_overlay['lookup_operators'] ?? array(),
				$column_overlay['lookup_validator'] ?? null,
				$column_overlay['filter_operators'] ?? self::default_filter_operators( $column_definition['type'] ),
				$column_overlay['filter_validator'] ?? null
			);
		}
		$primary = array_values( array_filter( $definition['indexes'], static fn( array $index ): bool => 'PRIMARY' === $index['name'] ) );
		$natural_order = $overlay['natural_order'] ?? ( $primary[0]['columns'][0]['name'] ?? array_key_first( $columns ) );
		$identity_columns = array_map( static fn( array $column ): string => $column['name'], $primary[0]['columns'] ?? array() );
		return new WP_Markdown_Native_Table_Schema( $columns, $natural_order, $overlay['order_columns'] ?? array(), $identity_columns, $definition );
	}

	/** Build the conservative execution contract supported by a generic JSON snapshot. */
	public static function indexed_snapshot_schema(
		array $definition,
		array $column_overlays = array(),
		array $order_columns = array()
	): ?WP_Markdown_Native_Table_Schema {
		$primary = array_values( array_filter( $definition['indexes'] ?? array(), static fn( array $index ): bool => 'PRIMARY' === ( $index['name'] ?? null ) ) );
		$identity_columns = $primary[0]['columns'] ?? array();
		if ( 1 !== count( $primary ) || array() === $identity_columns ) {
			return null;
		}
		$identity = $identity_columns[0]['name'] ?? '';
		foreach ( $identity_columns as $identity_column ) {
			$name = $identity_column['name'] ?? '';
			if ( ! isset( $definition['columns'][ $name ] ) ) {
				return null;
			}
			$identity_type = $definition['columns'][ $name ]['type'];
			// A primary key is an identity. Integers are exact, and a declared
			// prefix-free string key is exact ASCII, which is the same identity
			// rule unique string keys already use.
			if ( ! self::is_integer( $identity_type )
				&& ( ! in_array( $identity_type, array( 'char', 'varchar' ), true ) || null !== ( $identity_column['length'] ?? null ) ) ) {
				return null;
			}
		}

		// Numeric and temporal SQL types have an unambiguous native order even
		// without an index. Textual ordering still requires the conservative
		// indexed/ASCII path below because its collation is not generic.
		foreach ( $definition['columns'] as $name => $column ) {
			if ( ( self::is_integer( $column['type'] ) || self::is_decimal( $column['type'] ) || in_array( $column['type'], array( 'date', 'datetime', 'timestamp', 'time', 'year' ), true ) )
				&& ! in_array( $name, $order_columns, true )
			) {
				$order_columns[] = $name;
			}
		}
		// Indexed textual columns remain orderable only when their values are
		// ASCII, which is checked by the schema at read time.
		foreach ( $definition['indexes'] as $index ) {
			foreach ( $index['columns'] as $index_column ) {
				$name = $index_column['name'] ?? '';
				if ( '' !== $name && isset( $definition['columns'][ $name ] ) && ! in_array( $name, $order_columns, true ) ) {
					$order_columns[] = $name;
				}
			}
		}
		$overlay = array( 'columns' => array(), 'natural_order' => $identity, 'order_columns' => $order_columns );
		$ascii = static fn( array $values ): bool => array() === array_filter(
			$values,
			static fn( mixed $value ): bool => ! is_string( $value ) || 1 === preg_match( '/[^\x00-\x7F]/', $value )
		);
		// A range comparison is the ordering question ORDER BY already answers,
		// so it is offered wherever this schema can order a column. The schema
		// still refuses a range whose literal has no place in that order.
		$ranges = array( '<', '<=', '>', '>=', 'BETWEEN' );
		foreach ( $definition['columns'] as $name => $column ) {
			if ( self::is_integer( $column['type'] ) || self::is_decimal( $column['type'] ) ) {
				$overlay['columns'][ $name ] = array( 'filter_operators' => array_merge( array( '=', 'IN', 'NOT IN', '<>' ), $ranges ) );
			} elseif ( in_array( $column['type'], array( 'char', 'varchar', 'enum', 'set', 'tinytext', 'text', 'mediumtext', 'longtext' ), true ) ) {
				// Text ordering needs a collation this engine does not
				// implement, so text carries equality and LIKE only.
				$overlay['columns'][ $name ] = array(
					'filter_operators' => array( '=', 'IN', 'NOT IN', '<>', 'LIKE', 'NOT LIKE', 'REGEXP' ),
					'filter_validator' => $ascii,
				);
			} elseif ( in_array( $column['type'], array( 'date', 'datetime', 'timestamp', 'time', 'year' ), true ) ) {
				// WordPress compares dates as canonical strings, which order
				// exactly as the stored 'Y-m-d H:i:s' form does.
				$overlay['columns'][ $name ] = array(
					'filter_operators' => array_merge( array( '=', 'IN', 'NOT IN', '<>' ), $ranges ),
					'filter_validator' => $ascii,
				);
			} else {
				$overlay['columns'][ $name ] = array( 'filter_operators' => array() );
			}
		}
		foreach ( $definition['indexes'] as $index ) {
			$unique = true === ( $index['unique'] ?? false );
			foreach ( $index['columns'] as $index_column ) {
				$name = $index_column['name'] ?? '';
				if ( ! isset( $definition['columns'][ $name ] ) ) {
					continue;
				}
				$type = $definition['columns'][ $name ]['type'];
				if ( self::is_integer( $type ) ) {
					$overlay['columns'][ $name ]['lookup_operators'] = array( '=', 'IN' );
					continue;
				}
				if ( in_array( $type, array( 'char', 'varchar', 'enum', 'set' ), true ) ) {
					if ( $unique ) {
						$overlay['columns'][ $name ]['lookup_operators']  = array( '=', 'IN' );
						$overlay['columns'][ $name ]['lookup_validator'] = $ascii;
					}
				}
			}
		}
		foreach ( $column_overlays as $name => $column_overlay ) {
			if ( isset( $overlay['columns'][ $name ] ) && is_array( $column_overlay ) ) {
				$overlay['columns'][ $name ] = array_merge( $overlay['columns'][ $name ], $column_overlay );
			}
		}
		return self::schema( $definition, 'mixed', $overlay );
	}

	/** @param array<string,mixed> $definition */
	private static function validator( array $definition, string $numeric_storage ): callable {
		if ( self::is_integer( $definition['type'] ) ) {
			if ( 'integer' === $numeric_storage ) {
				return $definition['unsigned']
					? static fn( mixed $value ): bool => is_int( $value ) && $value >= 0
					: 'is_int';
			}
			if ( 'mixed' === $numeric_storage ) {
				return $definition['unsigned']
					? static fn( mixed $value ): bool => ( is_int( $value ) && $value >= 0 ) || ( is_string( $value ) && 1 === preg_match( '/^(?:0|[1-9][0-9]*)$/D', $value ) )
					: static fn( mixed $value ): bool => is_int( $value ) || ( is_string( $value ) && 1 === preg_match( '/^-?(?:0|[1-9][0-9]*)$/D', $value ) );
			}
			return $definition['unsigned']
				? static fn( mixed $value ): bool => is_string( $value ) && 1 === preg_match( '/^(?:0|[1-9][0-9]*)$/D', $value )
				: static fn( mixed $value ): bool => is_string( $value ) && 1 === preg_match( '/^-?(?:0|[1-9][0-9]*)$/D', $value );
		}
		$maximum = match ( $definition['type'] ) {
			'char', 'varchar' => is_int( $definition['length'] ) ? $definition['length'] : null,
			'tinytext', 'tinyblob' => 255,
			'date' => 10,
			'time' => 10,
			'datetime', 'timestamp' => 19,
			'year' => 4,
			default => null,
		};
		return null === $maximum
			? 'is_string'
			: static fn( mixed $value ): bool => is_string( $value ) && strlen( $value ) <= $maximum;
	}

	/** @param array<string,mixed> $definition */
	private static function normalizer( array $definition ): mixed {
		if ( ! self::is_integer( $definition['type'] ) ) {
			return null;
		}
		return $definition['unsigned']
			? array( WP_Markdown_Native_Runtime_Factory::class, 'normalize_unsigned' )
			: array( WP_Markdown_Native_Runtime_Factory::class, 'normalize_signed' );
	}

	public static function is_integer( string $type ): bool {
		return in_array( $type, array( 'tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint' ), true );
	}

	public static function is_decimal( string $type ): bool {
		return in_array( $type, array( 'float', 'double', 'real', 'decimal', 'numeric' ), true );
	}

	/**
	 * Filters a column type answers when a caller declares none.
	 *
	 * Numeric and temporal columns carry one unambiguous order, so they also
	 * answer range comparisons. Text answers equality and pattern matching,
	 * because ordering it needs a collation this engine does not implement.
	 *
	 * @return array<int,string>
	 */
	private static function default_filter_operators( string $type ): array {
		$equality = array( '=', 'IN', 'NOT IN', '<>' );
		$ranges   = array( '<', '<=', '>', '>=', 'BETWEEN' );
		if ( self::is_integer( $type ) || self::is_decimal( $type ) ) {
			return array_merge( $equality, $ranges );
		}
		if ( in_array( $type, array( 'date', 'datetime', 'timestamp', 'time', 'year' ), true ) ) {
			return array_merge( $equality, $ranges );
		}
		return array_merge( $equality, array( 'LIKE', 'NOT LIKE', 'REGEXP' ) );
	}

	private static function field_type( string $type ): int {
		return match ( $type ) {
			'tinyint' => 1,
			'smallint' => 2,
			'int', 'integer' => 3,
			'float' => 4,
			'double', 'real' => 5,
			'timestamp' => 7,
			'bigint' => 8,
			'mediumint' => 9,
			'date' => 10,
			'time' => 11,
			'datetime' => 12,
			'year' => 13,
			'decimal', 'numeric' => 246,
			'tinyblob', 'mediumblob', 'longblob', 'blob', 'tinytext', 'mediumtext', 'longtext', 'text' => 252,
			'varchar', 'varbinary' => 253,
			// MySQL reports ENUM and SET over the wire as string field types.
			'char', 'binary', 'enum', 'set' => 254,
			default => throw new InvalidArgumentException( 'Schema DDL contains an unsupported SQL field type.' ),
		};
	}
}
