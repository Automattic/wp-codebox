<?php
/** wpdb query-helper facade for the bounded mdi-native runtime. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-native-query-runtime.php';

if ( ! class_exists( 'wpdb' ) ) {
	return;
}

if ( ! function_exists( 'is_multisite' ) ) {
	/**
	 * WP-CLI's `wp db query`/`db import`/`db export`/etc. fast path
	 * (DB_Command_SQLite::maybe_load_sqlite_dropin()) loads wp-includes/class-wpdb.php
	 * and this drop-in directly, after only wp-config.php, without wp-includes/load.php.
	 * The parent wpdb::set_prefix() call below (and other inherited wpdb methods) call
	 * the core is_multisite() unconditionally, so without this shim the constructor
	 * fatals with "Call to undefined function is_multisite()".
	 *
	 * This is a pure capability shim, not a multisite policy decision: it mirrors
	 * WordPress core's own wp-includes/load.php implementation exactly, byte for byte.
	 * A fully bootstrapped WordPress request (including WP-CLI commands that load all of
	 * WordPress) always requires wp-includes/load.php long before this file can be
	 * reached, because require_wp_db() -- which loads wp-content/db.php -- runs after
	 * load.php in wp-settings.php. The function_exists() guard means this definition is
	 * skipped there, so the real core is_multisite() is always used and multisite
	 * behavior is unchanged whenever it is available.
	 *
	 * @return bool Whether Multisite support is enabled.
	 */
	function is_multisite() {
		if ( defined( 'MULTISITE' ) ) {
			return MULTISITE;
		}

		if ( defined( 'SUBDOMAIN_INSTALL' ) || defined( 'VHOST' ) || defined( 'SUNRISE' ) ) {
			return true;
		}

		return false;
	}
}

final class WP_Markdown_Native_WPDB extends wpdb {

	public int|string $last_errno = 0;

	/** @var array{code:string,message:string,reason:string}|null */
	public ?array $last_runtime_diagnostic = null;

	private WP_Markdown_Query_Runtime $native_runtime;
	private string $native_table_prefix;
	private string $native_database_name;

	public function __construct( WP_Markdown_Query_Runtime $runtime, string $table_prefix = 'wp_' ) {
		if ( 1 !== preg_match( '/^[A-Za-z0-9_]+$/D', $table_prefix ) ) {
			throw new InvalidArgumentException( 'The table prefix contains unsupported characters.' );
		}
		$this->native_runtime = $runtime;
		$this->native_table_prefix = $table_prefix;
		$this->native_database_name = defined( 'DB_NAME' ) ? (string) DB_NAME : '';
		// Native executes the MySQL-compatible dialect in-process; this is not a
		// claim that wpdb has established a mysqli connection.
		$this->is_mysql = true;
		$this->set_prefix( $table_prefix );
		// db.php replaces wpdb after its normal constructor would establish the
		// primary site. Multisite switch_to_blog() requires that initial scope.
		if ( property_exists( $this, 'blogid' ) ) {
			$this->blogid = 1;
		}
		if ( property_exists( $this, 'siteid' ) ) {
			$this->siteid = 1;
		}
		$this->last_result = array();
		$this->ready       = true;
		$this->check_current_query = false;
	}

	/**
	 * Select the configured canonical store without requiring wpdb's mysqli handle.
	 *
	 * The native backend has one store selected during drop-in bootstrap. Database
	 * names are a WordPress lifecycle concept here; they must not redirect queries
	 * to another filesystem root.
	 */
	public function select( $db, $dbh = null ) {
		if ( ! is_string( $db ) || '' === $db ) {
			$this->ready      = false;
			$this->last_errno = 1049;
			$this->last_error = 'Unknown database';
			return false;
		}

		$this->native_database_name = $db;
		$this->ready                = true;
		$this->last_errno           = 0;
		$this->last_error           = '';
		return;
	}

	/** The native runtime is available without a MySQL connection. */
	public function db_connect( $allow_bail = true ) {
		$this->ready      = true;
		$this->last_errno = 0;
		$this->last_error = '';
		return true;
	}

	/** Do not invoke wpdb's mysqli reconnect loop for the in-process runtime. */
	public function check_connection( $allow_bail = true ) {
		return $this->ready || $this->db_connect( $allow_bail );
	}

	/**
	 * Report whether every requested exact table shares native's journaled
	 * canonical transaction boundary. Unsupported runtimes and unsafe roots fail
	 * closed; this does not claim InnoDB, MVCC, or a mysqli connection.
	 *
	 * @param string[] $tables
	 */
	public function supports_transactional_tables( array $tables ): bool {
		if ( ! $this->native_runtime instanceof WP_Markdown_Native_Transactional_Table_Support ) {
			return false;
		}
		try {
			return true === $this->native_runtime->supports_transactional_tables( $tables );
		} catch ( Throwable ) {
			return false;
		}
	}

	/** Close the logical native connection while leaving its configured root intact. */
	public function close() {
		if ( ! $this->ready ) {
			return false;
		}

		if ( method_exists( $this->native_runtime, 'close' ) ) {
			$this->native_runtime->close();
		}
		$this->ready = false;
		return true;
	}

	/** Execute one bounded native query and expose the normal wpdb result state. */
	public function query( $query ) {
		if ( ! is_string( $query ) || '' === trim( $query ) ) {
			return false;
		}

		if ( function_exists( 'apply_filters' ) ) {
			$query = apply_filters( 'query', $query );
		}
		if ( ! is_string( $query ) || '' === trim( $query ) ) {
			$this->insert_id = 0;
			return false;
		}
		$query = $this->remove_placeholder_escape( $query );
		$this->flush();
		$this->func_call  = "\$db->query(\"$query\")";
		$this->last_query = $query;
		$query_start      = microtime( true );
		// wp-settings can temporarily clear $wpdb->prefix before multisite has
		// selected its current blog. Continue serving that bootstrap query from
		// the base canonical scope.
		$result = $this->native_runtime->execute( new WP_Markdown_Query_Request( $query, '' === $this->prefix ? $this->native_table_prefix : $this->prefix ) );
		$state  = $result->wpdb_state();
		++$this->num_queries;

		$this->last_result            = $state['last_result'];
		$this->col_info               = $state['col_info'];
		$this->last_error             = $state['last_error'];
		$this->last_errno             = $state['last_errno'];
		$this->insert_id              = WP_Markdown_Native_WPDB_State_Projection::insert_id( $result, $query, (int) $this->insert_id );
		$this->rows_affected          = $state['rows_affected'];
		$this->num_rows               = $state['num_rows'];
		$this->last_runtime_diagnostic = $result->diagnostic();
		$this->result                 = $result->succeeded();
		if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES && method_exists( $this, 'log_query' ) ) {
			$this->log_query( $query, microtime( true ) - $query_start, method_exists( $this, 'get_caller' ) ? $this->get_caller() : '', $query_start, array() );
		}

		return $result->return_value();
	}

	/** Escape prepared string values without requiring a database connection. */
	public function _real_escape( $data ) {
		if ( ! is_scalar( $data ) ) {
			return '';
		}
		return $this->add_placeholder_escape( addslashes( (string) $data ) );
	}

	/** Identify the native engine without dereferencing wpdb's absent mysqli handle. */
	public function db_server_info() {
		return WP_Markdown_Native_Schema_Catalog::SERVER_VERSION;
	}

	/** Report the MySQL semantics the engine implements, from that same identity. */
	public function db_version() {
		return (string) preg_replace( '/[^0-9.].*/', '', WP_Markdown_Native_Schema_Catalog::SERVER_VERSION );
	}
}
