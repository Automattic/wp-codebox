<?php
/** Derived per-table index that keeps generic snapshot inserts constant time. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../class-wp-markdown-file-witness.php';

/**
 * A rebuildable index over one persisted snapshot table.
 *
 * The index holds nothing that cannot be recomputed from the snapshot it
 * describes. A missing, stale, or unreadable index is not an error: callers
 * fall back to reading the snapshot, which is the behaviour that existed
 * before the index, and then republish it.
 */
final class WP_Markdown_Native_Table_Index {

	public const SCHEMA = 'mdi-native-table-index/v2';
	private const DIRECTORY = '.index';

	/** @var array<string,array{path:string,witness:WP_Markdown_File_Witness,index:array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int}}> */
	private array $cached = array();

	public function __construct( private string $tables_directory ) {}

	public function path( string $suffix ): string {
		return $this->tables_directory . DIRECTORY_SEPARATOR . self::DIRECTORY . DIRECTORY_SEPARATOR . $suffix . '.json';
	}

	/**
	 * Load an index that still describes the current snapshot.
	 *
	 * @return array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int}|null
	 */
	public function load( string $suffix, string $snapshot_path ): ?array {
		$witness = WP_Markdown_File_Witness::take( $snapshot_path );
		$cached = $this->cached[ $suffix ] ?? null;
		if ( null !== $witness && is_array( $cached ) && $snapshot_path === $cached['path'] && $cached['witness']->is( $witness ) ) {
			return $cached['index'];
		}
		$path = $this->path( $suffix );
		if ( ! is_file( $path ) || is_link( $path ) ) {
			return null;
		}
		$decoded = json_decode( (string) @file_get_contents( $path ), true );
		if ( ! is_array( $decoded ) || self::SCHEMA !== ( $decoded['schema'] ?? null ) ) {
			return null;
		}
		if ( null === $witness || ! $this->describes( $decoded, $witness ) ) {
			return null;
		}
		$index = array(
			'max'       => array(),
			'unique'    => array(),
			'summary'   => array(),
			'row_count' => (int) ( $decoded['row_count'] ?? 0 ),
		);
		foreach ( (array) ( $decoded['max'] ?? array() ) as $column => $value ) {
			$index['max'][ (string) $column ] = (int) $value;
		}
		foreach ( (array) ( $decoded['unique'] ?? array() ) as $name => $keys ) {
			$index['unique'][ (string) $name ] = array_map( 'strval', is_array( $keys ) ? $keys : array() );
		}
		foreach ( (array) ( $decoded['summary'] ?? array() ) as $column => $counts ) {
			if ( ! is_array( $counts ) ) {
				return null;
			}
			$index['summary'][ (string) $column ] = array(
				'null'  => (int) ( $counts['null'] ?? 0 ),
				'empty' => (int) ( $counts['empty'] ?? 0 ),
			);
		}
		$this->cached[ $suffix ] = array(
			'path'    => $snapshot_path,
			'witness' => $witness,
			'index'   => $index,
		);
		return $index;
	}

	/** Remember an index after an append without republishing its derived sidecar. */
	public function remember( string $suffix, string $snapshot_path, array $index ): void {
		$witness = WP_Markdown_File_Witness::take( $snapshot_path );
		if ( null === $witness ) {
			unset( $this->cached[ $suffix ] );
			return;
		}
		$this->cached[ $suffix ] = array(
			'path'    => $snapshot_path,
			'witness' => $witness,
			'index'   => $index,
		);
	}

	/**
	 * Compute an index from the snapshot rows.
	 *
	 * @param  array<int,array<string,mixed>> $rows       Snapshot rows.
	 * @param  array<string,mixed>            $definition Compiled table definition.
	 * @return array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int}
	 */
	public static function build( array $rows, array $definition, WP_Markdown_Native_Table_Schema $schema ): array {
		$index = array( 'max' => array(), 'unique' => array(), 'summary' => array(), 'row_count' => 0 );
		foreach ( $definition['columns'] as $name => $column ) {
			$index['summary'][ $name ] = array( 'null' => 0, 'empty' => 0 );
			if ( true === ( $column['auto_increment'] ?? false ) ) {
				$index['max'][ $name ] = 0;
			}
		}
		foreach ( self::unique_indexes( $definition ) as $name => $columns ) {
			$index['unique'][ $name ] = array();
		}
		foreach ( $rows as $row ) {
			$index = self::with_row( $index, $row, $definition, $schema );
		}
		return $index;
	}

	/**
	 * Fold one row into an index.
	 *
	 * @param  array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int} $index Current index.
	 * @param  array<string,mixed>                                                               $row   Row to record.
	 * @param  array<string,mixed>                                                               $definition Compiled definition.
	 * @return array{max:array<string,int>,unique:array<string,array<int,string>>,row_count:int}
	 */
	public static function with_row( array $index, array $row, array $definition, WP_Markdown_Native_Table_Schema $schema ): array {
		foreach ( $index['summary'] as $column => $counts ) {
			if ( null === ( $row[ $column ] ?? null ) ) {
				++$index['summary'][ $column ]['null'];
			} elseif ( '' === $row[ $column ] ) {
				++$index['summary'][ $column ]['empty'];
			}
		}
		foreach ( array_keys( $index['max'] ) as $column ) {
			$index['max'][ $column ] = max( $index['max'][ $column ], (int) ( $row[ $column ] ?? 0 ) );
		}
		foreach ( self::unique_indexes( $definition ) as $name => $columns ) {
			$key = self::unique_key( $row, $columns, $schema );
			if ( null !== $key ) {
				$index['unique'][ $name ][] = $key;
			}
		}
		++$index['row_count'];
		return $index;
	}

	/**
	 * Apply a non-key UPDATE to the summaries of an already valid index.
	 *
	 * Callers retain the unique keys and auto-increment maxima, so only the
	 * NULL and empty-value counters can change.
	 *
	 * @param array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int} $index
	 * @param array<string,mixed> $before
	 * @param array<string,mixed> $after
	 * @return array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int}
	 */
	public static function with_non_key_update( array $index, array $before, array $after ): array {
		foreach ( $index['summary'] as $column => $counts ) {
			$before_value = $before[ $column ] ?? null;
			$after_value  = $after[ $column ] ?? null;
			if ( null === $before_value ) {
				--$index['summary'][ $column ]['null'];
			} elseif ( '' === $before_value ) {
				--$index['summary'][ $column ]['empty'];
			}
			if ( null === $after_value ) {
				++$index['summary'][ $column ]['null'];
			} elseif ( '' === $after_value ) {
				++$index['summary'][ $column ]['empty'];
			}
		}
		return $index;
	}

	/**
	 * Decide whether a row would duplicate a recorded unique key.
	 *
	 * @param array{unique:array<string,array<int,string>>} $index      Current index.
	 * @param array<string,mixed>                          $row        Candidate row.
	 * @param array<string,mixed>                          $definition Compiled definition.
	 */
	public static function duplicates( array $index, array $row, array $definition, WP_Markdown_Native_Table_Schema $schema ): bool {
		foreach ( self::unique_indexes( $definition ) as $name => $columns ) {
			$key = self::unique_key( $row, $columns, $schema );
			if ( null !== $key && in_array( $key, $index['unique'][ $name ] ?? array(), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Persist an index describing the current snapshot.
	 *
	 * @param array{max:array<string,int>,unique:array<string,array<int,string>>,summary:array<string,array{null:int,empty:int}>,row_count:int} $index Index to persist.
	 */
	public function save( string $suffix, string $snapshot_path, array $index, ?WP_Markdown_Native_Transaction_Journal $transactions ): bool {
		$path = $this->path( $suffix );
		$directory = dirname( $path );
		if ( ! is_dir( $directory ) && ! @mkdir( $directory, 0755, true ) && ! is_dir( $directory ) ) {
			return false;
		}
		$witness = WP_Markdown_File_Witness::take( $snapshot_path );
		if ( null === $witness ) {
			return false;
		}
		if ( null !== $transactions && true !== $transactions->record( $path ) ) {
			return false;
		}
		try {
			$encoded = json_encode(
				array(
					'schema'      => self::SCHEMA,
					'fingerprint' => $witness->identity(),
					'max'         => $index['max'],
					'unique'      => $index['unique'],
					'summary'     => $index['summary'],
					'row_count'   => $index['row_count'],
				),
				JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
			);
		} catch ( Throwable ) {
			return false;
		}
		$temp = $path . '.tmp-' . getmypid() . '-' . bin2hex( random_bytes( 8 ) );
		if ( false === @file_put_contents( $temp, $encoded ) || ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			return false;
		}
		return true;
	}

	/** Discard an index that no longer describes its snapshot. */
	public function forget( string $suffix, ?WP_Markdown_Native_Transaction_Journal $transactions ): void {
		unset( $this->cached[ $suffix ] );
		$path = $this->path( $suffix );
		if ( ! is_file( $path ) ) {
			return;
		}
		if ( null !== $transactions ) {
			$transactions->record( $path );
		}
		@unlink( $path );
	}

	/** @param array<string,mixed> $decoded */
	private function describes( array $decoded, WP_Markdown_File_Witness $witness ): bool {
		$fingerprint = $decoded['fingerprint'] ?? array();
		return is_array( $fingerprint ) && $fingerprint === $witness->identity();
	}

	/**
	 * Unique indexes whose members must be tracked by value.
	 *
	 * An index over only the auto-increment column is skipped: a generated
	 * identifier is derived from the recorded maximum and therefore cannot
	 * collide, so recording every identifier would grow the index with the
	 * table for no additional guarantee.
	 *
	 * @param  array<string,mixed> $definition Compiled definition.
	 * @return array<string,array<int,string>>
	 */
	private static function unique_indexes( array $definition ): array {
		$generated = array();
		foreach ( $definition['columns'] ?? array() as $name => $column ) {
			if ( true === ( $column['auto_increment'] ?? false ) ) {
				$generated[] = (string) $name;
			}
		}
		$indexes = array();
		foreach ( $definition['indexes'] ?? array() as $position => $index ) {
			if ( true !== ( $index['unique'] ?? false ) ) {
				continue;
			}
			$columns = $index['columns'] ?? array();
			$names   = array_column( $columns, 'name' );
			if ( array() === $names || array() === array_diff( $names, $generated ) ) {
				continue;
			}
			$indexes[ (string) ( $index['name'] ?? $position ) ] = $columns;
		}
		return $indexes;
	}

	/**
	 * Report whether an insert supplies its own auto-increment identifier.
	 *
	 * A supplied identifier bypasses the generated-value guarantee, so callers
	 * must verify it against the snapshot rather than the index.
	 *
	 * @param array<string,int|string|null> $provided   Supplied columns.
	 * @param array<string,mixed>           $definition Compiled definition.
	 */
	public static function supplies_identity( array $provided, array $definition ): bool {
		foreach ( $definition['columns'] ?? array() as $name => $column ) {
			if ( true !== ( $column['auto_increment'] ?? false ) ) {
				continue;
			}
			$value = $provided[ $name ] ?? null;
			if ( null !== $value && '0' !== (string) $value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param array<string,mixed> $row     Row to key.
	 * @param array<int,array{name?:string,length?:int|null}> $columns Index columns.
	 */
	private static function unique_key( array $row, array $columns, WP_Markdown_Native_Table_Schema $schema ): ?string {
		$parts = array();
		foreach ( $columns as $column ) {
			$name = (string) ( $column['name'] ?? '' );
			if ( ! array_key_exists( $name, $row ) || null === $row[ $name ] ) {
				return null;
			}
			$value  = $row[ $name ];
			$length = $column['length'] ?? null;
			if ( is_int( $length ) && is_string( $value ) ) {
				$value = substr( $value, 0, $length );
			}
			$key = $schema->value_key( $name, $value );
			if ( null === $key ) {
				return null;
			}
			$parts[] = $key;
		}
		return implode( "\x1f", $parts );
	}
}
