<?php
/** File-backed providers; query execution remains table-neutral. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-native-json-row-stream.php';
require_once __DIR__ . '/../class-wp-markdown-file-witness.php';
require_once __DIR__ . '/class-wp-markdown-native-post-catalogue.php';
require_once __DIR__ . '/class-wp-markdown-native-option-catalogue.php';

abstract class WP_Markdown_Native_File_Provider implements WP_Markdown_Native_Table_Provider {

	protected string $state_root;

	public function __construct(
		string $state_root,
		protected WP_Markdown_Native_Table_Schema $schema
	) {
		$root = realpath( $state_root );
		if ( false === $root || ! is_dir( $root ) ) {
			throw new InvalidArgumentException( 'The canonical state root must be an existing directory.' );
		}
		$this->state_root = rtrim( $root, DIRECTORY_SEPARATOR );
	}

	protected function failure( string $code, string $reason, string $message ): WP_Markdown_Query_Result {
		return WP_Markdown_Query_Result::failure(
			array(
				'code'    => $code,
				'reason'  => $reason,
				'message' => $message,
			)
		);
	}

	protected function contains( string $root, string $path ): bool {
		return str_starts_with( $path, rtrim( $root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR );
	}

	/** @return mixed|WP_Markdown_Query_Result */
	/**
	 * Open a canonical state file, proving it is the file it claims to be.
	 *
	 * @return resource|WP_Markdown_Query_Result
	 */
	protected function open_verified( string $path, string $root, string $kind ) {
		$real = realpath( $path );
		if ( is_link( $path ) || false === $real || ! is_file( $real ) || ! $this->contains( $root, $real ) ) {
			return $this->failure(
				'markdown_db_native_unsafe_path',
				'unsafe_' . $kind,
				'The canonical state file is not contained by its state directory.'
			);
		}

		$handle = @fopen( $real, 'rb' );
		if ( false === $handle ) {
			return $this->failure(
				'markdown_db_native_malformed_table',
				'unreadable_' . $kind,
				'The canonical state file cannot be read.'
			);
		}

		$opened  = fstat( $handle );
		$current = @lstat( $real );
		if ( false === $opened
			|| false === $current
			|| $opened['dev'] !== $current['dev']
			|| $opened['ino'] !== $current['ino']
			|| 1 !== ( $opened['nlink'] ?? 1 )
			|| is_link( $real )
			|| $root !== realpath( dirname( $path ) )
		) {
			fclose( $handle );
			return $this->failure(
				'markdown_db_native_unsafe_path',
				'changed_' . $kind,
				'The canonical state file changed while it was being opened.'
			);
		}
		return $handle;
	}

	protected function read_json( string $path, string $root, string $kind, ?string &$digest = null ) {
		$handle = $this->open_verified( $path, $root, $kind );
		if ( $handle instanceof WP_Markdown_Query_Result ) {
			return $handle;
		}

		try {
			$contents = stream_get_contents( $handle );
			if ( false === $contents ) {
				return $this->failure(
					'markdown_db_native_malformed_table',
					'unreadable_' . $kind,
					'The canonical state file cannot be read.'
				);
			}
			if ( 4 <= func_num_args() ) {
				$digest = hash( 'sha256', $contents );
			}
			return json_decode( $contents, true, 512, JSON_THROW_ON_ERROR );
		} catch ( JsonException $error ) {
			return $this->failure(
				'markdown_db_native_malformed_table',
				'invalid_json',
				'The canonical state file contains invalid JSON.'
			);
		} finally {
			fclose( $handle );
		}
	}

	/** @return array<int,array<string,mixed>>|WP_Markdown_Query_Result */
	protected function validate_rows( mixed $rows ): array|WP_Markdown_Query_Result {
		if ( ! is_array( $rows ) || ! array_is_list( $rows ) ) {
			return $this->failure(
				'markdown_db_native_malformed_table',
				'invalid_table_rows',
				'The canonical table must contain a JSON array of rows.'
			);
		}

		$identities = array();
		$columns = $this->schema->column_names();
		foreach ( $rows as $offset => $row ) {
			if ( ! is_array( $row ) || true !== $this->schema->validate_row( $row ) ) {
				return $this->failure(
					'markdown_db_native_malformed_table',
					'invalid_table_row',
					'The canonical table contains a row outside its declared schema.'
				);
			}
			$key = $this->schema->identity_key( $row );
			if ( null === $key || isset( $identities[ $key ] ) ) {
				return $this->failure(
					'markdown_db_native_malformed_table',
					'duplicate_natural_identity',
					'The canonical table contains duplicate natural identities.'
				);
			}
			$identities[ $key ] = true;
			$ordered = array();
			foreach ( $columns as $column ) {
				$ordered[ $column ] = $row[ $column ];
			}
			$rows[ $offset ] = $ordered;
		}
		return $rows;
	}

	/**
	 * Order a read, bound it, and project the columns it asked for.
	 *
	 * Every provider answers a read this way, so it is said here once. A
	 * provider that must go back to storage for a column it did not carry
	 * through ordering supplies $hydrate, which is called only for the rows
	 * that survived the bound, and may refuse the read.
	 *
	 * @param array<int,array<string,mixed>> $rows
	 * @param null|callable(int,array<string,mixed>):(array<string,mixed>|WP_Markdown_Query_Result) $hydrate
	 * @return array<int,array<string,mixed>>|WP_Markdown_Query_Result
	 */
	protected function bounded_rows( array $rows, WP_Markdown_Native_Table_Access $access, ?callable $hydrate = null, bool $ordered = false ): array|WP_Markdown_Query_Result {
		$case_order = false;
		foreach ( $access->order_by() as $item ) {
			$case_order = $case_order || null !== ( $item['case'] ?? null );
		}
		if ( $case_order && null !== $hydrate ) {
			// A searched CASE may rank on canonical body content that the post
			// catalogue intentionally omits. It must see every ordering value
			// before the bound chooses which rows survive.
			foreach ( $rows as $offset => $row ) {
				$hydrated = $hydrate( $offset, $row );
				if ( $hydrated instanceof WP_Markdown_Query_Result ) {
					return $hydrated;
				}
				$rows[ $offset ] = $hydrated;
			}
			$hydrate = null;
		}
		if ( ! $ordered ) {
			$rows = $this->schema->ordered_rows( $rows, $access->order_by() );
			if ( null === $rows ) {
				return $this->failure(
					'markdown_db_native_unsupported_query',
					'unsupported_order',
					'mdi-native cannot apply the requested ordering collation.'
				);
			}
		}

		$selected = array();
		foreach ( $rows as $offset => $source ) {
			if ( count( $selected ) >= $access->limit() ) {
				break;
			}
			if ( null !== $hydrate ) {
				$source = $hydrate( $offset, $source );
				if ( $source instanceof WP_Markdown_Query_Result ) {
					return $source;
				}
			}
			$row = array();
			foreach ( $access->projection() as $column ) {
				$row[ $column ] = $source[ $column ];
			}
			$selected[] = $row;
		}
		return $selected;
	}

	/** Cache identity only; path safety is still enforced while reading. */
	protected function path_signature( string $path, ?string $content_digest = null ): string {
		clearstatcache( true, $path );
		$stat = @lstat( $path );
		if ( false === $stat ) {
			return 'missing';
		}
		$identity = implode( ':', array( $stat['dev'], $stat['ino'], $stat['mode'], $stat['size'], $stat['mtime'], $stat['ctime'], $stat['nlink'] ?? 0 ) );
		if ( is_link( $path ) ) {
			return 'link:' . $identity . ':' . (string) @readlink( $path );
		}
		if ( is_file( $path ) ) {
			if ( 1 !== ( $stat['nlink'] ?? 1 ) ) {
				return 'linked-file:' . $identity;
			}
			return 'file:' . $identity . ':' . ( $content_digest ?? (string) @hash_file( 'sha256', $path ) );
		}
		return 'node:' . $identity;
	}
}

final class WP_Markdown_Native_Post_Provider extends WP_Markdown_Native_File_Provider {
	private WP_Markdown_Storage $storage;
	private WP_Markdown_Native_Post_Catalogue $catalogue;
	/** @var array<string,array<int,array{post:object,row:array<string,mixed>,file:array<string,mixed>,identity:array<string,int>}>> */
	private array $scoped_posts = array();
	/** @var array<string,array<string,array<int,array{post:object,row:array<string,mixed>,file:array<string,mixed>,identity:array<string,int>}>>> */
	private array $scoped_ordered_posts = array();

	public function __construct(
		string $content_root,
		WP_Markdown_Native_Table_Schema $schema,
		?WP_Markdown_Storage $storage = null,
		?string $state_root = null,
		private bool $network_root = false
	) {
		parent::__construct( $content_root, $schema );
		$this->storage = $storage ?? new WP_Markdown_Storage( $content_root );
		// Writing a canonical file makes what was remembered about that file
		// stale, so its parse is dropped the moment it changes. Files the
		// write did not touch are still proven by the witness they were
		// recorded under and are kept. The scoped views are lists of which
		// files answered a read, which a new or removed file changes, so they
		// are rebuilt — from the surviving parses, not from the corpus.
		$this->catalogue = new WP_Markdown_Native_Post_Catalogue( $content_root, $state_root ?? $content_root, $network_root ? array( 'sites' ) : array() );
		$this->storage->add_file_mutation_observer( function ( string $path ): void {
			$this->catalogue->forget( $path );
			$this->scoped_posts = array();
			$this->scoped_ordered_posts = array();
		} );
	}

	/** A read that restricts post type parses a different part of the corpus. */
	private function parse_key( ?array $scope ): string {
		return null === $scope ? '*' : implode( ',', $scope );
	}

	/** Cache orderings that can be answered from metadata without body hydration. */
	private function order_key( WP_Markdown_Native_Table_Access $access ): ?string {
		foreach ( $access->order_by() as $item ) {
			if ( null !== ( $item['case'] ?? null ) ) {
				return null;
			}
		}
		return hash( 'sha256', serialize( $access->order_by() ) );
	}

	/**
	 * @param array<int,array{post:object,row:array<string,mixed>,file:array<string,mixed>,identity:array<string,int>}> $candidates
	 * @return array{candidates:array<int,array{post:object,row:array<string,mixed>,file:array<string,mixed>,identity:array<string,int>}>,ordered:bool}
	 */
	private function ordered_scoped_candidates( string $scope, array $candidates, WP_Markdown_Native_Table_Access $access ): array {
		$key = $this->order_key( $access );
		if ( null === $key ) {
			return array( 'candidates' => $candidates, 'ordered' => false );
		}
		if ( isset( $this->scoped_ordered_posts[ $scope ][ $key ] ) ) {
			return array( 'candidates' => $this->scoped_ordered_posts[ $scope ][ $key ], 'ordered' => true );
		}
		$rows = array_map( static fn( array $candidate ): array => $candidate['row'], $candidates );
		$ordered = $this->schema->ordered_rows( $rows, $access->order_by() );
		if ( null === $ordered ) {
			return array( 'candidates' => $candidates, 'ordered' => false );
		}
		$this->scoped_ordered_posts[ $scope ][ $key ] = array_map( fn( array $row, int $offset ): array => $candidates[ $offset ], $ordered, array_keys( $ordered ) );
		return array( 'candidates' => $this->scoped_ordered_posts[ $scope ][ $key ], 'ordered' => true );
	}

	/**
	 * Resolve the post types a read may restrict itself to.
	 *
	 * A post type restriction maps directly onto canonical layout, so the
	 * read can skip the types it cannot match. Any other restriction reads
	 * the full corpus, which is the behaviour that existed before.
	 *
	 * @return array<int,string>|null
	 */
	private function post_type_scope( WP_Markdown_Native_Table_Access $access ): ?array {
		$predicates = $access->predicates();
		if ( array() === $predicates && null !== $access->predicate() ) {
			$predicates = array( $access->predicate() );
		}
		foreach ( $predicates as $predicate ) {
			if ( 'post_type' !== $predicate->column() ) {
				continue;
			}
			$types = array();
			foreach ( $predicate->values() as $value ) {
				if ( ! is_string( $value ) || '' === $value ) {
					return null;
				}
				$types[] = $value;
			}
			return array() === $types ? null : $types;
		}
		return null;
	}

	/**
	 * Resolve a read restricted to durable identity without walking the corpus.
	 *
	 * A scan proves the corpus is internally consistent, which is why every
	 * file is visited when one is performed. Looking up a post by identity is
	 * the common read and cannot afford that, so it goes straight to the file
	 * the identity was last found in. Anything unproven — an identity never
	 * seen, a file since removed, or a file no longer carrying that identity —
	 * returns null so the caller scans instead.
	 *
	 * @return array<int,array<string,mixed>>|null
	 */
	private function located_candidates( WP_Markdown_Native_Table_Access $access ): ?array {
		$predicate = $access->predicate();
		if ( null === $predicate || $predicate->column() !== $this->schema->natural_order() ) {
			return null;
		}
		$candidates = array();
		foreach ( $predicate->values() as $value ) {
			$id = (int) $value;
			$file = $this->catalogue->file_for( $id );
			if ( null === $file && ! $this->network_root ) {
				$file = $this->storage->indexed_post_file( $id );
			}
			if ( null === $file ) {
				return null;
			}
			$witness = WP_Markdown_File_Witness::take( $file['absolute'] );
			if ( null === $witness ) {
				return null;
			}
			$identity = $witness->identity();
			$remembered = $this->catalogue->recorded( $file['absolute'], $witness );
			if ( null !== $remembered ) {
				$post = $remembered['post'];
				$row = $remembered['row'];
			} else {
				$post = $this->storage->read_file( $file['absolute'], true, $file['parent_id'] );
				if ( null === $post || ! $this->unchanged( $file['absolute'], $identity ) ) {
					return null;
				}
				$row = $this->row( $post );
				if ( true !== $this->schema->validate_row( $row ) ) {
					return null;
				}
				$this->catalogue->remember( $witness, $file, $post, $row );
			}
			if ( $id !== (int) ( $post->ID ?? 0 ) || ! $this->matches( $row, $predicate ) ) {
				return null;
			}
			$candidates[] = array( 'post' => $post, 'row' => $row, 'file' => $file, 'identity' => $identity );
		}
		return $candidates;
	}

	public function read( WP_Markdown_Native_Table_Access $access ): iterable|WP_Markdown_Query_Result {
		return $this->read_posts( $access );
	}

	/** @return array<string,int>|WP_Markdown_Query_Result */
	public function identity_maxima( array $columns ): array|WP_Markdown_Query_Result {
		$access = new WP_Markdown_Native_Table_Access( $columns, null, $this->schema->natural_order(), PHP_INT_MAX );
		$start = WP_Markdown_Operation_Profile::begin();
		try {
			return $this->read_posts( $access, $columns );
		} finally {
			WP_Markdown_Operation_Profile::end( 'identity_allocation', $start );
		}
	}

	/**
	 * @param array<int,string> $allocation_columns Identity columns to reduce instead of producing query rows.
	 */
	private function read_posts( WP_Markdown_Native_Table_Access $access, array $allocation_columns = array() ): array|WP_Markdown_Query_Result {
		$scanning = false;
		$completed = false;
		$maxima = array_fill_keys( $allocation_columns, 0 );
		try {
			$posts = $this->located_candidates( $access );
			if ( null !== $posts ) {
				return $this->ordered_projection( $posts, $access );
			}
			$posts = array();
			$candidates = array();
			$ids   = array();
			$predicates = $access->predicates();
			if ( array() === $predicates && null !== $access->predicate() ) {
				$predicates[] = $access->predicate();
			}
			$metadata_predicates = array_values(
				array_filter(
					$predicates,
					static fn( WP_Markdown_Native_Query_Predicate $predicate ): bool => ! in_array( 'post_content', $predicate->columns(), true )
				)
			);
			$scope = $this->post_type_scope( $access );
			$key = null === $scope ? null : $this->parse_key( $scope );
			$ordered = false;
			if ( ! $access->requires_complete_scope() && null !== $key && isset( $this->scoped_posts[ $key ] ) ) {
				$candidates = $this->scoped_posts[ $key ];
				$posts = array_values( array_filter( $candidates, fn( array $candidate ): bool => $this->schema->matches( $candidate['row'], $metadata_predicates ) ) );
				if ( count( $posts ) === count( $candidates ) ) {
					$cached = $this->ordered_scoped_candidates( $key, $candidates, $access );
					$posts = $cached['candidates'];
					$ordered = $cached['ordered'];
				}
				return $this->ordered_projection( $posts, $access, $ordered );
			}
			if ( null === $scope ) {
				$this->catalogue->begin_scan();
				$scanning = true;
			}
			foreach ( $this->storage->get_markdown_file_manifest_iterator( true, $scope ) as $file ) {
				// The manifest looked at this file to yield it, so its witness
				// is the one taken then.
				$witness = $file['witness'] ?? WP_Markdown_File_Witness::take( $file['absolute'] );
				$identity = null === $witness ? null : $witness->identity();
				// Parsing a file is the expensive part of a post read, so a
				// file that still carries the identity it was parsed under is
				// taken from the previous parse. Every file is still visited,
				// so a corpus edited outside this process is still seen.
				$remembered = $this->catalogue->recorded( $file['absolute'], $witness, true );
				$reused = null !== $remembered;
				if ( $reused ) {
					WP_Markdown_Operation_Profile::count( 'post_parse_reuse' );
					$post = $remembered['post'];
					$row = $remembered['row'];
				} else {
					$post = $this->storage->read_file( $file['absolute'], true, $file['parent_id'] );
					$row = null;
				}
				if ( null === $identity || null === $post || (int) ( $post->ID ?? 0 ) < 1 ) {
					return $this->malformed( 'invalid_post', 'A canonical Markdown post is malformed or has no durable identity.' );
				}
				// Re-reading the identity proves the file did not change while
				// it was being read. A reused parse read nothing, so there is
				// no window to close.
				if ( ! $reused && ! $this->unchanged( $file['absolute'], $identity ) ) {
					return $this->malformed( 'changed_post', 'A canonical Markdown post changed while it was being read.' );
				}
				$id = (int) $post->ID;
				if ( isset( $ids[ $id ] ) ) {
					return $this->malformed( 'duplicate_post_id', 'Canonical Markdown posts contain a duplicate durable identity.' );
				}
				$ids[ $id ] = true;
				// A scan is the one read that sees the whole corpus, so it is
				// where identity learns which file it lives in.

				if ( null === $row ) {
					$row = $this->row( $post );
					if ( true !== $this->schema->validate_row( $row ) ) {
						return $this->malformed( 'invalid_post_row', 'A canonical Markdown post is outside the wp_posts schema.' );
					}
				}
				// Strict manifest traversal already proved this is a canonical path.
				$this->catalogue->remember( $witness, $file, $post, $row, true );
				if ( array() !== $allocation_columns ) {
					foreach ( $allocation_columns as $column ) {
						$maxima[ $column ] = max( $maxima[ $column ], (int) $row[ $column ] );
					}
					continue;
				}
				// Body predicates remain executor residuals until their candidates
				// are hydrated; metadata predicates safely reduce sorting work here.
				$matches = $this->schema->matches( $row, $metadata_predicates );
				if ( $matches || null !== $key ) {
					$candidate = array( 'post' => $post, 'row' => $row, 'file' => $file, 'identity' => $identity );
					if ( $matches ) {
						$posts[] = $candidate;
					}
					if ( null !== $key ) {
						$candidates[] = $candidate;
					}
				}
			}
			if ( null === $scope ) {
				$this->catalogue->complete_scan( array() === $allocation_columns );
				$completed = true;
			} elseif ( null !== $key ) {
				// A scoped corpus is immutable for this runtime after its initial
				// verified traversal. Canonical writes clear this snapshot first.
				$this->scoped_posts[ $key ] = $candidates;
				if ( count( $posts ) === count( $candidates ) ) {
					$cached = $this->ordered_scoped_candidates( $key, $candidates, $access );
					$posts = $cached['candidates'];
					$ordered = $cached['ordered'];
				}
			}

			return array() !== $allocation_columns ? $maxima : $this->ordered_projection( $posts, $access, $ordered ?? false );
		} catch ( Throwable $error ) {
			return $this->malformed( 'unsafe_post_storage', 'Canonical Markdown posts cannot be read safely.' );
		} finally {
			if ( $scanning && ! $completed ) {
				$this->catalogue->abort_scan();
			}
		}
	}

	/**
	 * Order, bound and project the posts a read selected.
	 *
	 * @param array<int,array<string,mixed>> $posts
	 * @return array<int,array<string,mixed>>|WP_Markdown_Query_Result
	 */
	private function ordered_projection( array $posts, WP_Markdown_Native_Table_Access $access, bool $ordered = false ): array|WP_Markdown_Query_Result {
		try {
			$rows = array_map( static fn( array $candidate ): array => $candidate['row'], $posts );
			if ( ! in_array( 'post_content', $access->projection(), true ) ) {
				return $this->bounded_rows( $rows, $access, null, $ordered );
			}
			// A body is read only for the posts the bound actually returns,
			// and the file must still be the one the row was taken from.
			return $this->bounded_rows(
				$rows,
				$access,
				function ( int $offset, array $row ) use ( $posts ): array|WP_Markdown_Query_Result {
					$candidate = $posts[ $offset ];
					$post      = $this->storage->read_file( $candidate['file']['absolute'], false, $candidate['file']['parent_id'] );
					if ( ! $this->unchanged( $candidate['file']['absolute'], $candidate['identity'] ) || null === $post ) {
						return $this->malformed( 'changed_post', 'A canonical Markdown post changed while it was being read.' );
					}
					return $this->row( $post );
				},
				$ordered
			);
		} catch ( Throwable $error ) {
			return $this->malformed( 'unsafe_post_storage', 'Canonical Markdown posts cannot be read safely.' );
		}
	}

	/** @param array<string,mixed> $row */
	private function matches( array $row, WP_Markdown_Native_Query_Predicate $predicate ): bool {
		foreach ( $predicate->values() as $value ) {
			if ( $this->schema->values_match( $predicate->column(), $row[ $predicate->column() ], $value ) ) {
				return true;
			}
		}
		return false;
	}

	/** @return array<string,mixed> */
	private function row( object $post ): array {
		$row = array();
		foreach ( $this->schema->column_names() as $column ) {
			$row[ $column ] = $post->{$column};
		}
		return $row;
	}

	private function malformed( string $reason, string $message ): WP_Markdown_Query_Result {
		return $this->failure( 'markdown_db_native_malformed_post', $reason, $message );
	}

	/** @return array{dev:int,ino:int,mode:int,size:int,mtime:int,ctime:int,nlink:int}|null */
	private function file_identity( string $path ): ?array {
		$witness = WP_Markdown_File_Witness::take( $path );
		return null === $witness ? null : $witness->identity();
	}

	/** @param array{dev:int,ino:int,mode:int,size:int,mtime:int,ctime:int,nlink:int} $identity */
	private function unchanged( string $path, array $identity ): bool {
		return $identity === $this->file_identity( $path );
	}
}

final class WP_Markdown_Native_JSON_Snapshot_Provider extends WP_Markdown_Native_File_Provider {
	private bool $loaded = false;
	/** @var array<int,array<string,mixed>>|WP_Markdown_Query_Result|null */
	private array|WP_Markdown_Query_Result|null $snapshot = null;
	/** @var array<string,array<string,array<int,int>>> */
	private array $equality_indexes = array();

	public function __construct(
		string $state_root,
		WP_Markdown_Native_Table_Schema $schema,
		private string $filename
	) {
		parent::__construct( $state_root, $schema );
	}

	public function read( WP_Markdown_Native_Table_Access $access ): iterable|WP_Markdown_Query_Result {
		return $this->rows();
	}

	/** @return array<int,array<string,mixed>>|WP_Markdown_Query_Result */
	public function rows(): array|WP_Markdown_Query_Result {
		$directory = $this->state_root . DIRECTORY_SEPARATOR . '_tables';
		$path      = $directory . DIRECTORY_SEPARATOR . $this->filename;
		if ( $this->loaded ) {
			return $this->snapshot;
		}
		$this->loaded = true;
		if ( ! file_exists( $directory ) && ! is_link( $directory ) ) {
			return $this->snapshot = array();
		}
		$root = realpath( $directory );
		if ( is_link( $directory ) || false === $root || ! is_dir( $root ) || ! $this->contains( $this->state_root, $root ) ) {
			return $this->snapshot = $this->failure(
				'markdown_db_native_unsafe_path',
				'unsafe_tables_directory',
				'The canonical tables directory is not contained by the state root.'
			);
		}

		$path = $root . DIRECTORY_SEPARATOR . $this->filename;
		if ( ! file_exists( $path ) && ! is_link( $path ) ) {
			return $this->snapshot = array();
		}
		$data = $this->read_json( $path, $root, 'table_file' );
		return $this->snapshot = $data instanceof WP_Markdown_Query_Result
			? $data
			: $this->validate_rows( $data );
	}

	/**
	 * Return the smallest exact-equality candidate set from this validated
	 * request snapshot. The executor still applies every predicate afterwards.
	 *
	 * @param array<int,WP_Markdown_Native_Query_Predicate> $predicates
	 * @return array<int,array<string,mixed>>|WP_Markdown_Query_Result
	 */
	public function equality_candidates( array $predicates ): array|WP_Markdown_Query_Result {
		$rows = $this->rows();
		if ( $rows instanceof WP_Markdown_Query_Result ) {
			return $rows;
		}

		$candidates = null;
		foreach ( $predicates as $predicate ) {
			if ( '=' !== $predicate->operator() || null !== $predicate->cast() || 1 !== count( $predicate->values() ) ) {
				continue;
			}
			$column = $predicate->column();
			$key = $this->schema->value_key( $column, $predicate->values()[0] );
			if ( null === $key ) {
				return array();
			}
			$offsets = $this->equality_index( $column, $rows )[ $key ] ?? array();
			if ( null === $candidates || count( $offsets ) < count( $candidates ) ) {
				$candidates = $offsets;
			}
		}
		if ( null === $candidates ) {
			return $rows;
		}

		return array_map( fn( int $offset ): array => $rows[ $offset ], $candidates );
	}

	/** @param array<int,array<string,mixed>> $rows @return array<string,array<int,int>> */
	private function equality_index( string $column, array $rows ): array {
		if ( isset( $this->equality_indexes[ $column ] ) ) {
			return $this->equality_indexes[ $column ];
		}
		$index = array();
		foreach ( $rows as $offset => $row ) {
			$key = $this->schema->value_key( $column, $row[ $column ] ?? null );
			if ( null !== $key ) {
				$index[ $key ][] = $offset;
			}
		}
		return $this->equality_indexes[ $column ] = $index;
	}

	/** @param array<int,array<string,mixed>> $rows */
	public function replace_rows( array $rows ): void {
		$this->loaded   = true;
		$this->snapshot = $rows;
		$this->equality_indexes = array();
	}

	/** @param array<string,mixed> $row */
	public function append_row( array $row ): void {
		if ( $this->loaded && is_array( $this->snapshot ) ) {
			$offset = count( $this->snapshot );
			foreach ( array_keys( $this->equality_indexes ) as $column ) {
				$key = $this->schema->value_key( $column, $row[ $column ] ?? null );
				if ( null !== $key ) {
					$this->equality_indexes[ $column ][ $key ][] = $offset;
				}
			}
			$this->snapshot[] = $row;
		}
	}

	public function forget_rows(): void {
		$this->loaded   = false;
		$this->snapshot = null;
		$this->equality_indexes = array();
	}
}

final class WP_Markdown_Native_JSON_Partition_Provider extends WP_Markdown_Native_File_Provider {
	private string $lock_root;

	public function __construct(
		string $state_root,
		WP_Markdown_Native_Table_Schema $schema,
		private string $table,
		private string $identity_column
	) {
		$this->lock_root = rtrim( $state_root, '/\\' );
		parent::__construct( $state_root, $schema );
		if ( 1 !== preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/D', $table )
			|| ! $schema->has_column( $identity_column )
			|| ! $schema->is_lookup( $identity_column )
		) {
			throw new InvalidArgumentException( 'Partition providers require a table and indexed identity column.' );
		}
	}

	public function read( WP_Markdown_Native_Table_Access $access ): iterable|WP_Markdown_Query_Result {
		$lock = $this->partition_lock();
		if ( $lock instanceof WP_Markdown_Query_Result ) {
			return $lock;
		}
		try {
			$generation = $this->active_generation();
			if ( $generation instanceof WP_Markdown_Query_Result ) {
				return $generation;
			}
			if ( null === $generation ) {
				return array();
			}

			$predicate = $access->predicate();
			$rows = $this->exact_rows( $generation, $access, $predicate );
			if ( null === $rows ) {
				$rows = $this->generation_rows( $generation );
			}
			if ( $rows instanceof WP_Markdown_Query_Result ) {
				return $rows;
			}
			if ( null !== $predicate ) {
				$rows = array_values( array_filter( $rows, fn( array $row ): bool => $this->schema->matches( $row, array( $predicate ) ) ) );
			}
			return $this->bounded_rows( $rows, $access );
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}

	/**
	 * Return hash-addressed rows when the executor supplied an exact identity
	 * predicate. A null return deliberately selects the complete scan path.
	 *
	 * @return array<int,array<string,mixed>>|WP_Markdown_Query_Result|null
	 */
	private function exact_rows( string $generation, WP_Markdown_Native_Table_Access $access, ?WP_Markdown_Native_Query_Predicate $predicate ): array|WP_Markdown_Query_Result|null {
		if ( null === $predicate
			|| $this->identity_column !== $predicate->column()
			|| ! in_array( $predicate->operator(), array( '=', 'IN' ), true )
			|| array() === $predicate->values()
		) {
			return null;
		}

		$identities = array();
		foreach ( $predicate->values() as $value ) {
			$normalized = $this->schema->column( $this->identity_column )->normalize( $value );
			if ( ! is_int( $normalized ) && ! is_string( $normalized ) ) {
				return $this->malformed( 'invalid_partition_identity', 'The requested partition identity cannot be normalized.' );
			}
			$identities[ (string) $normalized ] = $normalized;
		}
		if ( $access->order() === $this->identity_column ) {
			usort( $identities, fn( mixed $left, mixed $right ): int => $this->schema->compare_values( $this->identity_column, $left, $right ) );
		}

		$rows = array();
		foreach ( $identities as $normalized ) {
			if ( $access->order() === $this->identity_column && count( $rows ) >= $access->limit() ) {
				break;
			}
			$row = $this->partition_row( $generation, (string) $normalized );
			if ( $row instanceof WP_Markdown_Query_Result ) {
				return $row;
			}
			if ( null !== $row ) {
				$rows[] = $row;
			}
		}
		return $rows;
	}

	/** @return array<int,array<string,mixed>>|WP_Markdown_Query_Result */
	private function generation_rows( string $generation ): array|WP_Markdown_Query_Result {
		$entries = @scandir( $generation );
		if ( false === $entries ) {
			return $this->malformed( 'unreadable_partition_generation', 'The active canonical partition generation cannot be enumerated.' );
		}

		$rows = array();
		$identities = array();
		foreach ( $entries as $entry ) {
			// Only content-addressed v1 row files participate in the generation.
			if ( 1 !== preg_match( '/^[a-f0-9]{64}\.json$/D', $entry ) ) {
				continue;
			}
			$row = $this->partition_row( $generation, null, $entry );
			if ( $row instanceof WP_Markdown_Query_Result ) {
				return $row;
			}
			if ( null === $row ) {
				return $this->malformed( 'missing_partition_row', 'A canonical partition row disappeared while it was being read.' );
			}
			$identity = (string) $this->schema->column( $this->identity_column )->normalize( $row[ $this->identity_column ] );
			if ( isset( $identities[ $identity ] ) ) {
				return $this->malformed( 'duplicate_partition_identity', 'The active canonical partition generation contains duplicate identities.' );
			}
			$identities[ $identity ] = true;
			$rows[] = $row;
		}
		return $rows;
	}

	/** @return resource|WP_Markdown_Query_Result */
	private function partition_lock() {
		$directory = rtrim( sys_get_temp_dir(), '/\\' ) . '/markdown-database-integration-locks';
		if ( ! is_dir( $directory ) && ! @mkdir( $directory, 0755, true ) && ! is_dir( $directory ) ) {
			return $this->malformed( 'unavailable_partition_lock', 'The native partition lock directory is unavailable.' );
		}
		$path = $directory . '/partition-' . hash( 'sha256', $this->lock_root . "\0" . $this->table ) . '.lock';
		$lock = @fopen( $path, 'c+' );
		if ( false === $lock || ! flock( $lock, LOCK_SH ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock );
			}
			return $this->malformed( 'unavailable_partition_lock', 'The native partition lock cannot be acquired.' );
		}
		return $lock;
	}

	private function active_generation(): string|WP_Markdown_Query_Result|null {
		$directory = $this->state_root . DIRECTORY_SEPARATOR . '_tables' . DIRECTORY_SEPARATOR . $this->table;
		if ( ! file_exists( $directory ) && ! is_link( $directory ) ) {
			return null;
		}
		$root = realpath( $directory );
		if ( is_link( $directory ) || false === $root || ! is_dir( $root ) || ! $this->contains( $this->state_root, $root ) ) {
			return $this->malformed( 'unsafe_partition_directory', 'The canonical partition directory is unsafe.' );
		}

		$marker = $this->read_json( $root . DIRECTORY_SEPARATOR . '.mdi-partition.json', $root, 'partition_marker' );
		if ( $marker instanceof WP_Markdown_Query_Result ) {
			return $this->read_failure( $marker, 'invalid_partition_marker', 'The canonical partition marker cannot be read.' );
		}
		if ( ! is_array( $marker )
			|| 1 !== ( $marker['version'] ?? null )
			|| $this->table !== ( $marker['table'] ?? null )
			|| $this->identity_column !== ( $marker['identity_column'] ?? null )
			|| 1 !== preg_match( '/^generation-[a-f0-9]{24}$/D', (string) ( $marker['generation'] ?? '' ) )
		) {
			return $this->malformed( 'invalid_partition_marker', 'The canonical partition marker does not match its declared table.' );
		}

		$path = $root . DIRECTORY_SEPARATOR . $marker['generation'];
		$generation = realpath( $path );
		if ( is_link( $path ) || false === $generation || ! is_dir( $generation ) || ! $this->contains( $root, $generation ) ) {
			return $this->malformed( 'invalid_partition_generation', 'The active canonical partition generation is unavailable.' );
		}
		return $generation;
	}

	/** @return array<string,mixed>|WP_Markdown_Query_Result|null */
	private function partition_row( string $generation, ?string $identity = null, ?string $filename = null ): array|WP_Markdown_Query_Result|null {
		$filename ??= hash( 'sha256', (string) $identity ) . '.json';
		$path = $generation . DIRECTORY_SEPARATOR . $filename;
		if ( ! file_exists( $path ) && ! is_link( $path ) ) {
			return null;
		}
		$data = $this->read_json( $path, $generation, 'partition_row' );
		if ( $data instanceof WP_Markdown_Query_Result ) {
			return $this->read_failure( $data, 'invalid_partition_row', 'The requested canonical partition row cannot be read.' );
		}
		$metadata = is_array( $data ) ? ( $data['_mdi_partition'] ?? null ) : null;
		$row      = is_array( $data ) ? ( $data['row'] ?? null ) : null;
		$stored_identity = is_array( $metadata ) ? ( $metadata['identity'] ?? null ) : null;
		$normalized = is_array( $row ) ? $this->schema->column( $this->identity_column )->normalize( $row[ $this->identity_column ] ?? null ) : null;
		if ( ! is_array( $data )
			|| 2 !== count( $data )
			|| array_diff_key( $data, array( '_mdi_partition' => true, 'row' => true ) )
			|| array_diff_key( array( '_mdi_partition' => true, 'row' => true ), $data )
			|| ! is_array( $metadata )
			|| 3 !== count( $metadata )
			|| array_diff_key( $metadata, array( 'version' => true, 'identity_column' => true, 'identity' => true ) )
			|| array_diff_key( array( 'version' => true, 'identity_column' => true, 'identity' => true ), $metadata )
			|| 1 !== ( $metadata['version'] ?? null )
			|| $this->identity_column !== ( $metadata['identity_column'] ?? null )
			|| ! is_string( $stored_identity )
			|| ( null !== $identity && $identity !== $stored_identity )
			|| hash( 'sha256', $stored_identity ) . '.json' !== $filename
			|| ! is_array( $row )
			|| true !== $this->schema->validate_row( $row )
			|| ( ! is_int( $normalized ) && ! is_string( $normalized ) )
			|| $stored_identity !== (string) $normalized
		) {
			return $this->malformed( 'invalid_partition_row', 'The requested canonical partition row does not match its identity or schema.' );
		}
		return $row;
	}

	private function malformed( string $reason, string $message ): WP_Markdown_Query_Result {
		return $this->failure( 'markdown_db_native_malformed_partition', $reason, $message );
	}

	private function read_failure( WP_Markdown_Query_Result $failure, string $reason, string $message ): WP_Markdown_Query_Result {
		return 'markdown_db_native_unsafe_path' === ( $failure->diagnostic()['code'] ?? '' )
			? $failure
			: $this->malformed( $reason, $message );
	}
}

final class WP_Markdown_Native_Option_Provider extends WP_Markdown_Native_File_Provider {
	private bool $loaded = false;
	private string $signature = '';
	private string $snapshot_scope = '';
	/** @var array<int,array<string,mixed>>|WP_Markdown_Query_Result|null */
	private array|WP_Markdown_Query_Result|null $snapshot = null;
	/** @var array<string,array{signature:string,value:array<string,mixed>|WP_Markdown_Query_Result|null}> */
	private array $option_cache = array();
	private WP_Markdown_Native_Option_Catalogue $catalogue;

	public function __construct( string $state_root, WP_Markdown_Native_Table_Schema $schema ) {
		parent::__construct( $state_root, $schema );
		$this->catalogue = new WP_Markdown_Native_Option_Catalogue( $state_root );
	}

	public function read( WP_Markdown_Native_Table_Access $access ): iterable|WP_Markdown_Query_Result {
		$predicate = $access->predicate();
		if ( null !== $predicate && 'option_name' === $predicate->column() ) {
			$rows = $this->named_rows( $predicate->values() );
		} else {
			$rows = $this->snapshot( null !== $predicate && 'autoload' === $predicate->column() ? $predicate->values() : null );
			if ( is_array( $rows ) && null !== $predicate ) {
				$rows = array_values(
					array_filter(
						$rows,
						function ( array $row ) use ( $predicate ): bool {
							foreach ( $predicate->values() as $value ) {
								if ( $this->schema->values_match( $predicate->column(), $row[ $predicate->column() ], $value ) ) {
									return true;
								}
							}
							return false;
						}
					)
				);
			}
		}
		return $rows instanceof WP_Markdown_Query_Result ? $rows : $this->bounded_rows( $rows, $access );
	}

	/** @return array<int,array<string,mixed>>|WP_Markdown_Query_Result */
	private function snapshot( ?array $autoload_values = null ): array|WP_Markdown_Query_Result {
		$scope = null === $autoload_values ? '*' : implode( ',', array_map( 'strval', $autoload_values ) );
		if ( $this->loaded && $scope === $this->snapshot_scope ) {
			$signature = $this->options_signature();
			if ( $signature === $this->signature ) {
				return $this->snapshot;
			}
		}
		$this->loaded = true;
		$this->snapshot_scope = $scope;
		$root = $this->options_root();
		if ( $root instanceof WP_Markdown_Query_Result ) {
			$this->signature = $this->options_signature();
			return $this->snapshot = $root;
		}
		if ( null === $root ) {
			$this->signature = $this->options_signature();
			return $this->snapshot = array();
		}

		try {
			$paths = array();
			foreach ( new FilesystemIterator( $root, FilesystemIterator::SKIP_DOTS ) as $entry ) {
				if ( str_ends_with( $entry->getFilename(), '.json' ) ) {
					$paths[] = $root . DIRECTORY_SEPARATOR . $entry->getFilename();
				}
			}
		} catch ( UnexpectedValueException $error ) {
			$this->signature = $this->options_signature();
			return $this->snapshot = $this->failure(
				'markdown_db_native_unsafe_path',
				'unreadable_options_directory',
				'The canonical options directory cannot be enumerated.'
			);
		}
		if ( $root !== realpath( $this->state_root . DIRECTORY_SEPARATOR . '_options' )
			|| is_link( $this->state_root . DIRECTORY_SEPARATOR . '_options' )
		) {
			$this->signature = $this->options_signature();
			return $this->snapshot = $this->failure(
				'markdown_db_native_unsafe_path',
				'changed_options_directory',
				'The canonical options directory changed while it was being enumerated.'
			);
		}

		sort( $paths, SORT_STRING );
		$catalogued = $this->catalogue->restore( $root, $paths );
		$rows  = array();
		$ids   = array();
		$names = array();
		$signatures = array();
		$ordered_signatures = array();
		foreach ( $paths as $offset => $path ) {
			$path_signature = null === $catalogued ? null : ( $catalogued['signatures'][ $offset ] ?? null );
			$row = null === $catalogued ? $this->read_option( $path, $root, null, $path_signature ) : ( $catalogued['rows'][ $offset ] ?? null );
			if ( null !== $catalogued && null === $row ) {
				$autoload = $catalogued['autoloads'][ $offset ] ?? null;
				if ( null !== $autoload_values && is_string( $autoload ) && ! in_array( $autoload, $autoload_values, true ) ) {
					$signatures[ basename( $path ) ] = (string) $path_signature;
					$ordered_signatures[] = (string) $path_signature;
					continue;
				}
				$row = $this->read_option( $path, $root, null, $path_signature );
			}
			if ( $row instanceof WP_Markdown_Query_Result ) {
				$this->signature = $this->options_signature();
				return $this->snapshot = $row;
			}
			if ( ! is_array( $row ) || true !== $this->schema->validate_row( $row )
				|| basename( $path ) !== WP_Markdown_Canonical_Option_Path::filename( $row['option_name'] )
				|| isset( $ids[ $row['option_id'] ] )
				|| isset( $names[ $row['option_name'] ] )
			) {
				$this->signature = $this->options_signature();
				return $this->snapshot = $this->failure(
					'markdown_db_native_malformed_option',
					'invalid_option_identity',
					'Canonical option files must have unique identities and canonical filenames.'
				);
			}
			$ids[ $row['option_id'] ]     = true;
			$names[ $row['option_name'] ] = true;
			$rows[]                       = $row;
			$signatures[ basename( $path ) ] = (string) $path_signature;
			$ordered_signatures[] = (string) $path_signature;
			$key = (string) $this->schema->value_key( 'option_name', $row['option_name'] );
			$this->option_cache[ $key ] = array(
				'signature' => (string) $path_signature,
				'value'     => $row,
			);
		}
		if ( null === $catalogued ) {
			$this->catalogue->persist( $paths, $rows, $ordered_signatures );
		}
		$this->signature = $this->options_signature( $signatures );
		return $this->snapshot = $rows;
	}

	/** @param array<int,int|string> $values @return array<int,array<string,mixed>>|WP_Markdown_Query_Result */
	private function named_rows( array $values ): array|WP_Markdown_Query_Result {
		$root = $this->options_root();
		if ( $root instanceof WP_Markdown_Query_Result ) {
			return $root;
		}
		if ( null === $root ) {
			return array();
		}

		$rows = array();
		$ids  = array();
		foreach ( $values as $name ) {
			if ( ! is_string( $name ) ) {
				continue;
			}
			$key = (string) $this->schema->value_key( 'option_name', $name );
			$path = $this->option_path( $root, $name );
			if ( $path instanceof WP_Markdown_Query_Result ) {
				return $path;
			}
			$signature = null === $path ? 'missing' : ( isset( $this->option_cache[ $key ] ) ? $this->path_signature( $path ) : null );
			if ( ! isset( $this->option_cache[ $key ] ) || $signature !== $this->option_cache[ $key ]['signature'] ) {
				$path_signature = null;
				$value = null === $path ? null : $this->read_option( $path, $root, $name, $path_signature );
				$this->option_cache[ $key ] = array(
					'signature' => null === $path ? 'missing' : (string) $path_signature,
					'value'     => $value,
				);
			}
			$row = $this->option_cache[ $key ]['value'];
			if ( $row instanceof WP_Markdown_Query_Result ) {
				return $row;
			}
			if ( null === $row ) {
				continue;
			}
			if ( isset( $ids[ $row['option_id'] ] ) ) {
				return $this->failure(
					'markdown_db_native_malformed_option',
					'invalid_option_identity',
					'Canonical option files must have unique identities.'
				);
			}
			$ids[ $row['option_id'] ] = true;
			$rows[]                   = $row;
		}
		return $rows;
	}

	/** @param array<string,string>|null $file_signatures */
	private function options_signature( ?array $file_signatures = null ): string {
		$directory = $this->state_root . DIRECTORY_SEPARATOR . '_options';
		$parts = array( $this->path_signature( $directory ) );
		if ( null !== $file_signatures ) {
			$parts += $file_signatures;
		} elseif ( is_dir( $directory ) && ! is_link( $directory ) ) {
			try {
				foreach ( new FilesystemIterator( $directory, FilesystemIterator::SKIP_DOTS ) as $entry ) {
					if ( str_ends_with( $entry->getFilename(), '.json' ) ) {
						$parts[ $entry->getFilename() ] = $this->path_signature( $directory . DIRECTORY_SEPARATOR . $entry->getFilename() );
					}
				}
			} catch ( UnexpectedValueException $error ) {
				$parts[] = 'unreadable';
			}
		}
		ksort( $parts, SORT_STRING );
		return hash( 'sha256', serialize( $parts ) );
	}

	private function option_path( string $root, string $name ): string|WP_Markdown_Query_Result|null {
		$filename = WP_Markdown_Canonical_Option_Path::filename( $name );
		$path     = $root . DIRECTORY_SEPARATOR . $filename;
		if ( file_exists( $path ) || is_link( $path ) ) {
			return $path;
		}
		$hashed_prefix = null;
		if ( $filename !== $name . '.json'
			&& 1 === preg_match( '/^(.*-)[0-9a-f]{8}\.json$/D', $filename, $expected )
		) {
			$hashed_prefix = $expected[1];
		}

		$matches = array();
		try {
			foreach ( new FilesystemIterator( $root, FilesystemIterator::SKIP_DOTS ) as $entry ) {
				$candidate = $entry->getFilename();
				if ( 0 === strcasecmp( $candidate, $filename ) ) {
					$matches[] = $root . DIRECTORY_SEPARATOR . $candidate;
					continue;
				}
				if ( null === $hashed_prefix
					|| 1 !== preg_match( '/^(.*-)[0-9a-f]{8}\.json$/D', $candidate, $actual )
					|| 0 !== strcasecmp( $hashed_prefix, $actual[1] )
				) {
					continue;
				}
				$candidate_path = $root . DIRECTORY_SEPARATOR . $candidate;
				$signature = null;
				$row = $this->read_option( $candidate_path, $root, null, $signature );
				if ( $row instanceof WP_Markdown_Query_Result ) {
					return $row;
				}
				if ( $this->schema->values_match( 'option_name', $name, $row['option_name'] ) ) {
					$matches[] = $candidate_path;
				}
			}
		} catch ( UnexpectedValueException $error ) {
			return $this->failure(
				'markdown_db_native_unsafe_path',
				'unreadable_options_directory',
				'The canonical options directory cannot be enumerated.'
			);
		}
		if ( $root !== realpath( $this->state_root . DIRECTORY_SEPARATOR . '_options' ) || is_link( $root ) ) {
			return $this->failure(
				'markdown_db_native_unsafe_path',
				'changed_options_directory',
				'The canonical options directory changed while resolving an identity.'
			);
		}
		if ( count( $matches ) > 1 ) {
			return $this->failure(
				'markdown_db_native_malformed_option',
				'duplicate_collated_identity',
				'Canonical option files contain duplicate collated identities.'
			);
		}
		return $matches[0] ?? null;
	}

	private function options_root(): string|WP_Markdown_Query_Result|null {
		$path = $this->state_root . DIRECTORY_SEPARATOR . '_options';
		if ( ! file_exists( $path ) && ! is_link( $path ) ) {
			return null;
		}
		$root = realpath( $path );
		if ( is_link( $path ) || false === $root || ! is_dir( $root ) || ! $this->contains( $this->state_root, $root ) ) {
			return $this->failure(
				'markdown_db_native_unsafe_path',
				'unsafe_options_directory',
				'The canonical options directory is not contained by the state root.'
			);
		}
		return $root;
	}

	/** @return array<string,mixed>|WP_Markdown_Query_Result */
	private function read_option(
		string $path,
		string $root,
		?string $expected = null,
		?string &$signature = null
	): array|WP_Markdown_Query_Result {
		$digest = null;
		$row = $this->read_json( $path, $root, 'option_file', $digest );
		$signature = $this->path_signature( $path, $digest );
		if ( $row instanceof WP_Markdown_Query_Result ) {
			$diagnostic = $row->diagnostic();
			return 'markdown_db_native_unsafe_path' === ( $diagnostic['code'] ?? '' )
				? $row
				: $this->failure(
					'markdown_db_native_malformed_option',
					$diagnostic['reason'] ?? 'unreadable_option_file',
					'The canonical option file cannot be read.'
				);
		}
		if ( ! is_array( $row )
			|| true !== $this->schema->validate_row( $row )
			|| ( null !== $expected && ! $this->schema->values_match( 'option_name', $expected, $row['option_name'] ) )
		) {
			return $this->failure(
				'markdown_db_native_malformed_option',
				'invalid_option_row',
				'The canonical option file does not contain the requested option row.'
			);
		}
		return $row;
	}
}
