<?php
/** Probe how the native runtime answers MySQL transaction control statements. */

declare( strict_types=1 );

define( 'ABSPATH', __DIR__ . '/' );
require_once __DIR__ . '/../inc/native/class-wp-markdown-native-query-runtime.php';

class wpdb {
	public string $prefix = '';
	public string $options = '';
	public bool $ready = false;
	public int $num_queries = 0;
	public int $num_rows = 0;
	public int $rows_affected = 0;
	public int $insert_id = 0;
	public string $last_error = '';
	public ?string $last_query = null;
	public string $func_call = '';
	public array $last_result = array();
	protected array $col_info = array();
	protected bool $check_current_query = true;
	protected bool $result = false;

	public function set_prefix( string $prefix ): string {
		$this->prefix  = $prefix;
		$this->options = $prefix . 'options';
		return $prefix;
	}

	public function flush(): void {
		$this->last_result = array();
		$this->col_info    = array();
		$this->last_error  = '';
		$this->num_rows    = 0;
	}

	public function add_placeholder_escape( string $value ): string {
		return $value;
	}

	public function remove_placeholder_escape( string $value ): string {
		return $value;
	}
}
require_once __DIR__ . '/../inc/native/class-wp-markdown-native-wpdb.php';

$root = sys_get_temp_dir() . '/mdi-native-transactions-' . bin2hex( random_bytes( 6 ) );
if ( ! mkdir( $root . '/_options', 0777, true ) || ! mkdir( $root . '/_tables', 0777, true ) ) {
	throw new RuntimeException( 'Failed to create the transaction probe fixture.' );
}

file_put_contents(
	$root . '/_options/probe_option.json',
	json_encode(
		array(
			'option_id'    => 1,
			'option_name'  => 'probe_option',
			'option_value' => 'committed',
			'autoload'     => 'on',
		),
		JSON_THROW_ON_ERROR
	)
);

$runtime = WP_Markdown_Native_Runtime_Factory::runtime( $root );
$runtime->execute( new WP_Markdown_Query_Request( 'CREATE TABLE wp_probe_rows (id int unsigned NOT NULL auto_increment, label varchar(32) NOT NULL, PRIMARY KEY (id))', 'wp_' ) );

/** @return array<string,mixed> */
function probe_statement( WP_Markdown_Native_Query_Runtime $runtime, string $sql ): array {
	try {
		$result = $runtime->execute( new WP_Markdown_Query_Request( $sql ) );
		return array(
			'sql'          => $sql,
			'outcome'      => 'returned',
			'return_value' => $result->return_value(),
			'diagnostic'   => $result->diagnostic(),
			'last_error'   => $result->wpdb_state()['last_error'] ?? null,
		);
	} catch ( Throwable $error ) {
		return array(
			'sql'       => $sql,
			'outcome'   => 'threw',
			'exception' => get_class( $error ),
			'message'   => $error->getMessage(),
		);
	}
}

/** Read native session state and its wpdb-visible result contract. */
function probe_session_variable( WP_Markdown_Native_Query_Runtime $runtime, string $sql ): array {
	$result = $runtime->execute( new WP_Markdown_Query_Request( $sql ) );
	$state = $result->wpdb_state();
	$rows = $state['last_result'] ?? array();
	$columns = $state['col_info'] ?? array();
	return array(
		'value' => isset( $rows[0] ) ? current( get_object_vars( $rows[0] ) ) : null,
		'column' => $columns[0]->name ?? null,
	);
}

$inactive_savepoint = probe_statement( $runtime, 'SAVEPOINT outside_transaction' );
$inactive_state = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
$inactive_release = probe_statement( $runtime, 'RELEASE SAVEPOINT outside_transaction' );

probe_statement( $runtime, 'SET autocommit = 0' );
$autocommit_off_savepoint = probe_statement( $runtime, 'SAVEPOINT autocommit_off' );
$autocommit_off_savepoint_state = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
$autocommit_off_release = probe_statement( $runtime, 'RELEASE SAVEPOINT autocommit_off' );
probe_statement( $runtime, 'ROLLBACK' );
probe_statement( $runtime, 'SET autocommit = 1' );

$session_before = array(
	'in_transaction' => probe_session_variable( $runtime, 'SELECT @@session.in_transaction' ),
	'autocommit'     => probe_session_variable( $runtime, 'SELECT @@autocommit' ),
);
probe_statement( $runtime, 'START TRANSACTION' );
$session_inside = array(
	'in_transaction' => probe_session_variable( $runtime, 'SELECT @@SESSION.in_transaction' ),
	'autocommit'     => probe_session_variable( $runtime, 'SELECT @@session.autocommit' ),
);
probe_statement( $runtime, 'ROLLBACK' );

probe_statement( $runtime, 'SET autocommit = 0' );
$autocommit_idle = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, 'SELECT 1' );
$autocommit_after_scalar_read = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, "SELECT option_value FROM wp_options WHERE option_name = 'probe_option'" );
$autocommit_after_table_read = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, "UPDATE wp_options SET option_value = 'implicit-write' WHERE option_name = 'probe_option'" );
$autocommit_after_write = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, 'ROLLBACK' );
$autocommit_after_rollback = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, 'SET autocommit = 1' );

// Generic-table writes must share the implicit autocommit-off transaction.
probe_statement( $runtime, 'SET autocommit = 0' );
probe_statement( $runtime, "INSERT INTO wp_probe_rows (label) VALUES ('first')" );
probe_statement( $runtime, "INSERT INTO wp_probe_rows (label) VALUES ('second')" );
$generic_inside = probe_session_variable( $runtime, 'SELECT @@session.in_transaction' );
probe_statement( $runtime, 'ROLLBACK' );
$generic_after_rollback = $runtime->execute( new WP_Markdown_Query_Request( 'SELECT COUNT(*) FROM wp_probe_rows', 'wp_' ) );
probe_statement( $runtime, 'SET autocommit = 1' );

$statements = array(
	'START TRANSACTION',
	'BEGIN',
	'SAVEPOINT probe_point',
	'ROLLBACK TO SAVEPOINT probe_point',
	'RELEASE SAVEPOINT probe_point',
	'COMMIT',
	'ROLLBACK',
	'SET autocommit = 0',
);

$observations = array();
foreach ( $statements as $statement ) {
	$observations[] = probe_statement( $runtime, $statement );
}

// A rolled-back mutation must not remain visible in canonical state.
$mutation = array(
	'begin'    => probe_statement( $runtime, 'START TRANSACTION' ),
	'mutate'   => probe_statement(
		$runtime,
		"UPDATE wp_options SET option_value = 'rolled-back' WHERE option_name = 'probe_option'"
	),
	'rollback' => probe_statement( $runtime, 'ROLLBACK' ),
);

$after_rollback = probe_statement(
	$runtime,
	"SELECT option_value FROM wp_options WHERE option_name = 'probe_option'"
);

$canonical_after_rollback = json_decode( (string) file_get_contents( $root . '/_options/probe_option.json' ), true );

/** Read one canonical option value straight from disk. */
function probe_canonical_value( string $root, string $option ): ?string {
	$path = $root . '/_options/' . $option . '.json';
	if ( ! is_file( $path ) ) {
		return null;
	}
	$row = json_decode( (string) file_get_contents( $path ), true );
	return is_array( $row ) ? ( $row['option_value'] ?? null ) : null;
}

// COMMIT must publish the mutation durably.
probe_statement( $runtime, 'START TRANSACTION' );
probe_statement( $runtime, "UPDATE wp_options SET option_value = 'committed-value' WHERE option_name = 'probe_option'" );
probe_statement( $runtime, 'COMMIT' );
$commit_durability = probe_canonical_value( $root, 'probe_option' );

// A savepoint rewind must discard only the work after the savepoint.
probe_statement( $runtime, 'START TRANSACTION' );
probe_statement( $runtime, "UPDATE wp_options SET option_value = 'before-savepoint' WHERE option_name = 'probe_option'" );
probe_statement( $runtime, 'SAVEPOINT stage_one' );
probe_statement( $runtime, "UPDATE wp_options SET option_value = 'after-savepoint' WHERE option_name = 'probe_option'" );
probe_statement( $runtime, 'ROLLBACK TO SAVEPOINT stage_one' );
$savepoint_rewind = probe_canonical_value( $root, 'probe_option' );
probe_statement( $runtime, 'COMMIT' );
$savepoint_committed = probe_canonical_value( $root, 'probe_option' );

// An INSERT rolled back must leave no canonical row behind.
probe_statement( $runtime, 'START TRANSACTION' );
probe_statement( $runtime, "INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('probe_created','created','on')" );
$insert_visible_in_transaction = probe_canonical_value( $root, 'probe_created' );
probe_statement( $runtime, 'ROLLBACK' );
$insert_after_rollback = probe_canonical_value( $root, 'probe_created' );

// Terminating mid-transaction must leave a journal that the next boot rolls back.
probe_statement( $runtime, 'START TRANSACTION' );
probe_statement( $runtime, "UPDATE wp_options SET option_value = 'torn-write' WHERE option_name = 'probe_option'" );
$journal_present = 1 === count( glob( $root . '/_journal/native-transaction-*.json' ) ?: array() );
$torn_value      = probe_canonical_value( $root, 'probe_option' );
unset( $runtime );
gc_collect_cycles();
$recovered_runtime = WP_Markdown_Native_Runtime_Factory::runtime( $root );
$recovered_value   = probe_canonical_value( $root, 'probe_option' );
$journal_cleared   = array() === ( glob( $root . '/_journal/native-transaction-*.json' ) ?: array() );

$control_executes = array_reduce(
	$observations,
	static fn( bool $carry, array $observation ): bool => $carry && 0 === $observation['return_value'],
	true
);

$report = array(
	'schema'                   => 'mdi-native-transaction-probe/v1',
	'control_statements'       => $observations,
	'rollback_sequence'        => $mutation,
	'select_after_rollback'    => $after_rollback,
	'canonical_after_rollback' => $canonical_after_rollback['option_value'] ?? null,
	'session_state'            => array(
		'before' => $session_before,
		'inside' => $session_inside,
		'autocommit_off' => array(
			'idle' => $autocommit_idle,
			'after_scalar_read' => $autocommit_after_scalar_read,
			'after_table_read' => $autocommit_after_table_read,
			'after_write' => $autocommit_after_write,
			'after_rollback' => $autocommit_after_rollback,
		),
		'generic_autocommit_off' => array(
			'inside' => $generic_inside,
			'after_rollback' => $generic_after_rollback->wpdb_state()['last_result'][0]->{'COUNT(*)'} ?? null,
		),
	),
	'assertions'               => array(
		'savepoint outside an autocommit session is a no-op' => 0 === $inactive_savepoint['return_value']
			&& '0' === $inactive_state['value']
			&& false === $inactive_release['return_value'],
		'autocommit-off savepoint remains outside a transaction' => 0 === $autocommit_off_savepoint['return_value']
			&& '0' === $autocommit_off_savepoint_state['value']
			&& 0 === $autocommit_off_release['return_value'],
		'transaction control statements execute'        => $control_executes,
	'session state reports MySQL-shaped strings and headers' => '0' === $session_before['in_transaction']['value']
		&& '@@session.in_transaction' === $session_before['in_transaction']['column']
		&& '1' === $session_before['autocommit']['value']
		&& '@@autocommit' === $session_before['autocommit']['column']
		&& '1' === $session_inside['in_transaction']['value']
		&& '@@SESSION.in_transaction' === $session_inside['in_transaction']['column']
		&& '1' === $session_inside['autocommit']['value']
		&& '@@session.autocommit' === $session_inside['autocommit']['column'],
	'autocommit-off starts only on transactional table access' => '0' === $autocommit_idle['value']
		&& '0' === $autocommit_after_scalar_read['value']
		&& '1' === $autocommit_after_table_read['value']
		&& '1' === $autocommit_after_write['value']
		&& '0' === $autocommit_after_rollback['value'],
	'generic autocommit-off writes share rollback ownership' => '1' === $generic_inside['value']
		&& '0' === ( $generic_after_rollback->wpdb_state()['last_result'][0]->{'COUNT(*)'} ?? null ),
		'rollback restores the canonical pre-image'     => 'committed' === ( $canonical_after_rollback['option_value'] ?? null ),
		'commit publishes the mutation durably'         => 'committed-value' === $commit_durability,
		'savepoint rewind discards only later work'     => 'before-savepoint' === $savepoint_rewind,
		'commit after a rewind keeps the kept work'     => 'before-savepoint' === $savepoint_committed,
		'a rolled back insert leaves no canonical row'  => 'created' === $insert_visible_in_transaction
			&& null === $insert_after_rollback,
		'an interrupted transaction journals its undo'  => $journal_present && 'torn-write' === $torn_value,
	),
);
$report['durability_preserved'] = 'committed' === ( $canonical_after_rollback['option_value'] ?? null );

$passed = ! in_array( false, $report['assertions'], true );
$report['passed'] = $passed;

fwrite(
	$passed ? STDOUT : STDERR,
	json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR ) . "\n"
);
exit( $passed ? 0 : 1 );
