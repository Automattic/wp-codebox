---
type: document
title: Cloudflare WordPress Runtime
description: A bounded WordPress WebAssembly runtime with canonical Markdown state in R2.
resource: "https://wp-codebox-runtime.invalid/?page_id=2"
tags:
timestamp: "2026-07-18T14:54:20+00:00"
wordpress:
  id: 2
  status: publish
  type: page
  author: 1
  date: "2026-07-18 14:54:20"
  date_gmt: "2026-07-18 14:54:20"
  modified: "2026-07-18 14:54:20"
  modified_gmt: "2026-07-18 14:54:20"
  slug: cloudflare-wordpress-runtime
  parent: 0
  menu_order: 0
  comment_status: closed
  ping_status: open
  guid: "https://wp-codebox-runtime.invalid/?page_id=2"
  comment_count: 0
  excerpt: A bounded WordPress WebAssembly runtime with canonical Markdown state in R2.
  meta:
    _wp_page_template: default
---

<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">WordPress at the edge, with durable Markdown state</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">This bounded Cloudflare runtime runs WordPress and PHP as WebAssembly at the edge while keeping durable site state outside the disposable query database.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Architecture flow</h2>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Edge request</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>WordPress/PHP WebAssembly boots for the request.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"align":"center","fontSize":"x-large"} -->
<p class="has-text-align-center has-x-large-font-size">&rarr;</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Disposable SQLite</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>SQLite is reconstructed as query state, not the durable source of truth.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"align":"center","fontSize":"x-large"} -->
<p class="has-text-align-center has-x-large-font-size">&rarr;</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Canonical state</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Markdown Database Integration exports canonical Markdown and JSON into immutable, content-addressed R2 objects and revision manifests.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"align":"center","fontSize":"x-large"} -->
<p class="has-text-align-center has-x-large-font-size">&rarr;</p>
<!-- /wp:paragraph --><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Serialized writes</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>A Durable Object serializes writes and atomically advances the current revision. A cold runtime hydrates that manifest and reconstructs SQLite.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Verified capabilities</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Log in to WordPress.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Edit content with the block editor and publish it.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Render the published page publicly.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Recover the site after a cold start from the current revision manifest.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Bounded by design</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>One site namespace is currently configured.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Requests for a site are serialized while a write lease is held.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Each dynamic request currently pays PHP boot cost.</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Cold recovery hydrates the full revision manifest.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</main>
<!-- /wp:group -->
