---
type: document
title: "Hello world!"
description: ""
resource: "https://wp-codebox-runtime.invalid/?p=1"
tags:
timestamp: "2026-07-18T14:54:20+00:00"
wordpress:
  id: 1
  status: publish
  type: post
  author: 1
  date: "2026-07-18 14:54:20"
  date_gmt: "2026-07-18 14:54:20"
  modified: "2026-07-18 14:54:20"
  modified_gmt: "2026-07-18 14:54:20"
  slug: hello-world
  parent: 0
  menu_order: 0
  comment_status: open
  ping_status: open
  guid: "https://wp-codebox-runtime.invalid/?p=1"
  comment_count: 1
  terms:
    category:
      - uncategorized
---

<!-- wp:paragraph -->
<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>
<!-- /wp:paragraph -->
